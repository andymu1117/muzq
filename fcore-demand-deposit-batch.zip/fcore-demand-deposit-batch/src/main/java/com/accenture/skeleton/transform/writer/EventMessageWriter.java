package com.accenture.skeleton.transform.writer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.SpannerException;
import com.google.cloud.spanner.TransactionContext;
import com.google.common.collect.ImmutableMap;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.mutation.EntityToMutationConverter;
import com.accenture.mainri.core.converter.spanner.mutation.EntityToMutationConverter.Operation;
import com.accenture.mainri.core.entity.EventMessagesEntity;
import com.accenture.mainri.core.entity.PublishMessageResultsEntity;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.io.kafka.ContextKafkaDestination;
import com.accenture.mainri.core.pipeline.options.DefaultOptions;

@SuppressWarnings({"serial", "squid:S1948"})
public class EventMessageWriter extends DoFn<EventMessagesEntity, EventMessagesEntity> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EventMessageWriter.class);
    // シリアライズ可能な値が設定される
    private ImmutableMap<String, Object> ctx;
    private transient Spanner spanner;
    private transient DatabaseClient dbClient;
    private SpannerDriver spannerDriver;
    private TupleTag<EventMessagesEntity> successTag;
    private TupleTag<EventMessagesEntity> errorTag;

    private EntityToMutationConverter converter = new EntityToMutationConverter();

    /**
     * Spannerアクセス用のドライバとリトライ処理用の出力先を受け取りインスタンスを生成します。
     *
     * @param options DefaultOptions
     * @param spannerDriver Spannerアクセス用のDriver
     * @param successTag 処理成功時の出力先
     * @param errorTag 処理失敗時の出力先
     */
    public EventMessageWriter(DefaultOptions options, SpannerDriver spannerDriver,
        TupleTag<EventMessagesEntity> successTag, TupleTag<EventMessagesEntity> errorTag) {
        this.ctx = ImmutableMap.copyOf(options.getPipelineContext());
        this.spannerDriver = spannerDriver;
        this.successTag = successTag;
        this.errorTag = errorTag;
    }

    /**
     * 初期化処理。
     */
    @Setup
    public void setup() {
        LOGGER.debug("Setup spanner.");
        spanner = spannerDriver.createService();
        dbClient = spannerDriver.createDatabaseClient(spanner);
    }

    @Teardown
    public void teardown() {
        LOGGER.debug("Close spanner.");
        spanner.close();
    }

    /**
     * Writerの処理。
     *
     * @param entity 対象メッセージ
     * @param context ProcessのContext
     */
    @ProcessElement
    public void processElement(@Element EventMessagesEntity entity, ProcessContext context) {
        LOGGER.debug("call InsertFn.processElement");
        try {
            // inputのDailyBalanceMessageDtoを一部書き換えてoutputにするため、新しくインスタンスを作る
            spannerDriver.write(dbClient, (TransactionContext tx) -> {
                List<Mutation> mutations = convertToMutations(ctx, entity);
                tx.buffer(mutations);
            });
            context.output(successTag, entity);
            LOGGER.debug("end InsertFn.processElement");
        } catch (SpannerException e) {
            context.output(errorTag, entity);
            LOGGER.error("Insertion failed", e);
        }
    }

    /**
     * EventMessagesEntityをMutationのリストに変換する。
     * 
     * @param ctx パイプラインコンテキスト
     * @param entity 変換対象エンティティ
     * @return 変換結果
     */
    private List<Mutation> convertToMutations(Map<String, Object> ctx, EventMessagesEntity entity) {
        List<Mutation> mutations = new ArrayList<>();

        // EventMessagesテーブル
        mutations.add(createEventMessagesMutation(entity));

        // PublishMessageResultsテーブル
        List<ContextKafkaDestination> kafkaDestinations =
            ((List<Map<String, Object>>) ctx.get("kafka.destinations")).stream()
                .map(ContextKafkaDestination::new)
                .collect(Collectors.toList());
        for (ContextKafkaDestination destination : kafkaDestinations) {
            String targetKey = destination.getTargetKey();
            mutations.add(createPublishMessageResultsMutation(entity, targetKey));
        }

        return mutations;
    }

    private Mutation createEventMessagesMutation(EventMessagesEntity entity) {
        EntityToMutationConverter.Metadata metadata =
            new EntityToMutationConverter.Metadata(Operation.INSERT_OR_UPDATE);
        return converter.convert(entity, metadata);
    }

    private Mutation createPublishMessageResultsMutation(EventMessagesEntity entity, String targetKey) {
        PublishMessageResultsEntity target = new PublishMessageResultsEntity();
        target.setEventMessageId(entity.getEventMessageId());
        target.setPublishTarget(targetKey);
        target.setCreationUserId(entity.getCreationUserId());
        target.setCreationDate(entity.getCreationDate());
        target.setUpdatedUserId(entity.getUpdatedUserId());
        target.setUpdatedDate(entity.getUpdatedDate());

        EntityToMutationConverter.Metadata metadata =
            new EntityToMutationConverter.Metadata(Operation.INSERT_OR_UPDATE);
        return converter.convert(target, metadata);
    }

}
