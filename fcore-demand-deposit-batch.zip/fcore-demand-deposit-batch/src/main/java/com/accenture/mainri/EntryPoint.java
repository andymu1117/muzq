package com.accenture.mainri;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.reflections.Reflections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.exception.JobFailedException;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineTemplate;
import com.accenture.mainri.core.pipeline.options.DefaultOptions;

public class EntryPoint {
    private static final Logger LOGGER = LoggerFactory.getLogger(EntryPoint.class);

    /**
     * ApplicationのEntry point。
     * 
     * @param args コマンドライン引数
     * @throws Exception 実行時に発生した例外
     */
    public static void main(String[] args) throws Exception {
        printVersionJson();
        Map<String, Class<? extends PipelineTemplate<?>>> definitions = scanPipelineDefinitions();
        String pipelineName = getPipelineName(args);
        Class<? extends PipelineTemplate<?>> pipelineClass = definitions.get(pipelineName);
        if (pipelineClass == null) {
            throw new IllegalStateException("Could not find a pipeline definition associated with " + pipelineName);
        }
        PipelineDefinition annotation = pipelineClass.getAnnotation(PipelineDefinition.class);
        Class<? extends DefaultOptions> optionClass = annotation.optionClass();
        try {
            pipelineClass.newInstance()
                .configureAndRun(args, optionClass);
        } catch (JobFailedException ex) {
            LOGGER.error("Job has been failed", ex);
            System.exit(1);
        }
    }

    private static void printVersionJson() {
        try (InputStream is = EntryPoint.class.getResourceAsStream("/www/version.json");
            InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr)) {
            String versionJson = br.lines()
                .collect(Collectors.joining("\n"));
            LOGGER.info("version json: {}", versionJson);
        } catch (IOException e) {
            LOGGER.warn("failed to get version.json", e);
        }
    }

    private static String getPipelineName(String[] args) {
        DefaultOptions options = PipelineOptionsFactory.fromArgs(args)
            .withoutStrictParsing()
            .as(DefaultOptions.class);
        String pipelineName = options.getPipelineName();
        if (pipelineName == null) {
            throw new IllegalStateException("--pipelineName must be provided as a command line argument");
        }

        return pipelineName;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Class<? extends PipelineTemplate<?>>> scanPipelineDefinitions() {
        // 作成したPipelineクラスを取得。
        Reflections businessPackage = new Reflections("com.neobank");
        Set<Class<?>> pipelineClasses = businessPackage.getTypesAnnotatedWith(PipelineDefinition.class);
        // Mainri Pipeline Frameworkに標準で含められているPipelineクラスを取得。
        Reflections corePackage = new Reflections("com.accenture.mainri.core.pipeline");
        Set<Class<?>> corePipelineClasses = corePackage.getTypesAnnotatedWith(PipelineDefinition.class);

        pipelineClasses.addAll(corePipelineClasses);

        Map<String, Class<? extends PipelineTemplate<?>>> pipelineDefinitions = new HashMap<>();
        for (Class<?> pipelineClass : pipelineClasses) {
            PipelineDefinition annotation = pipelineClass.getAnnotation(PipelineDefinition.class);
            String pipelineName = annotation.name();
            if (null != pipelineDefinitions.get(pipelineName)) {
                throw new IllegalStateException(pipelineName + " is duplicated pipeline name.");
            }
            pipelineDefinitions.put(pipelineName, (Class<? extends PipelineTemplate<?>>) pipelineClass);
        }

        return pipelineDefinitions;
    }

}
