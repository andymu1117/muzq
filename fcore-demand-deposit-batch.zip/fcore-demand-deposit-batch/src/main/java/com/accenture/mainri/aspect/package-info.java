/**
 * AspectJ用の定義を配置するパッケージ。
 */
package com.accenture.mainri.aspect;
