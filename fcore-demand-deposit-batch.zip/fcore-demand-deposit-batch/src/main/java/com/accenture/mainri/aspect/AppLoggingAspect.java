package com.accenture.mainri.aspect;

import java.util.UUID;

import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.aspect.utils.LoggingAspectUtils;

/**
 * 横断的なログの出力機能を取りまとめるためのクラス。
 */
@Aspect
public class AppLoggingAspect {

    /**
     * {@linkplain ProcessElement}アノテーションを付与したメソッドを対象としたログ出力Aspect。
     *
     * @param point ポイントカットオブジェクト
     * @return ポイントカットしたメソッドの戻り値
     * @throws Throwable ポイントカットしたメソッドの例外
     */
    @SuppressWarnings("squid:S00112")
    @Around("execution(* com.neobank*..*(..)) && @annotation(org.apache.beam.sdk.transforms.DoFn.ProcessElement)")
    public Object logProcessElement(ProceedingJoinPoint point) throws Throwable {
        Logger logger = LoggerFactory.getLogger(point.getTarget()
            .getClass());

        String methodName = point.getSignature()
            .getName();
        UUID methodTraceKey = UUID.randomUUID();

        if (logger.isInfoEnabled()) {
            logger.info("{}({}) starts with params: {}", methodName, methodTraceKey,
                LoggingAspectUtils.convertToLogString(point.getArgs()));
        }
        Object result = point.proceed();
        if (logger.isInfoEnabled()) {
            logger.info("{}({}) ends with return value: {}", methodName, methodTraceKey,
                LoggingAspectUtils.convertToLogString(result));
        }
        return result;
    }

}
