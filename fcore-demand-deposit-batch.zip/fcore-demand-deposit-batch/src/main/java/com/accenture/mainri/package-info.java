/**
 * アプリケーション起動用の資源を格納するパッケージ。
 */
package com.accenture.mainri;
