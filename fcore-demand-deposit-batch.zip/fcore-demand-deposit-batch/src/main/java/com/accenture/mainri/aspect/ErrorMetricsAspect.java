package com.accenture.mainri.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

import com.accenture.mainri.core.metrics.MetricsUtil;

/**
 * エラーログを出力した際にApache BeamのMetricsで計測しているエラーカウントをインクリメントするためのAspect。
 */
@Aspect
public class ErrorMetricsAspect {

    /**
     * {@link org.slf4j.Logger}の{@code error}メソッド実行後にApache BeamのMetricsにあるエラーカウントをインクリメントする。
     */
    @After("call(* org.slf4j.Logger.error(..))")
    public void incErrorCount() {
        MetricsUtil.incErrorCount();
    }

}
