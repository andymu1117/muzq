package com.neobank.fcore.demanddeposit.transform.grpc;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.io.GrpcConnector;

import com.neobank.fcore.demanddeposit.dto.CustomerAdvantageConditionUpdateErrorEntryDto;
import com.neobank.fcore.demanddeposit.dto.CustomerAdvantageConditionUpdateResponseDto;
import com.neobank.fcore.demanddeposit.entity.CustomerAdvantageConditionEntity;
import com.neobank.fcore.demanddeposit.grpc.GrpcErrorParser;
import com.neobank.fcore.demanddeposit.grpc.GrpcMetaBuilder;
import com.neobank.fcore.demanddeposit.grpc.GrpcSystemException;
import com.neobank.fcore.demanddeposit.grpc.GrpcValidationException;
import com.neobank.fcore.demanddeposit.pb.command.CommandVersion;
import com.neobank.fcore.demanddeposit.pb.command.CustomerAdvantageConditionCommandGrpc;
import com.neobank.fcore.demanddeposit.pb.command.CustomerAdvantageConditionCommandGrpc.CustomerAdvantageConditionCommandBlockingStub;
import com.neobank.fcore.demanddeposit.pb.command.message.CustomerAdvantageConditionUpdateRequest;
import com.neobank.fcore.demanddeposit.pb.command.message.CustomerAdvantageConditionUpdateResponse;

@SuppressWarnings("serial")
public class CustomerAdvantageConditionUpdateApiCaller
    extends DoFn<CustomerAdvantageConditionEntity, CustomerAdvantageConditionUpdateResponseDto> {
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerAdvantageConditionUpdateApiCaller.class);
    private GrpcConnector grpcConnector;
    private transient CustomerAdvantageConditionCommandBlockingStub stub;
    private TupleTag<CustomerAdvantageConditionUpdateResponseDto> successTag;
    private TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto> errorTag;
    private TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto> warnTag;

    /**
     * エラーハンドリング用のタグとgRPC用の接続を設定するコンストラクタ。
     *
     * @param grpcConnector gRPCのコネクタ
     * @param successTag 正常時の出力先
     * @param errorTag エラー時の出力先
     * @param warnTag 警告時の出力先
     */
    public CustomerAdvantageConditionUpdateApiCaller(GrpcConnector grpcConnector,
        TupleTag<CustomerAdvantageConditionUpdateResponseDto> successTag,
        TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto> errorTag,
        TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto> warnTag) {
        super();
        this.grpcConnector = grpcConnector;
        this.successTag = successTag;
        this.errorTag = errorTag;
        this.warnTag = warnTag;
    }

    /**
     * gRPCクライアント初期化。
     * 
     * @throws JsonProcessingException Json実施中異常
     */
    @Setup
    public void setup() throws JsonProcessingException {
        LOGGER.debug("SetUp Stub.");
        stub = CustomerAdvantageConditionCommandGrpc.newBlockingStub(grpcConnector.createManagedChannel());
        // リクエストヘッダの設定
        GrpcMetaBuilder metaBuilder = new GrpcMetaBuilder().apiVersion(CommandVersion.API_VERSION)
            .token("CBT007F");
        stub = MetadataUtils.attachHeaders(stub, metaBuilder.getHeaders());
    }

    /**
     * 顧客優遇条件更新API実行部分。
     *
     * @param element 実行対象のデータ
     * @param context 処理のコンテキスト
     * @throws JsonProcessingException JSON処理異常
     */
    @ProcessElement
    public void processElement(@Element CustomerAdvantageConditionEntity element, ProcessContext context)
        throws JsonProcessingException {
        CustomerAdvantageConditionUpdateResponse response = null;
        long startTimeMillis = System.currentTimeMillis();
        // 顧客優遇条件更新APIのリクエストに変換
        CustomerAdvantageConditionUpdateRequest request = convertToRequest(element);
        try {
            response = stub.update(request);
        } catch (StatusRuntimeException sEx) {
            try {
                GrpcErrorParser.parseErrorResponse(sEx);
            } catch (GrpcSystemException sysEx) {
                CustomerAdvantageConditionUpdateErrorEntryDto errorEntry =
                    new CustomerAdvantageConditionUpdateErrorEntryDto(element, sysEx);
                context.output(errorTag, errorEntry);
                LOGGER.error("api request errorEntry: {}", errorEntry, sysEx);
                return;
            } catch (GrpcValidationException valEx) {
                CustomerAdvantageConditionUpdateErrorEntryDto errorEntry =
                    new CustomerAdvantageConditionUpdateErrorEntryDto(element, valEx);
                context.output(warnTag, errorEntry);
                LOGGER.warn("api request warn: {}", errorEntry, valEx);
                return;
            }
            // GRPC呼び出し処理にどのエラーが発生してもキャッチできるようにExceptionをキャッチするようにする
        } catch (Exception ex) {
            CustomerAdvantageConditionUpdateErrorEntryDto errorLogEntry =
                new CustomerAdvantageConditionUpdateErrorEntryDto(element, ex);
            context.output(errorTag, errorLogEntry);
            LOGGER.error("api request errorLogEntry: {}", errorLogEntry, ex);
            return;
        }
        long processingTimeMillis = System.currentTimeMillis() - startTimeMillis;
        LOGGER.debug("[Processing Time] The processing time of the Customer Advantage Condition Update API is {} ms.",
            processingTimeMillis);

        CustomerAdvantageConditionUpdateResponseDto result = new CustomerAdvantageConditionUpdateResponseDto(response);
        context.output(successTag, result);
        LOGGER.debug("response: {}", result);
    }

    /**
     * 顧客優遇条件更新APIのリクエストに変換。
     *
     * @param customerAdvantageConditions 顧客優遇条件
     * @return 顧客優遇条件更新APIのリクエスト
     */
    private CustomerAdvantageConditionUpdateRequest convertToRequest(CustomerAdvantageConditionEntity element) {
        return CustomerAdvantageConditionUpdateRequest.newBuilder()
            .setUpdatedTime(element.getUpdatedTime())
            .addAllCustomerAdvantageCondition(element.getCustomerAdvantageConditions())
            .build();
    }
}
