package com.neobank.fcore.demanddeposit.entity;

import java.io.Serializable;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@SuppressWarnings("serial")
public class InterestAccountFilterEntity extends AccountEntity implements Serializable {
    // オファリングID
    private String offeringId;
    // 基本商品BS情報テーブル.利息有無フラグ
    private String interestFlag;
    // オファリングテーブル 販売開始日
    private LocalDate salesStartDate;
    // オファリングテーブル 販売終了日
    private LocalDate salesEndDate;
    // オファリングテーブル.基本商品BS参照フラグ
    private String itemReferenceFlag;
    // オファリングテーブル.利息有無フラグ
    private String offeringsInterestFlag;
    // オファリングテーブル.オファリングID
    private String offeringsOfferingId;
    // 利息基準日（input.バッチ実施日 - 1）
    private String interestDate;

    public String getOfferingId() {
        return offeringId;
    }

    public void setOfferingId(String offeringId) {
        this.offeringId = offeringId;
    }

    public String getInterestFlag() {
        return interestFlag;
    }

    public void setInterestFlag(String interestFlag) {
        this.interestFlag = interestFlag;
    }

    public LocalDate getSalesStartDate() {
        return salesStartDate;
    }

    public void setSalesStartDate(LocalDate salesStartDate) {
        this.salesStartDate = salesStartDate;
    }

    public LocalDate getSalesEndDate() {
        return salesEndDate;
    }

    public void setSalesEndDate(LocalDate salesEndDate) {
        this.salesEndDate = salesEndDate;
    }

    public String getItemReferenceFlag() {
        return itemReferenceFlag;
    }

    public void setItemReferenceFlag(String itemReferenceFlag) {
        this.itemReferenceFlag = itemReferenceFlag;
    }

    public String getOfferingsInterestFlag() {
        return offeringsInterestFlag;
    }

    public void setOfferingsInterestFlag(String offeringsInterestFlag) {
        this.offeringsInterestFlag = offeringsInterestFlag;
    }

    public String getOfferingsOfferingId() {
        return offeringsOfferingId;
    }

    public void setOfferingsOfferingId(String offeringsOfferingId) {
        this.offeringsOfferingId = offeringsOfferingId;
    }

    public String getInterestDate() {
        return interestDate;
    }

    public void setInterestDate(String interestDate) {
        this.interestDate = interestDate;
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

}
