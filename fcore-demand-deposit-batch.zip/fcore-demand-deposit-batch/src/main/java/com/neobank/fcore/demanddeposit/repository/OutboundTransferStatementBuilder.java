package com.neobank.fcore.demanddeposit.repository;

import java.util.HashMap;
import java.util.Map;

import com.google.cloud.spanner.Statement;

import com.accenture.mainri.core.spanner.SpannerQueryBuilder;
import com.accenture.mainri.core.spanner.SpannerStatementHelper;
import com.accenture.mainri.core.sql.template.FileTemplateProvider;

public class OutboundTransferStatementBuilder {

    /**
     * Spannerに流すSQL文を組み立てる。
     *
     * @param ctx ctx
     * @param targetDate 実施対象日
     * @return ステートメント
     */
    public Statement createSelectBatchTargets(Map<String, Object> ctx, String targetDate) {

        FileTemplateProvider templateProvider = new FileTemplateProvider(ctx, "SelectOutboundTransferExecuteTargets");
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("TargetDate", targetDate);

        SpannerQueryBuilder statementBuilder = new SpannerQueryBuilder();
        String query = statementBuilder.setQueryProvider(templateProvider)
            .setParameters(parameters)
            .build();
        return SpannerStatementHelper.build(query, parameters);
    }
}
