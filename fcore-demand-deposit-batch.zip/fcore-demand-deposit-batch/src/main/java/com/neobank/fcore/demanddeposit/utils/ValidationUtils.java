package com.neobank.fcore.demanddeposit.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.exception.BusinessFailureException;

public class ValidationUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(ValidationUtils.class);

    private static final String FORMAT_YYYYMMDD = "yyyyMMdd";

    private ValidationUtils() {
    }

    /**
     * 日付パラメータのチェック。
     *
     * @param paramDate パラメータ日付(yyyyMMdd)
     */
    public static void checkParamDate(String paramDate) {

        // パラメータの日付チェック
        if (StringUtils.isEmpty(paramDate)) {
            LOGGER.error("param is empty");
            throw new BusinessFailureException("param is empty");
        } else {
            if (paramDate.length() == FORMAT_YYYYMMDD.length()) {
                SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_YYYYMMDD);
                sdf.setLenient(false);
                try {
                    sdf.parse(paramDate);
                } catch (ParseException e) {
                    LOGGER.error("param parse error, ParamDate:{}", paramDate);
                    throw new BusinessFailureException("param parse error", e);
                }
            } else {
                LOGGER.error("param is out of character count, ParamDate:{}", paramDate);
                throw new BusinessFailureException("param is out of character count");
            }
        }
    }

}
