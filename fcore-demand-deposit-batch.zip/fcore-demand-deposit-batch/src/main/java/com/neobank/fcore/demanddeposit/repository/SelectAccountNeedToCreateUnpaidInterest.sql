SELECT
  a.AccountId
  , a.AccountNo
  , a.AccountManageKey
  , a.CustomerId
  , c.CustomerNo
  , a.OfferingId
  , ib.InterestFlag
  , o.SalesStartDate
  , o.SalesEndDate
  , o.ItemReferenceFlag
  , o.InterestFlag AS OfferingsInterestFlag
  , o.OfferingId AS OfferingsOfferingId
  , @interestDate AS InterestDate
  , a.CreationUserId
  , a.CreationDate
  , a.UpdatedUserId
  , a.UpdatedDate
  , a.PublishedDate
FROM
  Accounts@{FORCE_INDEX=IDX_Accounts_Status_Valid} a
  INNER JOIN Customers c
    ON a.CustomerId = c.CustomerId
    AND c.CustomerStatus = @customerStatusNormal
  INNER JOIN ItemBsInformations ib
    ON a.CompanyCode = ib.CompanyCode
    AND a.ItemCode = ib.ItemCode
  LEFT JOIN Offerings o
    ON a.OfferingId = o.OfferingId
    AND a.CompanyCode = o.CompanyCode
WHERE
  a.AccountManageKey = @accountManageKeyOrdinary
  AND
  a.AccountCreateDate <= @interestDateMaxTime
  AND (
    NOT EXISTS (
      SELECT
        *
      FROM
        AccountInterests acti
      WHERE
        a.AccountId = acti.AccountId
        AND acti.InterestDate = @interestDate
        AND acti.PaymentStatus = @paymentStatusPaid
    )
    OR (
      EXISTS (
        SELECT
          *
        FROM
          AccountTransactions ats
        WHERE
          a.AccountId = ats.AccountId
          AND ats.AccountingTime BETWEEN @interestDateMinTime AND @interestDateMaxTime
          AND ats.TransactionPatternCode = @TransactionPatternCodeInterestSettlement
          AND ats.TransactionPatternSubCode = @TransactionPatternSubCodeInterestSettlement
          AND DATE (TransactionTime) < DATE (AccountingTime)
      )
    )
  )
  AND NOT EXISTS (
    SELECT
      CancelRevivalType
    FROM
      (
        SELECT
          ac.CancelRevivalType
        FROM
          AccountCancelHistories ac
        WHERE
          a.accountId = ac.accountId
          AND ac.CreationDate <= @interestDateMaxTime
        ORDER BY
          ac.CreationDate DESC
        LIMIT
          1
      )
    where
      CancelRevivalType = @accountCancelCustomer
      OR CancelRevivalType = @accountCancelBankClerk
  )
   AND NOT EXISTS (
    SELECT
      1
    FROM
      AccountSuspensionCauses atsc
    WHERE
      a.AccountId = atsc.AccountId
      AND atsc.SuspensionFlag = @suspensionFlagOn
      AND atsc.SuspensionCausesCode = @accountDormant
  )
