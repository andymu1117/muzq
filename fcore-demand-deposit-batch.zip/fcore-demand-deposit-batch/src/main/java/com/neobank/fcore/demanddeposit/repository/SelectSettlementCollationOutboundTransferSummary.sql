### 仕向（振込）集計値

SELECT
  SUM(ATD.TransactionAmount) as Amount,
  COUNT(ATD.TransactionSlipId) as Number
--以下提供されたSQL


FROM
    OutboundTransfers AS OT
    INNER JOIN AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_GLCode_AccountTransactionDetails} AS ATD ON
        OT.TransactionSlipId = ATD.TransactionSlipId
    INNER JOIN
    (
        SELECT * FROM
        (
            SELECT
                ValueDate
                , CoreMoreTimeTypes.CoreMoreTimeType
                , AmPm
                , TIMESTAMP_ADD(TIMESTAMP(ValueDate, 'Japan'), INTERVAL FromHour HOUR) AS BeginDateTime
                , TIMESTAMP_ADD(TIMESTAMP(ValueDate, 'Japan'), INTERVAL ToHour HOUR) AS EndDateTime
                , TransferDate
            FROM
                UNNEST(GENERATE_DATE_ARRAY(@PreviousBusinessDate, @CurrentBusinessDate)) AS ValueDate
                CROSS JOIN (
                    SELECT '1' AS CoreMoreTimeType
                    UNION ALL SELECT '2') AS CoreMoreTimeTypes
                CROSS JOIN (
                    SELECT 'AM' AS AmPm, 0 AS FromHour, 12 AS ToHour
                    UNION ALL SELECT 'PM', 12, 24) AS AmPms
                CROSS JOIN UNNEST(GENERATE_DATE_ARRAY(@PreviousBusinessDate, @CurrentBusinessDate)) AS TransferDate
        ) AS Matrix
        WHERE
            (
                (ValueDate = @PreviousBusinessDate AND AmPm = 'PM')
            OR  (ValueDate > @PreviousBusinessDate AND ValueDate < @CurrentBusinessDate)
            OR  (ValueDate = @CurrentBusinessDate AND CoreMoreTimeType = '1')
            OR  (ValueDate = @CurrentBusinessDate AND CoreMoreTimeType = '2' AND AmPm = 'AM')
            )
            AND
            ((CoreMoreTimeType = '2' AND ValueDate = TransferDate)
            OR (CoreMoreTimeType = '1' AND TransferDate = @CurrentBusinessDate))
    ) AS VD ON
        -- 当日に残高は落ちるが翌コア発信になる場合があるので、振込日で抽出
        ATD.AccountingTime >= VD.BeginDateTime
        AND ATD.AccountingTime < VD.EndDateTime
        AND OT.TransferDate = VD.TransferDate
        AND OT.CoreMoreTimeType = VD.CoreMoreTimeType
    LEFT JOIN (
        SELECT
            DISTINCT CANCEL.BaseTransactionSlipId
        FROM
            AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_BaseTransactionSlipId_AccountTransactionDetails} AS CANCEL
        WHERE
            (   -- 他行振込仕向取消、口座解約取消（解約代わり金振込取消）
                (CANCEL.TransactionPatternCode = 'R002' AND CANCEL.TransactionPatternSubCode = '90')
                OR (CANCEL.TransactionPatternCode = 'A005' AND CANCEL.TransactionPatternSubCode = '92')
            )
            AND CANCEL.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan') -- TODO 時間の条件は要確認
            AND CANCEL.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
            -- AND ATD.TransactionSlipId = CANCEL.BaseTransactionSlipId
    ) AS CANCEL ON
      CANCEL.BaseTransactionSlipId = ATD.TransactionSlipId
WHERE
    ATD.GLCode = '017400000' -- 未決済為替借
    AND ATD.DrCrType = '2' -- Cr
    AND ATD.TransactionPatternCode = 'R002'
    AND ATD.TransactionPatternSubCode IN ('00','01','02','03','04','05')
    AND CANCEL.BaseTransactionSlipId is NULL
