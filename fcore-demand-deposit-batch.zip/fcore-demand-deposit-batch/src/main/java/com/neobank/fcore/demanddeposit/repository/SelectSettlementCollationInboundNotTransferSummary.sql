### 被仕向（振込以外） 集計値
SELECT
    SUM(TransactionAmount) AS Amount
    , COUNT(TransactionSlipId) AS Number
FROM
(
-- 以下提供のSQL


### 被仕向（振込以外）
-- 行内振替
SELECT
    ATD.TransactionSlipId
    , ATD.TransactionAmount
    , IT.AccManageNo AS ManagementNo
    , ATD.TransactionPatternCode
    , ATD.TransactionPatternSubCode
FROM
    InnerTransfers@{FORCE_INDEX=IDX_First_Hit_Column_TransactionSlipId_InnerTransfers} AS IT
    INNER JOIN AccountTransactionDetails@{FORCE_INDEX= IDX_First_Hit_Column_GLCode_AccountTransactionDetails} AS ATD ON
        IT.TransactionSlipId = ATD.TransactionSlipId
    LEFT JOIN
        (
        SELECT
            DISTINCT CANCEL.BaseTransactionSlipId
        FROM
            AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_BaseTransactionSlipId_AccountTransactionDetails} AS CANCEL
        WHERE
            -- 行内振替取消
            (CANCEL.TransactionPatternCode = 'A003' AND CANCEL.TransactionPatternSubCode = '90')
            AND CANCEL.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan') -- TODO 時間の条件は要確認
            AND CANCEL.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    ) AS CANCEL ON
      ATD.TransactionSlipId = CANCEL.BaseTransactionSlipId
WHERE
    ATD.GLCode = '052400000' -- 未決済為替貸
    AND ATD.DrCrType = '1' -- Dr
    AND ATD.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan')
    AND ATD.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    AND ATD.TransactionPatternCode = 'A003' AND ATD.TransactionPatternSubCode = '00'
    AND CANCEL.BaseTransactionSlipId is NULL

-- 他行仕向振込入金不能
UNION ALL
SELECT
    ATD.TransactionSlipId
    , ATD.TransactionAmount
    , IT.ZenginOperationServerManagementNo AS ManagementNo
    , ATD.TransactionPatternCode
    , ATD.TransactionPatternSubCode
FROM
    InboundTransfers AS IT
    INNER JOIN AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_GLCode_AccountTransactionDetails} AS ATD ON
        IT.TransactionSlipId = ATD.TransactionSlipId
    INNER JOIN
    (
        SELECT * FROM
        (
            SELECT
                ValueDate
                , CoreMoreTimeTypes.CoreMoreTimeType
                , AmPm
                , TIMESTAMP_ADD(TIMESTAMP(ValueDate, 'Japan'), INTERVAL FromHour HOUR) AS BeginDateTime
                , TIMESTAMP_ADD(TIMESTAMP(ValueDate, 'Japan'), INTERVAL ToHour HOUR) AS EndDateTime
            FROM
                UNNEST(GENERATE_DATE_ARRAY(@PreviousBusinessDate, @CurrentBusinessDate)) AS ValueDate
                CROSS JOIN (
                    SELECT '1' AS CoreMoreTimeType
                    UNION ALL SELECT '2') AS CoreMoreTimeTypes
                CROSS JOIN (
                    SELECT 'AM' AS AmPm, 0 AS FromHour, 12 AS ToHour
                    UNION ALL SELECT 'PM', 12, 24) AS AmPms
        ) AS Matrix
        WHERE
            (ValueDate = @PreviousBusinessDate AND CoreMoreTimeType = '2' AND AmPm = 'PM')
            OR  (ValueDate > @PreviousBusinessDate AND ValueDate < @CurrentBusinessDate)
            OR  (ValueDate = @CurrentBusinessDate AND CoreMoreTimeType = '1')
            OR  (ValueDate = @CurrentBusinessDate AND CoreMoreTimeType = '2' AND AmPm = 'AM')
    ) AS VD ON
        ATD.AccountingTime >= VD.BeginDateTime
        AND ATD.AccountingTime < VD.EndDateTime
        AND IT.CoreMoreTimeType = VD.CoreMoreTimeType
WHERE
    ATD.GLCode = '052400000' -- 未決済為替貸
    AND ATD.DrCrType = '1' -- Dr
    AND (
        (ATD.TransactionPatternCode = 'R004' AND ATD.TransactionPatternSubCode = '00')
        OR (ATD.TransactionPatternCode = 'R005' AND ATD.TransactionPatternSubCode = '00')
        OR (ATD.TransactionPatternCode = 'R007' AND ATD.TransactionPatternSubCode = '00')
        OR (ATD.TransactionPatternCode = 'A005' AND ATD.TransactionPatternSubCode = '90')
    )


-- 提供のSQL
)
