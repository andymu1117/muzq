package com.neobank.fcore.demanddeposit.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.grpc.Metadata;

import com.accenture.mainri.core.auth.IdToken;

public class GrpcUtils {
    private static final String X_ID_TOKEN_VALUE = "demanddeposit-scaleable-batch";
    private static final String API_VERSION_KEY = "x-grpc-api-version";
    private static final String ID_TOKEN_KEY = "X-Id-Token";

    private GrpcUtils() {
    }

    /**
     * gRPCのリクエストヘッダを作成する。
     *
     * @param apiVersion gRPCのAPIバージョン
     * @return リクエストヘッダ
     * @throws JsonProcessingException JSONの処理に失敗した場合のException
     */
    public static Metadata createGrpcHeaders(String apiVersion) throws JsonProcessingException {
        // APIバージョンKey
        Metadata.Key<String> apiVersionKey = Metadata.Key.of(API_VERSION_KEY, Metadata.ASCII_STRING_MARSHALLER);

        // Id Token Key、Value
        Metadata.Key<String> idTokenKey = Metadata.Key.of(ID_TOKEN_KEY, Metadata.ASCII_STRING_MARSHALLER);
        IdToken idToken = new IdToken();
        idToken.setSubject(X_ID_TOKEN_VALUE);

        // headersに設定
        Metadata headers = new Metadata();
        headers.put(apiVersionKey, apiVersion);
        headers.put(idTokenKey, GrpcUtils.serialize(idToken, false));
        return headers;
    }

    /**
     * Javaオブジェクト → JSON(文字列)変換。
     *
     * @param bean Javaオブジェクト
     * @param pp pretty print
     * @return JSON文字列
     * @throws JsonProcessingException JsonProcessingException
     */
    public static String serialize(Object bean, boolean pp) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        if (pp) {
            return mapper.writerWithDefaultPrettyPrinter()
                .writeValueAsString(bean);
        } else {
            return mapper.writeValueAsString(bean);
        }
    }
}
