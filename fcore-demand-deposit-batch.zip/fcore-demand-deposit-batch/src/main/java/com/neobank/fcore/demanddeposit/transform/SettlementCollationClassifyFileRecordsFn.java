package com.neobank.fcore.demanddeposit.transform;

import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode;
import com.neobank.fcore.demanddeposit.code.ZenginProcessCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.exception.SystemFailureException;

/**
 * 決済照合ファイルを(仕向/被仕向)(振込/振込以外)に分類する。
 */
@SuppressWarnings("serial")
public class SettlementCollationClassifyFileRecordsFn
    extends DoFn<KV<List<String>, SettlementCollationBase>, KV<List<String>, SettlementCollationFile>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationClassifyFileRecordsFn.class);

    private TupleTag<KV<List<String>, SettlementCollationFile>> fileResultOutboundTransferTag;
    private TupleTag<KV<List<String>, SettlementCollationFile>> fileResultOutboundNotTransferTag;
    private TupleTag<KV<List<String>, SettlementCollationFile>> fileResultInboundTransferTag;
    private TupleTag<KV<List<String>, SettlementCollationFile>> fileResultInboundNotTransferTag;

    private TupleTag<Integer> fileResultOutboundTransferBeforeSettlementNumTag;
    private TupleTag<Integer> fileResultOutboundNotTransferBeforeSettlementNumTag;
    private TupleTag<Integer> fileResultInboundTransferBeforeSettlementNumTag;
    private TupleTag<Integer> fileResultInboundNotTransferBeforeSettlementNumTag;

    /**
     * タグ受け渡し用のコンストラクタ。
     *
     * @param fileResultOutboundTransferTag 仕向振込を出力するためのタグ
     * @param fileResultOutboundNotTransferTag 仕向振込以外を出力するためのタグ
     * @param fileResultInboundTransferTag 被仕向振込を出力するためのタグ
     * @param fileResultInboundNotTransferTag 被仕向振込以外を出力するためのタグ
     * @param fileResultOutboundTransferBeforeSettlementNumTag 仕向振込の前営業日決済レコード数を出力するためのタグ
     * @param fileResultOutboundNotTransferBeforeSettlementNumTag 仕向振込以外の前営業日決済レコード数を出力するためのタグ
     * @param fileResultInboundTransferBeforeSettlementNumTag 被仕向振込の前営業日決済レコード数を出力するためのタグ
     * @param fileResultInboundNotTransferBeforeSettlementNumTag 被仕向振込以外の前営業日決済レコード数を出力するためのタグ
     */
    // 出力が8つ必要かつ、処理するレコード数が多いため、再実行は避けたい。
    @java.lang.SuppressWarnings("squid:S00107")
    public SettlementCollationClassifyFileRecordsFn(
        TupleTag<KV<List<String>, SettlementCollationFile>> fileResultOutboundTransferTag,
        TupleTag<KV<List<String>, SettlementCollationFile>> fileResultOutboundNotTransferTag,
        TupleTag<KV<List<String>, SettlementCollationFile>> fileResultInboundTransferTag,
        TupleTag<KV<List<String>, SettlementCollationFile>> fileResultInboundNotTransferTag,
        TupleTag<Integer> fileResultOutboundTransferBeforeSettlementNumTag,
        TupleTag<Integer> fileResultOutboundNotTransferBeforeSettlementNumTag,
        TupleTag<Integer> fileResultInboundTransferBeforeSettlementNumTag,
        TupleTag<Integer> fileResultInboundNotTransferBeforeSettlementNumTag) {
        this.fileResultOutboundTransferTag = fileResultOutboundTransferTag;
        this.fileResultOutboundNotTransferTag = fileResultOutboundNotTransferTag;
        this.fileResultInboundTransferTag = fileResultInboundTransferTag;
        this.fileResultInboundNotTransferTag = fileResultInboundNotTransferTag;
        this.fileResultOutboundTransferBeforeSettlementNumTag = fileResultOutboundTransferBeforeSettlementNumTag;
        this.fileResultOutboundNotTransferBeforeSettlementNumTag = fileResultOutboundNotTransferBeforeSettlementNumTag;
        this.fileResultInboundTransferBeforeSettlementNumTag = fileResultInboundTransferBeforeSettlementNumTag;
        this.fileResultInboundNotTransferBeforeSettlementNumTag = fileResultInboundNotTransferBeforeSettlementNumTag;
    }

    /**
     * 決済照合ファイルを(仕向/被仕向)(振込/振込以外)に分類する。
     *
     * @param target 処理対象のデータ
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, SettlementCollationBase> target, ProcessContext context) {
        SettlementCollationFile targetFile = (SettlementCollationFile) target.getValue();
        context.output(this.judgeOutputTag(targetFile), KV.of(target.getKey(), targetFile));
        this.outputNum(targetFile, context);
    }

    /**
     * レコードを分類し、レコード数を出力する。 ファイルの件数データはDBに存在しない前営業日決済レコードの数のみ利用する。
     *
     * @param targetFile 処理対象のデータ
     * @param context コンテキスト
     * @return 前営業日決済レコード数出力タグ
     */
    private TupleTag<KV<List<String>, SettlementCollationFile>> judgeOutputTag(SettlementCollationFile targetFile) {

        if (targetFile.getZenginProcessCode()
            .equals(ZenginProcessCode.OUTBOUND_TRANSFER.getCode())) {
            if (CommunicationTypeCode.isTransferTarget(targetFile.getCommunicationTypeCode())) {
                LOGGER.debug("transferTarget fileResultOutboundTransferTag:{}", targetFile);
                return fileResultOutboundTransferTag;
            } else if (CommunicationTypeCode.isChangeTarget(targetFile.getCommunicationTypeCode())) {
                LOGGER.debug("changeTarget fileResultOutboundNotTransferTag:{}", targetFile);
                return fileResultOutboundNotTransferTag;
            } else if (CommunicationTypeCode.isBillingTarget(targetFile.getCommunicationTypeCode())) {
                LOGGER.debug("billingTarget fileResultInboundNotTransferTag:{}", targetFile);
                return fileResultInboundNotTransferTag;
            } else {
                LOGGER.debug("otherTarget fileResultOutboundNotTransferTag:{}", targetFile);
                return fileResultOutboundNotTransferTag;
            }
        } else if (targetFile.getZenginProcessCode()
            .equals(ZenginProcessCode.INBOUND_TRANSFER.getCode())) {
            if (CommunicationTypeCode.isTransferTarget(targetFile.getCommunicationTypeCode())) {
                LOGGER.debug("transferTarget fileResultInboundTransferTag:{}", targetFile);
                return fileResultInboundTransferTag;
            } else if (CommunicationTypeCode.isChangeTarget(targetFile.getCommunicationTypeCode())) {
                LOGGER.debug("changeTarget fileResultInboundNotTransferTag:{}", targetFile);
                return fileResultInboundNotTransferTag;
            } else if (CommunicationTypeCode.isBillingTarget(targetFile.getCommunicationTypeCode())) {
                LOGGER.debug("billingTarget fileResultOutboundNotTransferTag:{}", targetFile);
                return fileResultOutboundNotTransferTag;
            } else {
                LOGGER.debug("otherTarget fileResultInboundNotTransferTag:{}", targetFile);
                return fileResultInboundNotTransferTag;
            }
        } else {
            throw new SystemFailureException("invalid zenginProcessCode");
        }
    }

    /**
     * レコードを分類し、出力タグを返却する。
     *
     * @param targetFile 処理対象のデータ
     * @param context コンテキスト
     * @return レコード数出力タグ
     */
    private void outputNum(SettlementCollationFile targetFile, ProcessContext context) {

        if (targetFile.getZenginProcessCode()
            .equals(ZenginProcessCode.OUTBOUND_TRANSFER.getCode())) {
            this.outputOutboundNum(targetFile, context);
        } else if (targetFile.getZenginProcessCode()
            .equals(ZenginProcessCode.INBOUND_TRANSFER.getCode())) {
            this.outputInboundNum(targetFile, context);
        } else {
            throw new SystemFailureException("invalid zenginProcessCode");
        }
    }

    private void outputOutboundNum(SettlementCollationFile targetFile, ProcessContext context) {
        if (CommunicationTypeCode.isTransferTarget(targetFile.getCommunicationTypeCode())
            && CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultOutboundTransferBeforeSettlementNumTag, 1);
        } else if (CommunicationTypeCode.isChangeTarget(targetFile.getCommunicationTypeCode())
            && CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultOutboundNotTransferBeforeSettlementNumTag, 1);
        } else if (CommunicationTypeCode.isBillingTarget(targetFile.getCommunicationTypeCode())
            && CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultInboundNotTransferBeforeSettlementNumTag, 1);
        } else if (CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            LOGGER.debug("otherTarget fileResultOutboundNotTransferTag:{}", targetFile);
            context.output(fileResultOutboundNotTransferBeforeSettlementNumTag, 1);
        }
    }

    private void outputInboundNum(SettlementCollationFile targetFile, ProcessContext context) {
        if (CommunicationTypeCode.isTransferTarget(targetFile.getCommunicationTypeCode())
            && CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultInboundTransferBeforeSettlementNumTag, 1);
        } else if (CommunicationTypeCode.isChangeTarget(targetFile.getCommunicationTypeCode())
            && CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultInboundNotTransferBeforeSettlementNumTag, 1);
        } else if (CommunicationTypeCode.isBillingTarget(targetFile.getCommunicationTypeCode())
            && CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultOutboundNotTransferBeforeSettlementNumTag, 1);
        } else if (CommunicationTypeCode.isBeforeSettlementTarget(targetFile.getCommunicationTypeCode())) {
            context.output(fileResultInboundNotTransferBeforeSettlementNumTag, 1);
        }
    }
}
