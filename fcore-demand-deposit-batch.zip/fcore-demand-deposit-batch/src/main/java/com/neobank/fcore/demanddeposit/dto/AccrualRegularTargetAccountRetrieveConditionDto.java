package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;
import java.util.Objects;

@SuppressWarnings("serial")
public class AccrualRegularTargetAccountRetrieveConditionDto implements Serializable {
    // 利息基準日（yyyyMMddフォーマットの文字列）
    private String interestDateWithoutHyphen;
    // 利息基準日（当日の最後の時間の文字列）
    private String interestDateTodayMaxTime;

    /**
     * 利息決算元加処理対象口座抽出条件エンティティのコンストラクタ。
     *
     * @param interestDateWithoutHyphen 利息基準日（yyyyMMddフォーマットの文字列）
     * @param interestDateTodayMaxTime 利息基準日（当日の最後の時間の文字列）
     */
    public AccrualRegularTargetAccountRetrieveConditionDto(String interestDateWithoutHyphen,
        String interestDateTodayMaxTime) {
        this.interestDateWithoutHyphen = interestDateWithoutHyphen;
        this.interestDateTodayMaxTime = interestDateTodayMaxTime;
    }

    public String getInterestDateWithoutHyphen() {
        return interestDateWithoutHyphen;
    }

    public String getInterestDateTodayMaxTime() {
        return interestDateTodayMaxTime;
    }

    @Override
    public int hashCode() {
        return Objects.hash(interestDateTodayMaxTime, interestDateWithoutHyphen);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AccrualRegularTargetAccountRetrieveConditionDto)) {
            return false;
        }
        AccrualRegularTargetAccountRetrieveConditionDto other = (AccrualRegularTargetAccountRetrieveConditionDto) obj;
        return Objects.equals(interestDateTodayMaxTime, other.interestDateTodayMaxTime)
            && Objects.equals(interestDateWithoutHyphen, other.interestDateWithoutHyphen);
    }
}
