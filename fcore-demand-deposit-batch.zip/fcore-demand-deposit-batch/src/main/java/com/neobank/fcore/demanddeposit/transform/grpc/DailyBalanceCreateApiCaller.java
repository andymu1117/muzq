package com.neobank.fcore.demanddeposit.transform.grpc;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.io.GrpcConnector;

import com.neobank.fcore.demanddeposit.dto.DailyBalanceCreateResponseDto;
import com.neobank.fcore.demanddeposit.dto.ErrorLogEntryDto;
import com.neobank.fcore.demanddeposit.entity.AccountEntity;
import com.neobank.fcore.demanddeposit.grpc.GrpcErrorParser;
import com.neobank.fcore.demanddeposit.grpc.GrpcMetaBuilder;
import com.neobank.fcore.demanddeposit.grpc.GrpcSystemException;
import com.neobank.fcore.demanddeposit.grpc.GrpcValidationException;
import com.neobank.fcore.demanddeposit.pb.command.CommandVersion;
import com.neobank.fcore.demanddeposit.pb.command.DailyBalanceCommandGrpc;
import com.neobank.fcore.demanddeposit.pb.command.DailyBalanceCommandGrpc.DailyBalanceCommandBlockingStub;
import com.neobank.fcore.demanddeposit.pb.command.message.DailyBalanceCalculateRequest;
import com.neobank.fcore.demanddeposit.pb.command.message.DailyBalanceCalculateResponse;
import com.neobank.fcore.demanddeposit.pipeline.options.DailyBalanceCreateOption;
import com.neobank.fcore.demanddeposit.utils.OffsetDateTimeUtils;

@SuppressWarnings("serial")
public class DailyBalanceCreateApiCaller extends DoFn<AccountEntity, DailyBalanceCreateResponseDto> {
    private static final Logger LOGGER = LoggerFactory.getLogger(DailyBalanceCreateApiCaller.class);
    private GrpcConnector grpcConnector;
    private transient DailyBalanceCommandBlockingStub stub;
    private TupleTag<DailyBalanceCreateResponseDto> successTag;
    private TupleTag<ErrorLogEntryDto> errorTag;
    private TupleTag<ErrorLogEntryDto> warnTag;

    /**
     * エラーハンドリング用のタグとgRPC用の接続を設定するコンストラクタ。
     *
     * @param grpcConnector gRPCのコネクタ
     * @param successTag 正常時の出力先
     * @param errorTag エラー時の出力先
     * @param warnTag 警告時の出力先
     */
    public DailyBalanceCreateApiCaller(GrpcConnector grpcConnector, TupleTag<DailyBalanceCreateResponseDto> successTag,
        TupleTag<ErrorLogEntryDto> errorTag, TupleTag<ErrorLogEntryDto> warnTag) {
        super();
        this.grpcConnector = grpcConnector;
        this.successTag = successTag;
        this.errorTag = errorTag;
        this.warnTag = warnTag;
    }

    /**
     * gRPCクライアント初期化。
     * 
     * @throws JsonProcessingException Json実施中異常
     */
    @Setup
    public void setup() throws JsonProcessingException {
        LOGGER.debug("SetUp Stub.");
        stub = DailyBalanceCommandGrpc.newBlockingStub(grpcConnector.createManagedChannel());
        // TODO gRPCヘッダ増殖問題の一時対応、アーキから恒久対策をもらったら再対応する予定
        // リクエストヘッダの設定
        GrpcMetaBuilder metaBuilder = new GrpcMetaBuilder().apiVersion(CommandVersion.API_VERSION)
            .token("CBT001F");
        stub = MetadataUtils.attachHeaders(stub, metaBuilder.getHeaders());
    }

    /**
     * 日次残高計算API実行部分。
     *
     * @param element 実行対象のデータ
     * @param context 処理のコンテキスト
     * @throws JsonProcessingException JSON処理異常
     */
    @ProcessElement
    public void processElement(@Element AccountEntity element, ProcessContext context) throws JsonProcessingException {
        DailyBalanceCreateOption options = context.getPipelineOptions()
            .as(DailyBalanceCreateOption.class);
        DailyBalanceCalculateResponse response = null;
        OffsetDateTimeUtils offsetDateTimeUtils = new OffsetDateTimeUtils(options);
        OffsetDateTime processDate = offsetDateTimeUtils.parserStringDateAsMaxOffsetTime(options.getProcessDate()
            .get());
        String balanceDate = offsetDateTimeUtils.formatOffsetDateTimeToIso8601(processDate.minusDays(1));
        LOGGER.debug("request params: accountId {} ; balanceDate: {}", element.getAccountId(), balanceDate);
        DailyBalanceCalculateRequest request = convertToRequest(element, balanceDate);
        long startTimeMillis = System.currentTimeMillis();
        try {
            response = stub.calculate(request);
        } catch (StatusRuntimeException sEx) {
            try {
                GrpcErrorParser.parseErrorResponse(sEx);
            } catch (GrpcSystemException sysEx) {
                ErrorLogEntryDto errorLogEntry = new ErrorLogEntryDto(element, sysEx);
                context.output(errorTag, errorLogEntry);
                LOGGER.error("api request error: {}", errorLogEntry, sysEx);
                return;
            } catch (GrpcValidationException valEx) {
                ErrorLogEntryDto errorLogEntry = new ErrorLogEntryDto(element, valEx);
                context.output(warnTag, errorLogEntry);
                LOGGER.warn("api request warn: {}", errorLogEntry, valEx);
                return;
            }
            // GRPC呼び出し処理にどのエラーが発生してもキャッチできるようにExceptionをキャッチするようにする
        } catch (Exception ex) {
            ErrorLogEntryDto errorLogEntry = new ErrorLogEntryDto(element, ex);
            context.output(errorTag, errorLogEntry);
            LOGGER.error("api request error: {}", errorLogEntry, ex);
            return;
        }
        long processingTimeMillis = System.currentTimeMillis() - startTimeMillis;
        LOGGER.debug("[Processing Time] The processing time of the Daily Balance Calculate API is {} ms.",
            processingTimeMillis);

        DailyBalanceCreateResponseDto result = new DailyBalanceCreateResponseDto(response);
        context.output(successTag, result);
        LOGGER.debug("response: {}", result);
    }

    /**
     * 口座情報を日次残高計算APIのリクエストに変換。
     *
     * @param element 口座情報
     * @param balanceDate 日次残高基準日
     * @return 日次残高計算APIのリクエスト
     */
    private DailyBalanceCalculateRequest convertToRequest(AccountEntity element, String balanceDate) {
        return DailyBalanceCalculateRequest.newBuilder()
            .setAccountId(element.getAccountId())
            .setBalanceDate(balanceDate)
            .build();
    }
}
