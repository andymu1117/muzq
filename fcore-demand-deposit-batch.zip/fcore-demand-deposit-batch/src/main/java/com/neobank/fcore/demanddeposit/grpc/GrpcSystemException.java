package com.neobank.fcore.demanddeposit.grpc;

import java.util.ArrayList;
import java.util.List;

/**
 * GRPCから {@code SYSTEM_ERROR} がレスポンスされたことを示す例外。
 */
@SuppressWarnings("serial")
public class GrpcSystemException extends RuntimeException {
    private final transient String errorTitle;
    private final transient List<GrpcGlobalError> globalErrors = new ArrayList<>();

    public GrpcSystemException() {
        super();
        this.errorTitle = "";
    }

    public GrpcSystemException(String message) {
        super(message);
        this.errorTitle = "";
    }

    public GrpcSystemException(Throwable cause) {
        super(cause);
        this.errorTitle = "";
    }

    public GrpcSystemException(String message, Throwable cause) {
        super(message, cause);
        this.errorTitle = "";
    }

    /**
     * コンストラクタ。
     *
     * @param errorTitle エラータイトル
     * @param gerrors 相関・業務チェックエラー
     */
    public GrpcSystemException(String errorTitle, List<GrpcGlobalError> gerrors) {
        super(errorTitle);
        this.errorTitle = errorTitle;
        if (gerrors != null) {
            this.globalErrors.addAll(gerrors);
        }
    }

    public String getErrorTitle() {
        return errorTitle;
    }

    public List<GrpcGlobalError> getGrpcGlobalErrors() {
        return globalErrors;
    }
}
