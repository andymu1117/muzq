package com.neobank.fcore.demanddeposit.transform.mutation;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.TransactionContext;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.mutation.EntityToMutationConverter;
import com.accenture.mainri.core.converter.spanner.mutation.EntityToMutationConverter.Operation;
import com.accenture.mainri.core.date.DateTimeUtils;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.entity.SettlementCollationPending;
import com.neobank.fcore.demanddeposit.exception.SystemFailureException;
import com.neobank.fcore.demanddeposit.pb.query.PublicHolidayQueryForOperationGrpc;
import com.neobank.fcore.demanddeposit.pb.query.PublicHolidayQueryForOperationGrpc.PublicHolidayQueryForOperationBlockingStub;
import com.neobank.fcore.demanddeposit.pb.query.QueryVersion;
import com.neobank.fcore.demanddeposit.pb.query.message.PublicHolidayCalculateBusinessDateRequest;
import com.neobank.fcore.demanddeposit.pb.query.message.PublicHolidayCalculateBusinessDateResponse;
import com.neobank.fcore.demanddeposit.pipeline.SettlementCollationPipeline;
import com.neobank.fcore.demanddeposit.utils.DateUtils;
import com.neobank.fcore.demanddeposit.utils.GrpcUtils;

/**
 * 保留対象のファイルをDBへ登録する。
 */
@SuppressWarnings("serial")
public class SettlementCollationResisterPendingFn
    extends DoFn<KV<List<String>, SettlementCollationBase>, KV<List<String>, SettlementCollationBase>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationResisterPendingFn.class);

    private transient DatabaseClient dbClient;
    private transient Spanner spanner;

    private SpannerDriver spannerDriver;
    private ValueProvider<String> targetDateProvider;
    private GrpcConnector grpcConnector;

    private DateTimeUtils dateTimeUtils;
    private EntityToMutationConverter converter = new EntityToMutationConverter();

    private List<LocalDate> workDaysUntilNext5 = new ArrayList<>();

    private transient PublicHolidayQueryForOperationBlockingStub stub;

    /**
     * 値設定用のコンストラクタ。
     *
     * @param spannerDriver SpannerDriver
     * @param grpcConnector grpcConnector
     * @param dateTimeUtils dateTimeUtils
     * @param targetDateProvider 対象日付
     */
    public SettlementCollationResisterPendingFn(SpannerDriver spannerDriver, GrpcConnector grpcConnector,
        DateTimeUtils dateTimeUtils, ValueProvider<String> targetDateProvider) {
        this.spannerDriver = spannerDriver;
        this.dateTimeUtils = dateTimeUtils;
        this.targetDateProvider = targetDateProvider;
        this.grpcConnector = grpcConnector;
    }

    /**
     * 初期処理（DB）。
     */
    @Setup
    public void setUp() {
        this.spanner = this.spannerDriver.createService();
        this.dbClient = this.spannerDriver.createDatabaseClient(this.spanner);
    }

    /**
     * 営業日や接続などを事前設定。
     */
    @StartBundle
    public void startBundle() {
        // stub, channelともにThreadsafeのためstubはここでキャッシュ。
        stub = PublicHolidayQueryForOperationGrpc.newBlockingStub(grpcConnector.createManagedChannel());
        if (workDaysUntilNext5.isEmpty()) {
            workDaysUntilNext5.add(DateUtils.parseIso8601WithoutHyphenToLocalDate(targetDateProvider.get()));
            workDaysUntilNext5.add(DateUtils.parseIso8601ToLocalDate(getWorkDay(1)));
            workDaysUntilNext5.add(DateUtils.parseIso8601ToLocalDate(getWorkDay(2)));
            workDaysUntilNext5.add(DateUtils.parseIso8601ToLocalDate(getWorkDay(3)));
            workDaysUntilNext5.add(DateUtils.parseIso8601ToLocalDate(getWorkDay(4)));
            workDaysUntilNext5.add(DateUtils.parseIso8601ToLocalDate(getWorkDay(5)));
        }
    }

    /**
     * 保留対象のファイルをDBへ登録する。
     *
     * @param target 保留対象のファイル
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, SettlementCollationBase> target, ProcessContext context) {

        SettlementCollationPending registerTarget = new SettlementCollationPending(
            SettlementCollationPipeline.DATABASE_USER_ID, (SettlementCollationFile) target.getValue(), dateTimeUtils);

        if (CommunicationTypeCode.isBeforeSettlementTarget(registerTarget.getCommunicationTypeCode())) {
            registerTarget.setSettlementDate(DateUtils.parseIso8601WithoutHyphenToLocalDate(targetDateProvider.get()));
            for (
                // 実行日から
                int counter = 0;
                // 振込予定日が同じ日になったらループをやめる(振込予定日-1営業日でループをやめる)
                !(registerTarget.getTransferDate() // ループを実行する条件なので、NOTにする
                    .isEqual(workDaysUntilNext5.get(counter))
                    // 念の為、振込予定日が前になったらループをやめる。(本来営業日しか設定されないので、入らないが直近営業日-1となるようにする)
                    || registerTarget.getTransferDate()
                        .isBefore(workDaysUntilNext5.get(counter)));
                // カウンターを増やす
                counter++) {
                // 過去から順に設定していく
                registerTarget.setSettlementDate(workDaysUntilNext5.get(counter));
            }
        } else {
            registerTarget.setSettlementDate(registerTarget.getTransferDate());
        }

        this.spannerDriver.write(dbClient, (TransactionContext tx) -> {
            List<Mutation> mutations = new ArrayList<>();
            EntityToMutationConverter.Metadata metadata = new EntityToMutationConverter.Metadata(Operation.INSERT);
            OffsetDateTime now = dateTimeUtils.now();
            registerTarget.setCreationDate(now);
            registerTarget.setUpdatedDate(now);
            mutations.add(converter.convert(registerTarget, metadata));

            tx.buffer(mutations);
        });
    }

    /**
     * 指定した数値を足した営業日を取得する。
     *
     * @param workDays 足す日数
     * @return 算出された営業日
     */
    private String getWorkDay(int workDays) {
        PublicHolidayCalculateBusinessDateRequest grpcRequest = PublicHolidayCalculateBusinessDateRequest.newBuilder()
            .setTargetDate(DateUtils.parseIso8601WithoutHyphenToLocalDate(targetDateProvider.get())
                .toString())
            .setDays(workDays)
            .build();
        PublicHolidayCalculateBusinessDateResponse grpcResponse = null;

        try {
            stub = MetadataUtils.attachHeaders(stub, GrpcUtils.createGrpcHeaders(QueryVersion.API_VERSION));
        } catch (JsonProcessingException e) {
            throw new SystemFailureException(e);
        }
        try {
            grpcResponse = stub.calculateBusinessDate(grpcRequest);
        } catch (RuntimeException e) {
            LOGGER.error("grpc request failed, Request:{}", grpcRequest);
            throw e;
        }

        if (grpcResponse != null) {
            return grpcResponse.getBusinessDate();
        } else {
            LOGGER.error("grpc request failed, Request:{}", grpcRequest);
            throw new SystemFailureException("grpc request failed");
        }
    }

    /**
     * DB接続を閉じる。
     */
    @Teardown
    public void tearDown() {
        this.spanner.close();
    }
}
