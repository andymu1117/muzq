package com.neobank.fcore.demanddeposit.pipeline;

import java.time.OffsetDateTime;
import java.util.List;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.date.DateTimeUtils;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.dto.CustomerAdvantageConditionUpdateErrorEntryDto;
import com.neobank.fcore.demanddeposit.dto.CustomerAdvantageConditionUpdateResponseDto;
import com.neobank.fcore.demanddeposit.entity.CustomerAdvantageConditionEntity;
import com.neobank.fcore.demanddeposit.pipeline.options.CustomerAdvantageConditionUpdateOptions;
import com.neobank.fcore.demanddeposit.transform.CombineCustomerAdvantageConditionFn;
import com.neobank.fcore.demanddeposit.transform.CustomerAdvantageConditionEntityConverterFn;
import com.neobank.fcore.demanddeposit.transform.CustomerAdvantageConditionFlatFn;
import com.neobank.fcore.demanddeposit.transform.CustomerAdvantageConditionResponseConvertFn;
import com.neobank.fcore.demanddeposit.transform.GoogleCloudStorageByteReaderFn;
import com.neobank.fcore.demanddeposit.transform.grpc.CustomerAdvantageConditionUpdateApiCaller;
import com.neobank.fcore.demanddeposit.transform.writer.CloudStorageFileUploadFn;
import com.neobank.fcore.demanddeposit.utils.DemandDepositGrpcPropertyUtil;

/**
 * CustomerAdvantageConditionUpdate 顧客優遇条件更新バッチ [--pipelineName=customer-advantage-condition-update
 * --inputFile=gs://bucket/folder/file --outputFile=gs://bucket/folder/file]。
 * 入力ファイルサンプル://gcp_sample_bucket/test/customerAdvantageConditionUpdateInput.csv
 * 出力ファイルサンプル://gcp_sample_bucket/test/customerAdvantageConditionUpdateOutput.csv
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "customer-advantage-condition-update",
    optionClass = CustomerAdvantageConditionUpdateOptions.class)
public class CustomerAdvantageConditionUpdatePipeline
    extends PipelineTemplate<CustomerAdvantageConditionUpdateOptions> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerAdvantageConditionUpdatePipeline.class);

    @Override
    public PipelineResult run(CustomerAdvantageConditionUpdateOptions options) {
        LOGGER.info("customer advantage condition update - start");
        // パイプラインを準備する
        Pipeline pipeline = Pipeline.create(options);

        DateTimeUtils dateTimeUtils = new DateTimeUtils(options);

        // CSVの顧客優遇条件を取得する
        PCollection<List<String>> customerAdvantageCondition = readCustomerAdvantageCondition(pipeline, options);

        // 顧客優遇条件情報を変換する
        PCollection<CustomerAdvantageConditionEntity> customerAdvantageConditionEntity =
            groupCustomerAdvantageConditionEntityByIndex(dateTimeUtils.now(), customerAdvantageCondition);

        // 顧客優遇条件更新API実行
        PCollection<CustomerAdvantageConditionUpdateResponseDto> customerAdvantageConditionUpdateResponseDto =
            updateCustomerAdvantageCondition(customerAdvantageConditionEntity, options);

        // 実行結果をGoogle Cloud Storage上のファイルに書き込む
        writeCustomerAdvantageConditionUpdateResponse(customerAdvantageConditionUpdateResponseDto, options);

        LOGGER.info("customer advantage condition update - end");
        // パイプラインを実行する
        return pipeline.run();
    }

    /**
     * バッチ実行CSVの顧客優遇条件を取得する。
     *
     * @param pipeline pipelineのインスタンス
     * @param options アクセス用のoptions
     * @return 処理対象抽出条件のPCollection
     */
    private PCollection<List<String>> readCustomerAdvantageCondition(Pipeline pipeline,
        final CustomerAdvantageConditionUpdateOptions options) {

        return pipeline
            // Google Cloud Storageよりファイルを読み込む（バイナリ形式）
            .apply("Read File Path", Create.ofProvider(options.getInputFile(), StringUtf8Coder.of()))
            .apply("Convert data", ParDo.of(new GoogleCloudStorageByteReaderFn()));
    }

    /**
     * 顧客優遇条件情報をグループに変換する。
     *
     * @param updatedTime 更新時間
     * @param customerAdvantageCondition 顧客優遇条件情報
     * @return 処理結果のPCollection
     */
    private PCollection<CustomerAdvantageConditionEntity> groupCustomerAdvantageConditionEntityByIndex(
        OffsetDateTime updatedTime, PCollection<List<String>> customerAdvantageCondition) {
        // 顧客優遇条件がKV<Integer, String>を変換する（K：番号 V:顧客優遇条件情報CSV）
        return customerAdvantageCondition
            .apply("convert customerAdvantageCondition to KV<Integer, String>",
                ParDo.of(new CustomerAdvantageConditionFlatFn()))
            .apply("GroupByKey", GroupByKey.create())
            .apply(ParDo.of(new CustomerAdvantageConditionEntityConverterFn(updatedTime)));
    }

    /**
     * 顧客優遇条件更新API実行。
     *
     * @param selectResult 顧客優遇条件情報
     * @param options アクセス用のoptions
     * @return 処理結果のPCollection
     */
    private PCollection<CustomerAdvantageConditionUpdateResponseDto> updateCustomerAdvantageCondition(
        PCollection<CustomerAdvantageConditionEntity> customerAdvantageConditionEntity,
        CustomerAdvantageConditionUpdateOptions options) {
        final TupleTag<CustomerAdvantageConditionUpdateResponseDto> successTag =
            new TupleTag<CustomerAdvantageConditionUpdateResponseDto>() {};
        final TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto> errorTag =
            new TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto>() {};
        final TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto> warnTag =
            new TupleTag<CustomerAdvantageConditionUpdateErrorEntryDto>() {};
        PCollectionTuple apiResult = customerAdvantageConditionEntity.apply(ParDo
            .of(new CustomerAdvantageConditionUpdateApiCaller(
                new GrpcConnector(DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceHost(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServicePort(options),
                    DemandDepositGrpcPropertyUtil.isTlsEnabledForGrpcDemandDepositService(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceVersion(options)),
                successTag, errorTag, warnTag))
            .withOutputTags(successTag, TupleTagList.of(errorTag)
                .and(warnTag)));
        // warn、errorが発生する際に、ログ出力だけをするので、warnTagとerrorTagに対する処理が不要
        return apiResult.get(successTag);
    }

    /**
     * 実行結果をGoogle Cloud Storage上のファイルに書き込む。
     *
     * @param responseDto 顧客優遇条件処理結果
     * @param options アクセス用のoptions
     */
    private void writeCustomerAdvantageConditionUpdateResponse(
        PCollection<CustomerAdvantageConditionUpdateResponseDto> responseDto,
        CustomerAdvantageConditionUpdateOptions options) {
        responseDto.apply(ParDo.of(new CustomerAdvantageConditionResponseConvertFn()))
            .apply("Combine.globally", Combine.globally(new CombineCustomerAdvantageConditionFn()))
            .apply("Write File", ParDo.of(new CloudStorageFileUploadFn(options.getOutputFile()
                .get())));
    }

}
