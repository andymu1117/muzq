package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;
import java.util.Objects;

@SuppressWarnings("serial")
public class DailyBalanceTargetAccountRetrieveConditionDto implements Serializable {
    // 日次残高基準日（yyyyMMddフォーマットの文字列）
    private String balanceDateWithoutHyphen;
    // 日次残高基準日（当日の最後の時間の文字列）
    private String balanceDateTodayMaxTime;

    /**
     * 日次残高確定処理対象口座抽出条件エンティティのコンストラクタ。
     *
     * @param balanceDateWithoutHyphen 日次残高基準日（yyyyMMddフォーマットの文字列）
     * @param balanceDateTodayMaxTime 日次残高基準日（当日の最後の時間の文字列）
     */
    public DailyBalanceTargetAccountRetrieveConditionDto(String balanceDateWithoutHyphen,
        String balanceDateTodayMaxTime) {
        this.balanceDateWithoutHyphen = balanceDateWithoutHyphen;
        this.balanceDateTodayMaxTime = balanceDateTodayMaxTime;
    }

    public String getBalanceDateWithoutHyphen() {
        return balanceDateWithoutHyphen;
    }

    public String getBalanceDateTodayMaxTime() {
        return balanceDateTodayMaxTime;
    }

    @Override
    public int hashCode() {
        return Objects.hash(balanceDateTodayMaxTime, balanceDateWithoutHyphen);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof DailyBalanceTargetAccountRetrieveConditionDto)) {
            return false;
        }
        DailyBalanceTargetAccountRetrieveConditionDto other = (DailyBalanceTargetAccountRetrieveConditionDto) obj;
        return Objects.equals(balanceDateTodayMaxTime, other.balanceDateTodayMaxTime)
            && Objects.equals(balanceDateWithoutHyphen, other.balanceDateWithoutHyphen);
    }
}
