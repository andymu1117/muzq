package com.neobank.fcore.demanddeposit.code;

/**
 * 大口取引フラグ。
 *
 */
public enum LargeValueTransactionFlag {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:1552] 大口フラグ
    NO("0"), YES("1");
    // --- Generated Code Ends---

    private String code;

    LargeValueTransactionFlag(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
