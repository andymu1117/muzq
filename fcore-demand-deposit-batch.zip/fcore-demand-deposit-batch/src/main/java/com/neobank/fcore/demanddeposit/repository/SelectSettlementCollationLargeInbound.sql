### ニュウキン
SELECT
    COUNT(ATD.TransactionSlipId) AS Number
    , SUM(ATD.TransactionAmount) AS Amount
FROM
    AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_GLCode_AccountTransactionDetails} AS ATD
    LEFT JOIN
      (
        SELECT
            DISTINCT CANCEL.BaseTransactionSlipId
        FROM
            AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_BaseTransactionSlipId_AccountTransactionDetails} AS CANCEL
        WHERE
            -- 行内振替取消
            (CANCEL.TransactionPatternCode = 'A003' AND CANCEL.TransactionPatternSubCode = '90')
            AND CANCEL.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan') -- TODO 時間の条件は要確認
            AND CANCEL.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    )AS CANCEL ON
      ATD.TransactionSlipId = CANCEL.BaseTransactionSlipId
WHERE
    ATD.GLCode = '031100000' -- 日銀預け金（1億円以上）
    AND ATD.DrCrType = '1' -- Dr
    AND ATD.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan')
    AND ATD.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    AND (
            (ATD.TransactionPatternCode = 'R003' AND ATD.TransactionPatternSubCode = '00')
            OR (ATD.TransactionPatternCode = 'R004' AND ATD.TransactionPatternSubCode = '00')
            OR (ATD.TransactionPatternCode = 'R005' AND ATD.TransactionPatternSubCode = '00')
            OR (ATD.TransactionPatternCode = 'R007' AND ATD.TransactionPatternSubCode = '00')
            OR (ATD.TransactionPatternCode = 'R007' AND ATD.TransactionPatternSubCode = '01')
            OR (ATD.TransactionPatternCode = 'R008' AND ATD.TransactionPatternSubCode = '00')
            OR (ATD.TransactionPatternCode = 'A005' AND ATD.TransactionPatternSubCode = '90')
            OR (ATD.TransactionPatternCode = 'A003' AND ATD.TransactionPatternSubCode = '00')
        )
    AND CANCEL.BaseTransactionSlipId is NULL
