package com.neobank.fcore.demanddeposit.entity;

import java.io.Serializable;

import com.accenture.mainri.core.entity.BaseEntity;

@SuppressWarnings("serial")
public class AccountEntity extends BaseEntity implements Serializable {
    // 預金口座ID
    private String accountId;
    // 顧客ID
    private String customerId;
    // 口座科目
    private String accountManageKey;
    // 口座番号
    private String accountNo;
    // 顧客番号
    private String customerNo;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAccountManageKey() {
        return accountManageKey;
    }

    public void setAccountManageKey(String accountManageKey) {
        this.accountManageKey = accountManageKey;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return this.accountId;
    }
}
