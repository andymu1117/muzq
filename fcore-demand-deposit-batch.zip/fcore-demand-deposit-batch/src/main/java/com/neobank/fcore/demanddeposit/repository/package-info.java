/**
 * DBに対してRead/Writeを行うRepositoryに相当するクラスを格納するパッケージ。<br>
 * 発行するSQLファイルのテンプレートもここに格納する。
 */
package com.neobank.fcore.demanddeposit.repository;
