package com.neobank.fcore.demanddeposit.transform;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.entity.CustomerAdvantageConditionEntity;

@SuppressWarnings("serial")
public class CustomerAdvantageConditionEntityConverterFn
    extends DoFn<KV<Integer, Iterable<String>>, CustomerAdvantageConditionEntity> {
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerAdvantageConditionEntityConverterFn.class);
    private OffsetDateTime updatedTime;

    public CustomerAdvantageConditionEntityConverterFn(OffsetDateTime updatedTime) {
        this.updatedTime = updatedTime;
    }

    /**
     * 顧客優遇条件エンティティを作成する。
     *
     * @param context 処理のコンテキスト
     */
    @ProcessElement
    public void processElement(ProcessContext context) {
        LOGGER.debug("CustomerAdvantageConditionEntityConverterFn context.element: {}", context.element()
            .getValue());
        List<String> customerAdvantageConditions = new ArrayList<>();

        context.element()
            .getValue()
            .forEach(customerAdvantageConditions::add);
        LOGGER.debug("CustomerAdvantageConditionEntityConverterFn customerAdvantageConditions: {}",
            customerAdvantageConditions);
        CustomerAdvantageConditionEntity customerAdvantageConditionEntity = new CustomerAdvantageConditionEntity();
        customerAdvantageConditionEntity.setCustomerAdvantageConditions(customerAdvantageConditions);
        customerAdvantageConditionEntity.setUpdatedTime(updatedTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        context.output(customerAdvantageConditionEntity);
    }
}
