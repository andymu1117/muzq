package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.accenture.mainri.core.entity.DataClassBase;

@SuppressWarnings("serial")
public class SettlementCollationOfficerDetailFile extends DataClassBase implements Serializable {
    private Long zenginAmount;
    private String zenginManageNo;
    private Long accountAmount;
    private String accountManageNo;
    private Long differentAmount;

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    public SettlementCollationOfficerDetailFile() {
    }

    /**
     * 突合結果を設定する(決済照合保留)。
     *
     * @param file ファイルレコード
     * @param db DBレコード
     */
    public SettlementCollationOfficerDetailFile(SettlementCollationBase file, SettlementCollationBase db) {
        SettlementCollationFile fileCasted =
            file instanceof SettlementCollationFile ? (SettlementCollationFile) file : new SettlementCollationFile();
        SettlementCollationDb dbCasted =
            db instanceof SettlementCollationDb ? (SettlementCollationDb) db : new SettlementCollationDb();
        this.zenginAmount = fileCasted.getAmount();
        this.zenginManageNo = fileCasted.getManagementNumber();
        this.accountAmount = dbCasted.getAmount();
        this.accountManageNo = dbCasted.getManagementNumber();

        this.differentAmount = (Objects.isNull(this.zenginAmount) ? 0 : this.zenginAmount)
            - (Objects.isNull(this.accountAmount) ? 0 : this.accountAmount);
    }

    public Long getZenginAmount() {
        return zenginAmount;
    }

    public void setZenginAmount(Long zenginAmount) {
        this.zenginAmount = zenginAmount;
    }

    public String getZenginManageNo() {
        return zenginManageNo;
    }

    public void setZenginManageNo(String zenginManageNo) {
        this.zenginManageNo = zenginManageNo;
    }

    public Long getAccountAmount() {
        return accountAmount;
    }

    public void setAccountAmount(Long accountAmount) {
        this.accountAmount = accountAmount;
    }

    public String getAccountManageNo() {
        return accountManageNo;
    }

    public void setAccountManageNo(String accountManageNo) {
        this.accountManageNo = accountManageNo;
    }

    public Long getDifferentAmount() {
        return differentAmount;
    }

    public void setDifferentAmount(Long differentAmount) {
        this.differentAmount = differentAmount;
    }

}
