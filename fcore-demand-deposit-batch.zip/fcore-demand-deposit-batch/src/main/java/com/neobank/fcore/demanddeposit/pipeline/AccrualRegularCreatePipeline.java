package com.neobank.fcore.demanddeposit.pipeline;

import java.util.HashMap;

import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.spanner.ReadOperation;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Filter;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.resultset.SpannerResultToEntitiesConverter;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineRepartitioner;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.dto.AccountInterestCreateAccrualRegularResponseDto;
import com.neobank.fcore.demanddeposit.dto.AccrualRegularTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.dto.ErrorLogEntryDto;
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterEntity;
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity;
import com.neobank.fcore.demanddeposit.pipeline.options.AccrualRegularCreateOptions;
import com.neobank.fcore.demanddeposit.repository.AccountDeterminationStatementBuilder;
import com.neobank.fcore.demanddeposit.transform.AccrualRegularTargetAccountRetrieveConditionConvertFn;
import com.neobank.fcore.demanddeposit.transform.InterestAccountFilterFn;
import com.neobank.fcore.demanddeposit.transform.InterestAccountFilterWithLocalDateOfInterestDateConvertFn;
import com.neobank.fcore.demanddeposit.transform.grpc.AccountInterestCreateAccrualRegularApiCaller;
import com.neobank.fcore.demanddeposit.utils.DemandDepositGrpcPropertyUtil;

/**
 * AccrualRegularCreate 利息決算元加バッチ [--pipelineName=accrual-regular-create --processDate=YYYY-MM-DD]。
 *
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "accrual-regular-create", optionClass = AccrualRegularCreateOptions.class)
public class AccrualRegularCreatePipeline extends PipelineTemplate<AccrualRegularCreateOptions> {
    private static final Logger LOGGER = LoggerFactory.getLogger(AccrualRegularCreatePipeline.class);
    private SpannerResultToEntitiesConverter converter = new SpannerResultToEntitiesConverter();

    @Override
    public PipelineResult run(AccrualRegularCreateOptions options) {
        LOGGER.info("accrual regular create - start");
        Pipeline pipeline = Pipeline.create(options);
        final SpannerDriver spannerDriver = new SpannerDriver(options);
        PCollection<AccrualRegularTargetAccountRetrieveConditionDto> retrieveConditionPCollection =
            accrualRegularCreateOpitionConverter(pipeline, options);
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> processTargets =
            selectAccountNeedToCreateAccrual(retrieveConditionPCollection, spannerDriver, options);
        createAccrualRegular(processTargets, options);
        LOGGER.info("accrual regular create - end");
        return pipeline.run();
    }

    /**
     * バッチ実行パラメータを変換する。
     *
     * @param pipeline pipelineのインスタンス
     * @param options アクセス用のoptions
     * @return 処理対象抽出条件のPCollection
     */
    private PCollection<AccrualRegularTargetAccountRetrieveConditionDto> accrualRegularCreateOpitionConverter(
        Pipeline pipeline, final AccrualRegularCreateOptions options) {
        return pipeline.apply("Read parameters", Create.ofProvider(options.getProcessDate(), StringUtf8Coder.of()))
            .apply("Convert options", ParDo.of(new AccrualRegularTargetAccountRetrieveConditionConvertFn()));
    }

    /**
     * 利息決算元加処理対象口座をspannerから取得。
     *
     * @param retrieveConditionPCollection 処理対象抽出条件のPCollection
     * @param spannerDriver spannerアクセス用のDriver
     * @param options アクセス用のoptions
     * @return 処理対象口座のPCollection
     */
    private PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> selectAccountNeedToCreateAccrual(
        PCollection<AccrualRegularTargetAccountRetrieveConditionDto> retrieveConditionPCollection,
        final SpannerDriver spannerDriver, final AccrualRegularCreateOptions options) {
        final HashMap<String, Object> ctx = options.getPipelineContext();
        return retrieveConditionPCollection
            .apply("Create read operation", MapElements.into(TypeDescriptor.of(ReadOperation.class))
                .via((AccrualRegularTargetAccountRetrieveConditionDto conditionEntity) -> {
                    LOGGER.debug("interestDate: {}", conditionEntity.getInterestDateWithoutHyphen());
                    Statement statement = new AccountDeterminationStatementBuilder()
                        .createSelectAccountsNeedToCreateAccrualStatement(ctx, conditionEntity);
                    LOGGER.debug("sql: {}", statement);
                    return ReadOperation.create()
                        .withQuery(statement);
                }))
            .apply("Read data from Spanner", spannerDriver.readAll(false))
            .apply("Create interestAccountFilterEntity",
                MapElements.into(TypeDescriptor.of(InterestAccountFilterEntity.class))
                    .via((Struct input) -> {
                        InterestAccountFilterEntity result =
                            converter.convert(input, InterestAccountFilterEntity.class);
                        LOGGER.debug("read interestAccountFilterEntity entity: {}", result);
                        return result;
                    }))
            .apply("Convert interestAccountFilterEntity to interestAccountFilterWithLocalDateOfInterestDateEntity",
                ParDo.of(new InterestAccountFilterWithLocalDateOfInterestDateConvertFn()))
            .apply(ParDo.of(new PipelineRepartitioner.AddArbitraryKey<>()))
            .apply(GroupByKey.create())
            .apply(ParDo.of(new PipelineRepartitioner.RemoveArbitraryKey<>()))
            .apply("Filter interestAccountFilterWithLocalDateOfInterestDateEntity",
                Filter.by(new InterestAccountFilterFn()));
    }

    /**
     * 利息決算元加API実行。
     *
     * @param selectResult 利息決算元加処理対象口座
     * @param options アクセス用のoptions
     * @return 処理結果のPCollection
     */
    private PCollection<AccountInterestCreateAccrualRegularResponseDto> createAccrualRegular(
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> selectResult,
        AccrualRegularCreateOptions options) {
        final TupleTag<AccountInterestCreateAccrualRegularResponseDto> successTag =
            new TupleTag<AccountInterestCreateAccrualRegularResponseDto>() {};
        final TupleTag<ErrorLogEntryDto> errorTag = new TupleTag<ErrorLogEntryDto>() {};
        final TupleTag<ErrorLogEntryDto> warnTag = new TupleTag<ErrorLogEntryDto>() {};
        PCollectionTuple apiResult = selectResult.apply(ParDo
            .of(new AccountInterestCreateAccrualRegularApiCaller(
                new GrpcConnector(DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceHost(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServicePort(options),
                    DemandDepositGrpcPropertyUtil.isTlsEnabledForGrpcDemandDepositService(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceVersion(options)),
                successTag, errorTag, warnTag))
            .withOutputTags(successTag, TupleTagList.of(errorTag)
                .and(warnTag)));
        // warn、errorが発生する際に、ログ出力だけをするので、warnTagとerrorTagに対する処理が不要
        return apiResult.get(successTag);
    }
}
