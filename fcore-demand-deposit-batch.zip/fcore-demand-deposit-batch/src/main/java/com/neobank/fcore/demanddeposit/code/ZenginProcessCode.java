package com.neobank.fcore.demanddeposit.code;

/**
 * 全銀処理コード。
 *
 */
public enum ZenginProcessCode {

    // 仕向振込
    OUTBOUND_TRANSFER("1"),
    // 被仕向振込
    INBOUND_TRANSFER("2"),
    // 振込入金不能
    TRANSFER_DEPOSIT_IMPOSSIBLE("3");

    private String code;

    ZenginProcessCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
