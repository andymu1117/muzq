package com.neobank.fcore.demanddeposit.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.accenture.mainri.core.date.DateTimeUtils;
import com.accenture.mainri.core.entity.BaseEntity;
import com.accenture.mainri.core.entity.annotation.Table;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.utils.DateUtils;

@SuppressWarnings("serial")
@Table("SettlementCollationPendings")
public class SettlementCollationPending extends BaseEntity implements Serializable {
    // 決済照合保留ID
    private String settlementCollationPendingId;
    // 全銀処理コード
    private String zenginProcessCode;
    // 管理番号
    private String managementNumber;
    // 通信種目コード
    private String communicationTypeCode;
    // 決済日
    private LocalDate settlementDate;
    // 取引金額
    private Long transactionAmount;
    // 振込日
    private LocalDate transferDate;
    // コア・モアタイプ
    private String coreMoreTimeType;
    // 大口取引フラグ
    private String largeValueTransactionFlag;
    // メッセージ発行日付
    private OffsetDateTime publishedDate;

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    public SettlementCollationPending() {
    }

    /**
     * ファイルの値を設定する(決済照合データファイル)。
     *
     * @param databaseUserName データベースユーザ名
     * @param input 決済照合データファイルレコード
     * @param dateTimeUtils 日付系共通部品
     */
    public SettlementCollationPending(String databaseUserName, SettlementCollationFile input,
        DateTimeUtils dateTimeUtils) {
        settlementCollationPendingId = UUID.randomUUID()
            .toString();
        zenginProcessCode = input.getZenginProcessCode();
        managementNumber = input.getManagementNumber();
        communicationTypeCode = input.getCommunicationTypeCode();
        transactionAmount = input.getAmount();
        transferDate = DateUtils.parseIso8601WithoutHyphenToLocalDate(input.getTransferScheduledDate());
        coreMoreTimeType = input.getCoreMoreTimeType();
        largeValueTransactionFlag = input.getLargeValueTransactionFlag();
        publishedDate = dateTimeUtils.now();

        this.setCreationUserId(databaseUserName);
        this.setUpdatedUserId(databaseUserName);
    }

    public void setSettlementCollationPendingId(String settlementCollationPendingId) {
        this.settlementCollationPendingId = settlementCollationPendingId;
    }

    public String getSettlementCollationPendingId() {
        return this.settlementCollationPendingId;
    }

    public void setZenginProcessCode(String zenginProcessCode) {
        this.zenginProcessCode = zenginProcessCode;
    }

    public String getZenginProcessCode() {
        return this.zenginProcessCode;
    }

    public void setManagementNumber(String managementNumber) {
        this.managementNumber = managementNumber;
    }

    public String getManagementNumber() {
        return this.managementNumber;
    }

    public void setCommunicationTypeCode(String communicationTypeCode) {
        this.communicationTypeCode = communicationTypeCode;
    }

    public String getCommunicationTypeCode() {
        return this.communicationTypeCode;
    }

    public void setSettlementDate(LocalDate settlementDate) {
        this.settlementDate = settlementDate;
    }

    public LocalDate getSettlementDate() {
        return this.settlementDate;
    }

    public void setTransferDate(LocalDate transferDate) {
        this.transferDate = transferDate;
    }

    public LocalDate getTransferDate() {
        return this.transferDate;
    }

    public void setCoreMoreTimeType(String coreMoreTimeType) {
        this.coreMoreTimeType = coreMoreTimeType;
    }

    public String getCoreMoreTimeType() {
        return this.coreMoreTimeType;
    }

    public void setLargeValueTransactionFlag(String largeValueTransactionFlag) {
        this.largeValueTransactionFlag = largeValueTransactionFlag;
    }

    public String getLargeValueTransactionFlag() {
        return this.largeValueTransactionFlag;
    }

    public void setPublishedDate(OffsetDateTime publishedDate) {
        this.publishedDate = publishedDate;
    }

    public OffsetDateTime getPublishedDate() {
        return this.publishedDate;
    }

    public Long getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(Long transactionAmount) {
        this.transactionAmount = transactionAmount;
    }
}
