package com.neobank.fcore.demanddeposit.transform.grpc;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.grpc.Metadata;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.auth.IdToken;
import com.accenture.mainri.core.io.GrpcConnector;

import com.neobank.fcore.demanddeposit.dto.TransferReservationExecuteResponseDto;
import com.neobank.fcore.demanddeposit.dto.TransferReservationExecutionErrorEntryDto;
import com.neobank.fcore.demanddeposit.grpc.GrpcErrorParser;
import com.neobank.fcore.demanddeposit.grpc.GrpcSystemException;
import com.neobank.fcore.demanddeposit.grpc.GrpcValidationException;
import com.neobank.fcore.demanddeposit.pb.command.TransferReservationCommandGrpc;
import com.neobank.fcore.demanddeposit.pb.command.TransferReservationCommandGrpc.TransferReservationCommandBlockingStub;
import com.neobank.fcore.demanddeposit.pb.command.message.TransferReservationExecuteRequest;
import com.neobank.fcore.demanddeposit.pb.command.message.TransferReservationExecuteResponse;

/**
 * 振込予約実行APIのCaller。
 */
@SuppressWarnings("serial")
public class TransferReservationExecuteApiCaller
    extends DoFn<List<TransferReservationExecuteRequest>, List<TransferReservationExecuteResponseDto>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransferReservationExecuteApiCaller.class);

    private GrpcConnector grpcConnector;
    private transient TransferReservationCommandBlockingStub stub;
    private TupleTag<List<TransferReservationExecuteResponseDto>> successTag;
    private String programId;

    /**
     * エラーハンドリング用のタグとgRPC用の接続を設定するコンストラクタ。
     *
     * @param grpcConnector gRPCのコネクタ
     * @param successTag 正常時の出力先
     * @param programId プログラムId
     */
    public TransferReservationExecuteApiCaller(GrpcConnector grpcConnector,
        TupleTag<List<TransferReservationExecuteResponseDto>> successTag, String programId) {
        this.grpcConnector = grpcConnector;
        this.successTag = successTag;
        this.programId = programId;
    }

    /**
     * gRPCクライアント初期化。
     */
    @Setup
    public void setup() {
        LOGGER.debug("SetUp Stub.");
        stub = TransferReservationCommandGrpc.newBlockingStub(grpcConnector.createManagedChannel());
    }

    /**
     * 振込予約実行API実行部分。
     *
     * @param element 実行対象のデータ
     * @param context ProcessのContext
     * @throws JsonProcessingException JsonProcessingException
     */
    @ProcessElement
    public void processElement(@Element List<TransferReservationExecuteRequest> element, ProcessContext context)
        throws JsonProcessingException {
        long startTimeMillis = System.currentTimeMillis();
        stub = MetadataUtils.attachHeaders(stub, this.createHeaders());
        List<TransferReservationExecuteResponseDto> list = new ArrayList<>();

        for (TransferReservationExecuteRequest transferReservationExecuteRequest : element) {
            execute(transferReservationExecuteRequest, list);
            long processingTimeMillis = System.currentTimeMillis() - startTimeMillis;
            LOGGER.debug("[Processing Time] The processing time of the Interest Rate API is {} ms.",
                processingTimeMillis);
        }
        context.output(successTag, list);
    }

    private void execute(TransferReservationExecuteRequest request, List<TransferReservationExecuteResponseDto> list) {
        TransferReservationExecuteResponse response;
        LOGGER.debug(request.getOutboundTransferId());
        try {
            response = stub.execute(request);
        } catch (StatusRuntimeException srEx) {
            try {
                GrpcErrorParser.parseErrorResponse(srEx);
            } catch (GrpcSystemException sysEx) {
                TransferReservationExecutionErrorEntryDto errorLogEntry =
                    new TransferReservationExecutionErrorEntryDto(request, sysEx);
                LOGGER.error("api request error: {}", errorLogEntry);
            } catch (GrpcValidationException valEx) {
                TransferReservationExecutionErrorEntryDto errorLogEntry =
                    new TransferReservationExecutionErrorEntryDto(request, valEx);
                LOGGER.warn("api request warn: {}", errorLogEntry);
            }

            return;
        } catch (RuntimeException ex) {
            TransferReservationExecutionErrorEntryDto errorLogEntry =
                new TransferReservationExecutionErrorEntryDto(request, ex);
            LOGGER.error("api runtime error: {}", errorLogEntry);

            return;
        }

        TransferReservationExecuteResponseDto result = new TransferReservationExecuteResponseDto(response);
        list.add(result);
        LOGGER.debug("response: {}", result);

    }

    /**
     * リクエストヘッダ生成。
     *
     * @return リクエストヘッダ
     * @throws JsonProcessingException JsonProcessingException
     */
    private Metadata createHeaders() throws JsonProcessingException {
        IdToken idToken = new IdToken();
        ObjectMapper mapper = new ObjectMapper();
        idToken.setSubject(programId);

        String idTokenJson = mapper.writeValueAsString(idToken);
        Metadata headers = new Metadata();
        Metadata.Key<String> idTokenKey = Metadata.Key.of("X-Id-Token", io.grpc.Metadata.ASCII_STRING_MARSHALLER);
        headers.put(idTokenKey, idTokenJson);

        return headers;
    }
}
