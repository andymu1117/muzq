package com.neobank.fcore.demanddeposit.grpc;

public class GrpcGlobalError {
    String message;

    public GrpcGlobalError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
