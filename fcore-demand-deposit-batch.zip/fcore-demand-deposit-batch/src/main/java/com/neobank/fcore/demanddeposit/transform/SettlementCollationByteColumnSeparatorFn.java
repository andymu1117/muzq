package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode;
import com.neobank.fcore.demanddeposit.code.LargeValueTransactionFlag;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.exception.SystemFailureException;
import com.neobank.fcore.demanddeposit.utils.Conversion;

/**
 * バイト配列のListを受け取り、決済照合用のオブジェクトListにする。
 * 決済照合では小口当日決済のデータのみを処理対象とし、大口は破棄、小口当日決済以外のデータを保留登録するため、破棄以外のものをTupleTagで分けて出力する。
 */
@SuppressWarnings("serial")
public class SettlementCollationByteColumnSeparatorFn extends DoFn<byte[], KV<List<String>, SettlementCollationBase>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationByteColumnSeparatorFn.class);

    private static final int HEADER_COLUMN_COUNT = 3;
    private static final int DATA_COLUMN_COUNT = 7;

    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag;
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag;
    private PCollectionView<String> nextWorkDay;
    private ValueProvider<String> targetDate;

    /**
     * タグ受け渡し用のコンストラクタ。
     *
     * @param smallTodayDataTag 小口当日決済のデータを出力するためのタグ
     * @param smallFutureDataTag 小口翌日以降決済のデータを出力するためのタグ
     * @param nextWorkDay 翌営業日
     * @param targetDate 実行日付
     */
    public SettlementCollationByteColumnSeparatorFn(
        TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag,
        TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag, PCollectionView<String> nextWorkDay,
        ValueProvider<String> targetDate) {
        this.smallTodayDataTag = smallTodayDataTag;
        this.smallFutureDataTag = smallFutureDataTag;
        this.nextWorkDay = nextWorkDay;
        this.targetDate = targetDate;
    }

    /**
     * バイト配列のListを受け取り、全銀決済照合用のオブジェクトListにする。
     * 決済照合では小口当日決済のデータのみを処理対象とし、大口は破棄、小口当日決済以外のデータを保留登録するため、破棄以外のものをTupleTagで分けて出力する。
     * 出力形式はKV構造で、キーはDBレコードとの紐づけに必要な管理番号。
     *
     * @param target target
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element byte[] target, ProcessContext context) {
        List<List<String>> resultList = Conversion.separateBytesBySemicolonAndBreakLine(target);
        resultList.forEach(result -> {
            if (result.size() == HEADER_COLUMN_COUNT) {
                // ヘッダは利用しないがエラーにもしない
                return;
            } else if (result.size() == DATA_COLUMN_COUNT && result.get(6)
                .equals(LargeValueTransactionFlag.NO.getCode())) {
                // ↓大口でないもののみを処理対象とする
                SettlementCollationFile entity = new SettlementCollationFile(result);
                List<String> keys = new ArrayList<>();
                keys.add(entity.getManagementNumber());
                // 前営業日決済の判定と、決済日の判定(当日なら本処理で対象とし、違えばDB保持する)
                if (this.judgeProcessTarget(entity, context)) {
                    context.output(smallTodayDataTag, KV.of(keys, entity));
                    LOGGER.debug("smallTodayDataTag {}", entity);
                } else {
                    context.output(smallFutureDataTag, KV.of(keys, entity));
                    LOGGER.debug("smallFutureDataTag {}", entity);
                }
            } else if (result.size() == DATA_COLUMN_COUNT) {
                // ヘッダは利用しないがエラーにもしない
                return;
            } else {
                String resultString = new Gson().toJson(result);
                LOGGER.error("invalid column count: {}", resultString);
                throw new SystemFailureException("invalid column count");
            }
        });
    }

    /**
     * 対象のレコードが処理対象かどうか判定する。
     *
     * @param entity 判定するファイルレコード
     * @param context コンテキスト
     * @return true:処理対象 / false:翌日以降の処理対象
     */
    private boolean judgeProcessTarget(SettlementCollationFile entity, ProcessContext context) {
        // 前営業日の場合の判定
        return (CommunicationTypeCode.isBeforeSettlementTarget(entity.getCommunicationTypeCode())
            && context.sideInput(nextWorkDay)
                .replace("-", "")
                .equals(entity.getTransferScheduledDate()))
            // 前営業日以外の場合の判定
            || (!CommunicationTypeCode.isBeforeSettlementTarget(entity.getCommunicationTypeCode())) && targetDate.get()
                .equals(entity.getTransferScheduledDate());
    }
}
