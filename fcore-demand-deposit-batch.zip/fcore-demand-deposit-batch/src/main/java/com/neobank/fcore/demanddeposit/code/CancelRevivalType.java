package com.neobank.fcore.demanddeposit.code;

/**
 * 解約・復活タイプ。
 *
 */
public enum CancelRevivalType {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:1086] 解約・復活タイプ
    ACCOUNT_CANCEL_CUSTOMER("0"),
    ACCOUNT_REVIVAL_AUTO("1"),
    ACCOUNT_CANCEL_BANK_CLERK("2"),
    ACCOUNT_REVIVAL_BANK_CLERK("3");
    // --- Generated Code Ends---

    private String code;

    CancelRevivalType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
