package com.neobank.fcore.demanddeposit.code;

/**
 * 取引停止フラグ。
 *
 */
public enum SuspensionFlag {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:5] 取引停止フラグ
    OFF("0"), ON("1");
    // --- Generated Code Ends---

    private String code;

    SuspensionFlag(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
