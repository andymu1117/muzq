package com.neobank.fcore.demanddeposit.code;

import java.util.HashSet;

/**
 * 通信種目コード。
 */
public enum CommunicationTypeCode {

    SAME_DAY_TRANSFER("1022", "当日／振込／一般"), // 振込
    SAME_DAY_TRANSFER_NATIONAL_TREASURY_MONEY("1054", "当日／振込／国庫金"), // 振込
    TRANSFER_MONEY_ON_THE_DAY("1074", "当日／振込／公金"), // 振込
    ELECTRONIC_TRANSFER_RECEIVABLES_ON_THE_DAY("1082", "当日／振込／電子記録債権"), // 振込
    SAME_DAY_TRANSFER_STOCK_DIVIDEND_GENERAL("1041", "当日／振込／株式配当金（一般）"), // 振込
    SAME_DAY_TRANSFER_STOCK_DIVIDEND_OWNER_S_BANK("1046", "当日／振込／株式配当金（自行）"), // 振込
    SAME_DAY_TRANSFER_LENDING_TRUST_INCOME_DIVIDEND("1042", "当日／振込／貸付信託収益配当金"), // 振込
    SAME_DAY_TRANSFER_PENSION_BENEFITS_PENSION_TRUST("1043", "当日／振込／年金給付金（年金信託）"), // 振込
    TRANSFER_PENSION_BENEFITS_ON_THE_DAY_PUBLIC_PENSION("1044", "当日／振込／年金給付金（公的年金）"), // 振込
    TRANSFER_PENSION_BENEFITS_ON_THE_DAY_MEDICAL_INSURANCE("1045", "当日／振込／年金給付金（医療保険）"), // 振込

    DATE_CHANGE_FUND_COLLECTION("4101", "当日／付替／集手資金付替"), // 付替
    NEAR_DATE_FUND_TRANSFER("4201", "当日／付替／期近資金付替"), // 付替
    DATE_CHANGE_AND_OTHER_FUND_TRANSFER("4301", "当日／付替／その他資金付替"), // 付替
    DATE_CHANGE_AND_OTHER_FUND_TRANSFER_ELECTRONICALLY_RECORDED_RECEIVABLES("4401", "当日／付替／その他資金付替（電子記録債権）"), // 付替

    GENERAL_BILLING_MAIL_TRANSFER_FUND_BILLING_ON_THE_DAY("4501", "当日／請求／一般・メール振込資金請求"), // 請求
    PUBLIC_MONEY_EMAIL_TRANSFER_FUND_REQUEST_ON_THE_DAY("4671", "当日／請求／公金・メール振込資金請求"), // 請求
    SAME_DAY_BILLING_AND_OTHER_FUNDING_CLAIMS("4701", "当日／請求／その他資金請求"), // 請求
    ON_THE_DAY_OF_THE_BILL_COLLECTION_IMMEDIATE_NON_DELIVERY_NOTICE("4910", "当日／請求／集手・期近の不渡通知"), // 請求

    INDIVIDUAL_COLLECTION_RECEIPT_REPORT("3101", "個別取立／入金報告"), // その他
    NATIONAL_REMITTANCE_MONEY("2154", "送金／国庫金"), // その他
    REMITTANCE_PUBLIC_MONEY("2174", "送金／公金"), // その他

    GENERAL_FUTURE_TRANSFER("1122", "先日付／振込／一般"), // 振込
    FUTURE_TRANSFER_NATIONAL_TREASURY_MONEY("1154", "先日付／振込／国庫金"), // 振込
    FUTURE_TRANSFER_PUBLIC_MONEY("1174", "先日付／振込／公金"), // 振込
    ELECTRONICALLY_TRANSFERRED_RECEIVABLES("1182", "先日付／振込／電子記録債権"), // 振込
    DIVIDEND_TRANSFER_STOCK_DIVIDEND_GENERAL("1141", "先日付／振込／株式配当金（一般）"), // 振込
    DIVIDEND_TRANSFER_STOCK_DIVIDEND_OWNER_S_BANK("1146", "先日付／振込／株式配当金（自行）"), // 振込
    DIVIDEND_TRUST_INCOME("1142", "先日付／振込／貸付信託収益配当金"), // 振込
    FUTURE_TRANSFER_PENSION_BENEFITS_PENSION_TRUST("1143", "先日付／振込／年金給付金（年金信託）"), // 振込
    FUTURE_TRANSFER_PENSION_BENEFITS_PUBLIC_PENSION("1144", "先日付／振込／年金給付金（公的年金）"), // 振込
    FUTURE_TRANSFER_PENSION_BENEFITS_MEDICAL_INSURANCE("1145", "先日付／振込／年金給付金（医療保険）"), // 振込

    FUTURE_DATE_DISTRIBUTION("4102", "先日付／付替／集手資金付替"), // 付替
    SHORT_TERM_FUNDING("4202", "先日付／付替／期近資金付替"), // 付替
    FUTURE_DISTRIBUTION_AND_OTHER_FUND_DISTRIBUTION("4302", "先日付／付替／その他資金付替"), // 付替
    FUTURE_DATE_DISTRIBUTION_AND_OTHER_FUND_DISTRIBUTION_ELECTRONICALLY_RECORDED_RECEIVABLES("4402",
        "先日付／付替／その他資金付替（電子記録債権）"), // 付替

    FUTURE_DATE_BILLING_AND_OTHER_FUNDING_BILLING("4702", "先日付／請求／その他資金請求"), // 請求

    GENERAL_SALARY("1211", "給与／一般"), // 振込
    SALARY_PUBLIC_MONEY_SPECIFIED_DATE_SETTLEMENT("1271", "給与／公金（指定日決済）"), // 振込
    SALARY_NATIONAL_TREASURY_MONEY("1251", "給与／国庫金"), // 振込
    SALARY_PUBLIC_MONEY_SETTLEMENT_OF_BUSINESS_DAYS_BEFORE_DESIGNATED_DATE("1275", "給与／公金（指定日前営業日決済）"), // 振込
    BONUSES_IN_GENERAL("1212", "賞与／一般"), // 振込
    BONUS_PUBLIC_MONEY_SPECIFIED_DATE_SETTLEMENT("1272", "賞与／公金（指定日決済）"), // 振込
    BONUS_NATIONAL_TREASURY_MONEY("1252", "賞与／国庫金"), // 振込
    BONUS_PUBLIC_MONEY_SPECIFIED_BUSINESS_DAY_BEFORE_SETTLEMENT("1276", "賞与／公金（指定日前営業日決済）") // 振込
    ;

    private static HashSet<String> transferTarget = new HashSet<>();
    private static HashSet<String> changeTarget = new HashSet<>();
    private static HashSet<String> billingTarget = new HashSet<>();
    private static HashSet<String> beforeSettlementCodes = new HashSet<>();

    static {
        transferTarget.add(SAME_DAY_TRANSFER.getCode());
        transferTarget.add(SAME_DAY_TRANSFER_NATIONAL_TREASURY_MONEY.getCode());
        transferTarget.add(TRANSFER_MONEY_ON_THE_DAY.getCode());
        transferTarget.add(ELECTRONIC_TRANSFER_RECEIVABLES_ON_THE_DAY.getCode());
        transferTarget.add(SAME_DAY_TRANSFER_STOCK_DIVIDEND_GENERAL.getCode());
        transferTarget.add(SAME_DAY_TRANSFER_STOCK_DIVIDEND_OWNER_S_BANK.getCode());
        transferTarget.add(SAME_DAY_TRANSFER_LENDING_TRUST_INCOME_DIVIDEND.getCode());
        transferTarget.add(SAME_DAY_TRANSFER_PENSION_BENEFITS_PENSION_TRUST.getCode());
        transferTarget.add(TRANSFER_PENSION_BENEFITS_ON_THE_DAY_PUBLIC_PENSION.getCode());
        transferTarget.add(TRANSFER_PENSION_BENEFITS_ON_THE_DAY_MEDICAL_INSURANCE.getCode());

        transferTarget.add(GENERAL_FUTURE_TRANSFER.getCode());
        transferTarget.add(FUTURE_TRANSFER_NATIONAL_TREASURY_MONEY.getCode());
        transferTarget.add(FUTURE_TRANSFER_PUBLIC_MONEY.getCode());
        transferTarget.add(ELECTRONICALLY_TRANSFERRED_RECEIVABLES.getCode());
        transferTarget.add(DIVIDEND_TRANSFER_STOCK_DIVIDEND_GENERAL.getCode());
        transferTarget.add(DIVIDEND_TRANSFER_STOCK_DIVIDEND_OWNER_S_BANK.getCode());
        transferTarget.add(DIVIDEND_TRUST_INCOME.getCode());
        transferTarget.add(FUTURE_TRANSFER_PENSION_BENEFITS_PENSION_TRUST.getCode());
        transferTarget.add(FUTURE_TRANSFER_PENSION_BENEFITS_PUBLIC_PENSION.getCode());
        transferTarget.add(FUTURE_TRANSFER_PENSION_BENEFITS_MEDICAL_INSURANCE.getCode());

        transferTarget.add(GENERAL_SALARY.getCode());
        transferTarget.add(SALARY_PUBLIC_MONEY_SPECIFIED_DATE_SETTLEMENT.getCode());
        transferTarget.add(SALARY_NATIONAL_TREASURY_MONEY.getCode());
        transferTarget.add(SALARY_PUBLIC_MONEY_SETTLEMENT_OF_BUSINESS_DAYS_BEFORE_DESIGNATED_DATE.getCode());
        transferTarget.add(BONUSES_IN_GENERAL.getCode());
        transferTarget.add(BONUS_PUBLIC_MONEY_SPECIFIED_DATE_SETTLEMENT.getCode());
        transferTarget.add(BONUS_NATIONAL_TREASURY_MONEY.getCode());
        transferTarget.add(BONUS_PUBLIC_MONEY_SPECIFIED_BUSINESS_DAY_BEFORE_SETTLEMENT.getCode());

        changeTarget.add(DATE_CHANGE_FUND_COLLECTION.getCode());
        changeTarget.add(NEAR_DATE_FUND_TRANSFER.getCode());
        changeTarget.add(DATE_CHANGE_AND_OTHER_FUND_TRANSFER.getCode());
        changeTarget.add(DATE_CHANGE_AND_OTHER_FUND_TRANSFER_ELECTRONICALLY_RECORDED_RECEIVABLES.getCode());

        changeTarget.add(FUTURE_DATE_DISTRIBUTION.getCode());
        changeTarget.add(SHORT_TERM_FUNDING.getCode());
        changeTarget.add(FUTURE_DISTRIBUTION_AND_OTHER_FUND_DISTRIBUTION.getCode());
        changeTarget
            .add(FUTURE_DATE_DISTRIBUTION_AND_OTHER_FUND_DISTRIBUTION_ELECTRONICALLY_RECORDED_RECEIVABLES.getCode());

        billingTarget.add(GENERAL_BILLING_MAIL_TRANSFER_FUND_BILLING_ON_THE_DAY.getCode());
        billingTarget.add(PUBLIC_MONEY_EMAIL_TRANSFER_FUND_REQUEST_ON_THE_DAY.getCode());
        billingTarget.add(SAME_DAY_BILLING_AND_OTHER_FUNDING_CLAIMS.getCode());
        billingTarget.add(ON_THE_DAY_OF_THE_BILL_COLLECTION_IMMEDIATE_NON_DELIVERY_NOTICE.getCode());
        billingTarget.add(FUTURE_DATE_BILLING_AND_OTHER_FUNDING_BILLING.getCode());

        beforeSettlementCodes.add(SALARY_NATIONAL_TREASURY_MONEY.getCode());
        beforeSettlementCodes.add(SALARY_PUBLIC_MONEY_SETTLEMENT_OF_BUSINESS_DAYS_BEFORE_DESIGNATED_DATE.getCode());
        beforeSettlementCodes.add(BONUS_NATIONAL_TREASURY_MONEY.getCode());
        beforeSettlementCodes.add(BONUS_PUBLIC_MONEY_SPECIFIED_BUSINESS_DAY_BEFORE_SETTLEMENT.getCode());
    }

    private final String code;
    private final String decode;

    private CommunicationTypeCode(String code, String decode) {
        this.code = code;
        this.decode = decode;
    }

    public static boolean isTransferTarget(String code) {
        return transferTarget.contains(code);
    }

    public static boolean isChangeTarget(String code) {
        return changeTarget.contains(code);
    }

    public static boolean isBillingTarget(String code) {
        return billingTarget.contains(code);
    }

    public static boolean isBeforeSettlementTarget(String code) {
        return beforeSettlementCodes.contains(code);
    }

    public String getCode() {
        return this.code;
    }

    public String getDecode() {
        return this.decode;
    }

}
