package com.neobank.fcore.demanddeposit.code;

/**
 * 決済照合用データ種別コード。
 */
public enum SettlementCollationDataTypeCode {

    // "1:仕向(振込)"
    DATA_TYPE_OUTBOUND_TRANSFER("1"),
    // "2:仕向(振込以外)"
    DATA_TYPE_OUTBOUND_NOT_TRANSFER("2"),
    // "3:被仕向(振込)"
    DATA_TYPE_INBOUND_TRANSFER("3"),
    // "4:被仕向(振込以外)"
    DATA_TYPE_INBOUND_NOT_TRANSFER("4"),
    // "5:未決済為替貸"
    DATA_TYPE_INBOUND("5"),
    // "6:未決済為替借"
    DATA_TYPE_OUTBOUND("6"),
    // "7:ニユウキン"
    DATA_TYPE_LARGE_IN("7"),
    // "8:ヒキオトシ"
    DATA_TYPE_LARGE_OUT("8");

    private String code;

    SettlementCollationDataTypeCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
