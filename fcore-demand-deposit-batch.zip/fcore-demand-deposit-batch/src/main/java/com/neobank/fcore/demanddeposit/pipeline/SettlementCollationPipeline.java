package com.neobank.fcore.demanddeposit.pipeline;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.transforms.join.CoGroupByKey;
import org.apache.beam.sdk.transforms.join.KeyedPCollectionTuple;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;

import com.accenture.mainri.core.date.DateTimeUtils;
import com.accenture.mainri.core.entity.DataClassBase;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile;
import com.neobank.fcore.demanddeposit.pipeline.options.SettlementCollationOptions;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationByteColumnSeparatorFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationByteReaderFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationCheckAmountNotTransferFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationCheckAmountSummaryFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationCheckAmountTransferFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationCheckErroredNumberFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationClassifyFileRecordsFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationConvertForCallApiFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationFileAmountCombineFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationFileOutputEmptyCheckFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationFileToBaseConvertFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationFilterOutputTargetReconcileFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationMergeForOfficerDetailFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationMergeForOfficerSummaryFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationRemoveBeforeSettlementFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationSelectPendingsFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationSelectSettlementDetailFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationSelectSettlementSummaryFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationSetSummaryResultToErrorFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationStringifyForOfficerFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationStringifyForReconcileFn;
import com.neobank.fcore.demanddeposit.transform.SettlementCollationValidateDateFn;
import com.neobank.fcore.demanddeposit.transform.grpc.SettlementCollationBeforeSettlementApiCaller;
import com.neobank.fcore.demanddeposit.transform.grpc.SettlementCollationGetWorkDayApiCaller;
import com.neobank.fcore.demanddeposit.transform.mutation.SettlementCollationResisterPendingFn;
import com.neobank.fcore.demanddeposit.transform.writer.SettlementCollationFileCreateFn;
import com.neobank.fcore.demanddeposit.transform.writer.SettlementCollationMoveCompletedFile;

/**
 * 【全銀】決済照合Pipeline。
 *
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "settlement-collation", optionClass = SettlementCollationOptions.class)
public class SettlementCollationPipeline extends PipelineTemplate<SettlementCollationOptions> {
    public static final String DATABASE_USER_ID = "fcore-scalable-collation";

    private static final String GRPC_COMMAND_HOST = "grpc.demandDepositService.host";
    private static final String GRPC_COMMAND_PORT = "grpc.demandDepositService.port";
    private static final String GRPC_COMMAND_ENABLE_TLS = "grpc.demandDepositService.enableTls";
    private static final String GRPC_COMMAND_VERSION = "grpc.demandDepositService.version";
    private static final String GRPC_QUERY_HOST = "grpc.demandDepositQueryService.host";
    private static final String GRPC_QUERY_PORT = "grpc.demandDepositQueryService.port";
    private static final String GRPC_QUERY_ENABLE_TLS = "grpc.demandDepositQueryService.enableTls";
    private static final String GRPC_QUERY_VERSION = "grpc.demandDepositQueryService.version";

    private static final String BUCKET = "gcs.bucket.settlementCollation";

    public static final String OUTPUT_TYPE_SUMMARY = "1";
    public static final String OUTPUT_TYPE_DETAIL = "2";
    public static final String OUTPUT_TYPE_RECONCILE = "3";

    // ファイル読み込み用
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
        new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
        new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

    // ファイルデータ振り分け用
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundTransferTag =
        new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundNotTransferTag =
        new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundTransferTag =
        new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundNotTransferTag =
        new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<Integer> fileOutboundTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileOutboundNotTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundNotTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};

    // 判定結果の出力を分ける為のタグ
    TupleTag<Integer> errorNumTag = new TupleTag<Integer>() {};

    /**
     * 【全銀】決済照合Pipelineを実行する。
     *
     * @param options Pipeline用のOption
     */
    @Override
    public PipelineResult run(SettlementCollationOptions options) {
        final SpannerDriver spannerDriver = new SpannerDriver(options);
        final HashMap<String, Object> ctx = new HashMap<>(options.getPipelineContext());
        final String targetBucket = (String) ctx.get(BUCKET);
        final DateTimeUtils dateTimeUtils = new DateTimeUtils(options);

        Pipeline pipeline = Pipeline.create(options);

        // パラメータ取得
        PCollection<String> targetDate =
            pipeline.apply("read param", Create.ofProvider(options.getTargetDate(), StringUtf8Coder.of()))
                .apply("validate param", ParDo.of(new SettlementCollationValidateDateFn()));

        // 営業日取得
        PCollectionView<String> nextWorkDay = targetDate
            .apply("get nextWorkDay",
                ParDo.of(new SettlementCollationGetWorkDayApiCaller(getGrpcQueryConnector(options), 1)))
            .apply(View.asSingleton());
        PCollectionView<String> beforeWorkDay = targetDate
            .apply("get beforeWorkDay",
                ParDo.of(new SettlementCollationGetWorkDayApiCaller(getGrpcQueryConnector(options), -1)))
            .apply(View.asSingleton());
        PCollectionView<String> targetDateView = targetDate.apply(View.asSingleton());

        // 決済照合ファイル読み込み
        PCollectionTuple fileDataTuple =
            targetDate.apply("read file byte", ParDo.of(new SettlementCollationByteReaderFn(targetBucket)))
                .apply("separate into column settlement collation file",
                    ParDo
                        .of(new SettlementCollationByteColumnSeparatorFn(smallTodayDataTag, smallFutureDataTag,
                            nextWorkDay, options.getTargetDate()))
                        // TupleTagを用いて、当日決済・未来日決済を分けて出力する。
                        .withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag))
                        .withSideInputs(nextWorkDay));

        // 処理データ作成
        PCollection<KV<List<String>, SettlementCollationBase>> settlementCollationPendings = targetDate
            .apply("select pending data", ParDo.of(new SettlementCollationSelectPendingsFn(spannerDriver, ctx)));
        PCollection<KV<List<String>, SettlementCollationBase>> todaySettlementTarget =
            PCollectionList.of(fileDataTuple.get(smallTodayDataTag))
                .and(settlementCollationPendings)
                .apply("merge collation targets", Flatten.<KV<List<String>, SettlementCollationBase>>pCollections());

        // ファイルデータの振り分け
        PCollectionTuple classifiedtodaySettlementTargetsTuple = todaySettlementTarget.apply("classify file",
            ParDo
                .of(new SettlementCollationClassifyFileRecordsFn(fileOutboundTransferTag, fileOutboundNotTransferTag,
                    fileInboundTransferTag, fileInboundNotTransferTag, fileOutboundTransferBeforeSettlementNumTag,
                    fileOutboundNotTransferBeforeSettlementNumTag, fileInboundTransferBeforeSettlementNumTag,
                    fileInboundNotTransferBeforeSettlementNumTag))
                .withOutputTags(fileOutboundTransferTag, TupleTagList.of(fileOutboundNotTransferTag)
                    .and(fileInboundTransferTag)
                    .and(fileInboundNotTransferTag)
                    .and(fileOutboundTransferBeforeSettlementNumTag)
                    .and(fileOutboundNotTransferBeforeSettlementNumTag)
                    .and(fileInboundTransferBeforeSettlementNumTag)
                    .and(fileInboundNotTransferBeforeSettlementNumTag)));

        // ファイル数をSideInput形式で取り出す。
        PCollectionView<Integer> fileOutboundTransferBeforeSettlementNum =
            classifiedtodaySettlementTargetsTuple.get(fileOutboundTransferBeforeSettlementNumTag)
                .apply(Sum.integersGlobally())
                .apply(View.asSingleton());
        PCollectionView<Integer> fileOutboundNotTransferBeforeSettlementNum =
            classifiedtodaySettlementTargetsTuple.get(fileOutboundNotTransferBeforeSettlementNumTag)
                .apply(Sum.integersGlobally())
                .apply(View.asSingleton());
        PCollectionView<Integer> fileInboundTransferBeforeSettlementNum =
            classifiedtodaySettlementTargetsTuple.get(fileInboundTransferBeforeSettlementNumTag)
                .apply(Sum.integersGlobally())
                .apply(View.asSingleton());
        PCollectionView<Integer> fileInboundNotTransferBeforeSettlementNum =
            classifiedtodaySettlementTargetsTuple.get(fileInboundNotTransferBeforeSettlementNumTag)
                .apply(Sum.integersGlobally())
                .apply(View.asSingleton());

        // ファイルデータのサマライズ
        PCollection<KV<List<String>, SettlementCollationBase>> fileOutboundTransferSummary =
            classifiedtodaySettlementTargetsTuple.get(fileOutboundTransferTag)
                .apply("summarize fileOutboundTransferSummary",
                    Combine.globally(new SettlementCollationFileAmountCombineFn(
                        SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())))
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()));
        PCollection<KV<List<String>, SettlementCollationBase>> fileOutboundNotTransferSummary =
            classifiedtodaySettlementTargetsTuple.get(fileOutboundNotTransferTag)
                .apply("summarize fileOutboundNotTransferSummary",
                    Combine.globally(new SettlementCollationFileAmountCombineFn(
                        SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode())))
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()));
        PCollection<KV<List<String>, SettlementCollationBase>> fileInboundTransferSummary =
            classifiedtodaySettlementTargetsTuple.get(fileInboundTransferTag)
                .apply("summarize fileInboundTransferSummary",
                    Combine.globally(new SettlementCollationFileAmountCombineFn(
                        SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode())))
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()));
        PCollection<KV<List<String>, SettlementCollationBase>> fileInboundNotTransferSummary =
            classifiedtodaySettlementTargetsTuple.get(fileInboundNotTransferTag)
                .apply("summarize fileInboundNotTransferSummary",
                    Combine.globally(new SettlementCollationFileAmountCombineFn(
                        SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode())))
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()));

        // API Call
        PCollection<Boolean> apiCallResult =
            todaySettlementTarget.apply(ParDo.of(new SettlementCollationConvertForCallApiFn()))
                .apply("summarize before settlement",
                    Combine.globally(new SettlementCollationFileAmountCombineFn("before settlement")))
                .apply("call api",
                    ParDo.of(new SettlementCollationBeforeSettlementApiCaller(getGrpcCommandConnector(options),
                        options.getCallApi())));

        final String waitApiLabel = "wait apiCallResult";

        // DB明細取得
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallOutboundTransfer =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallOutboundTransfer",
                    ParDo
                        .of(new SettlementCollationSelectSettlementDetailFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallOutboundNotTransfer =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallOutboundNotTransfer",
                    ParDo
                        .of(new SettlementCollationSelectSettlementDetailFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallInboundTransfer =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallInboundTransfer",
                    ParDo
                        .of(new SettlementCollationSelectSettlementDetailFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallInboundNotTransfer =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallInboundNotTransfer",
                    ParDo
                        .of(new SettlementCollationSelectSettlementDetailFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));

        // DBサマリ取得
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallOutboundTransferSummary =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallOutboundTransferSummary",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallOutboundNotTransferSummary =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallOutboundNotTransferSummary",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallInboundTransferSummary =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallOutboundNotTransferSummary",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultSmallInboundNotTransferSummary =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultSmallInboundNotTransferSummary",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));

        // サマリ画面出力用のデータセット
        PCollection<KV<List<String>, SettlementCollationBase>> dbSumUnsettledInbound =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbSumUnsettledInbound",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_INBOUND, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbSumUnsettledOutbound =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbSumUnsettledOutbound",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultLargeOutboundTransferSummary =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultLargeOutboundTransferSummary",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_LARGE_OUT, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));
        PCollection<KV<List<String>, SettlementCollationBase>> dbResultLargeInboundTransferSummary =
            targetDate.apply(waitApiLabel, Wait.on(apiCallResult))
                .apply("select dbResultLargeInboundTransferSummary",
                    ParDo
                        .of(new SettlementCollationSelectSettlementSummaryFn(spannerDriver, ctx,
                            SettlementCollationDataTypeCode.DATA_TYPE_LARGE_IN, beforeWorkDay))
                        .withSideInputs(beforeWorkDay));

        // サマリのエラー判定
        // JOIN用のタグ用意
        TupleTag<SettlementCollationBase> fileTag = new TupleTag<SettlementCollationBase>() {};
        TupleTag<SettlementCollationBase> dbTag = new TupleTag<SettlementCollationBase>() {};
        TupleTag<KV<List<String>, SettlementCollationBase>> settlementCollationOfficerSummaryFileTag =
            new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

        // JOIN(仕向振込ファイル⇔DB)
        PCollectionTuple diffResultOutboundTransferSummaryTuple =
            KeyedPCollectionTuple.of(fileTag, fileOutboundTransferSummary)
                .and(dbTag, dbResultSmallOutboundTransferSummary)
                .apply("grouping small outbound transfer summary", CoGroupByKey.create())
                // 突合結果の参照
                .apply("check amount small outbound transfer summary",
                    ParDo
                        .of(new SettlementCollationCheckAmountSummaryFn(fileTag, dbTag, errorNumTag,
                            settlementCollationOfficerSummaryFileTag,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER,
                            fileOutboundTransferBeforeSettlementNum))
                        .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerSummaryFileTag))
                        .withSideInputs(fileOutboundTransferBeforeSettlementNum));
        // JOIN(仕向振込以外ファイル⇔DB)
        PCollectionTuple diffResultOutboundNotTransferSummaryTuple =
            KeyedPCollectionTuple.of(fileTag, fileOutboundNotTransferSummary)
                .and(dbTag, dbResultSmallOutboundNotTransferSummary)
                .apply("grouping small outbound not transfer summary", CoGroupByKey.create())
                // 突合結果の参照
                .apply("check amount small outbound not transfer summary",
                    ParDo
                        .of(new SettlementCollationCheckAmountSummaryFn(fileTag, dbTag, errorNumTag,
                            settlementCollationOfficerSummaryFileTag,
                            SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER,
                            fileOutboundNotTransferBeforeSettlementNum))
                        .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerSummaryFileTag))
                        .withSideInputs(fileOutboundNotTransferBeforeSettlementNum));
        // JOIN(被仕向振込ファイル⇔DB)
        PCollectionTuple diffResultInboundTransferSummaryTuple = KeyedPCollectionTuple
            .of(fileTag, fileInboundTransferSummary)
            .and(dbTag, dbResultSmallInboundTransferSummary)
            .apply("grouping small inbound transfer summary", CoGroupByKey.create())
            // 突合結果の参照
            .apply("check amount small inbound transfer summary",
                ParDo.of(new SettlementCollationCheckAmountSummaryFn(fileTag, dbTag, errorNumTag,
                    settlementCollationOfficerSummaryFileTag,
                    SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER, fileInboundTransferBeforeSettlementNum))
                    .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerSummaryFileTag))
                    .withSideInputs(fileInboundTransferBeforeSettlementNum));
        // JOIN(被仕向振込以外ファイル⇔DB)
        PCollectionTuple diffResultInboundNotTransferSummaryTuple =
            KeyedPCollectionTuple.of(fileTag, fileInboundNotTransferSummary)
                .and(dbTag, dbResultSmallInboundNotTransferSummary)
                .apply("grouping small inbound not transfer summary", CoGroupByKey.create())
                // 突合結果の参照
                .apply("check amount small inbound not transfer summary",
                    ParDo
                        .of(new SettlementCollationCheckAmountSummaryFn(fileTag, dbTag, errorNumTag,
                            settlementCollationOfficerSummaryFileTag,
                            SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER,
                            fileInboundNotTransferBeforeSettlementNum))
                        .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerSummaryFileTag))
                        .withSideInputs(fileInboundNotTransferBeforeSettlementNum));

        // 明細のエラー判定用副入力を用意
        PCollectionView<Integer> diffResultOutboundTransferSummaryErrorNum =
            diffResultOutboundTransferSummaryTuple.get(errorNumTag)
                .apply(Sum.integersGlobally())
                .apply(View.asSingleton());
        PCollectionView<Integer> diffResultInboundTransferSummaryErrorNum =
            diffResultInboundTransferSummaryTuple.get(errorNumTag)
                .apply(Sum.integersGlobally())
                .apply(View.asSingleton());

        // 判定結果の出力を分ける為のタグ
        TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>> settlementCollationOfficerDetailFileTag =
            new TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>>() {};

        // JOIN&エラー明細出力(仕向振込ファイル⇔DB)
        PCollectionTuple diffResultOutboundTransferTuple = KeyedPCollectionTuple
            .of(fileTag, classifiedtodaySettlementTargetsTuple.get(fileOutboundTransferTag)
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()))
                .apply("remove before settlement fileOutboundTransfer",
                    ParDo.of(new SettlementCollationRemoveBeforeSettlementFn())))
            .and(dbTag, dbResultSmallOutboundTransfer)
            .apply("grouping small outbound transfer detail", CoGroupByKey.create())
            // 突合結果の参照
            .apply("check amount small outbound transfer detail",
                ParDo
                    .of(new SettlementCollationCheckAmountTransferFn(fileTag, dbTag, errorNumTag,
                        settlementCollationOfficerDetailFileTag, diffResultOutboundTransferSummaryErrorNum,
                        SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER))
                    .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerDetailFileTag))
                    .withSideInputs(diffResultOutboundTransferSummaryErrorNum));
        // JOIN&エラー明細出力(仕向振込以外ファイル⇔DB)
        PCollectionTuple diffResultOutboundNotTransferTuple = KeyedPCollectionTuple
            .of(fileTag, classifiedtodaySettlementTargetsTuple.get(fileOutboundNotTransferTag)
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()))
                .apply("remove before settlement fileOutboundNotTransfer",
                    ParDo.of(new SettlementCollationRemoveBeforeSettlementFn())))
            .and(dbTag, dbResultSmallOutboundNotTransfer)
            .apply("grouping small outbound not transfer detail", CoGroupByKey.create())
            // 突合結果の参照
            .apply("check amount small outbound not transfer detail",
                ParDo
                    .of(new SettlementCollationCheckAmountNotTransferFn(fileTag, dbTag, errorNumTag,
                        settlementCollationOfficerDetailFileTag,
                        SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER))
                    .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerDetailFileTag)));
        // JOIN&エラー明細出力(被仕向振込ファイル⇔DB)
        PCollectionTuple diffResultInboundTransferTuple = KeyedPCollectionTuple
            .of(fileTag, classifiedtodaySettlementTargetsTuple.get(fileInboundTransferTag)
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()))
                .apply("remove before settlement fileInboundTransfer",
                    ParDo.of(new SettlementCollationRemoveBeforeSettlementFn())))
            .and(dbTag, dbResultSmallInboundTransfer)
            .apply("grouping small inbound transfer detail", CoGroupByKey.create())
            // 突合結果の参照
            .apply("check amount small inbound transfer detail",
                ParDo
                    .of(new SettlementCollationCheckAmountTransferFn(fileTag, dbTag, errorNumTag,
                        settlementCollationOfficerDetailFileTag, diffResultInboundTransferSummaryErrorNum,
                        SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER))
                    .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerDetailFileTag))
                    .withSideInputs(diffResultInboundTransferSummaryErrorNum));
        // JOIN&エラー明細出力(被仕向振込以外ファイル⇔DB)
        PCollectionTuple diffResultInboundNotTransferTuple = KeyedPCollectionTuple
            .of(fileTag, classifiedtodaySettlementTargetsTuple.get(fileInboundNotTransferTag)
                .apply(ParDo.of(new SettlementCollationFileToBaseConvertFn()))
                .apply("remove before settlement fileInboundNotTransfer",
                    ParDo.of(new SettlementCollationRemoveBeforeSettlementFn())))
            .and(dbTag, dbResultSmallInboundNotTransfer)
            .apply("grouping small inbound not transfer detail", CoGroupByKey.create())
            // 突合結果の参照
            .apply("check amount small inbound not transfer detail",
                ParDo
                    .of(new SettlementCollationCheckAmountNotTransferFn(fileTag, dbTag, errorNumTag,
                        settlementCollationOfficerDetailFileTag,
                        SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER))
                    .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerDetailFileTag)));

        // エラー数をログ出力
        PCollection<Integer> diffResultOutboundTransferDetailErrorNum = diffResultOutboundTransferTuple.get(errorNumTag)
            .apply(Sum.integersGlobally());
        PCollection<Integer> diffResultOutboundNotTransferDetailErrorNum =
            diffResultOutboundNotTransferTuple.get(errorNumTag)
                .apply(Sum.integersGlobally());
        PCollection<Integer> diffResultInboundTransferDetailErrorNum = diffResultInboundTransferTuple.get(errorNumTag)
            .apply(Sum.integersGlobally());
        PCollection<Integer> diffResultInboundNotTransferDetailErrorNum =
            diffResultInboundNotTransferTuple.get(errorNumTag)
                .apply(Sum.integersGlobally());

        PCollectionList.of(diffResultOutboundTransferDetailErrorNum)
            .and(diffResultOutboundNotTransferDetailErrorNum)
            .and(diffResultInboundTransferDetailErrorNum)
            .and(diffResultInboundNotTransferDetailErrorNum)
            .apply("merge error number", Flatten.<Integer>pCollections())
            .apply(Sum.integersGlobally())
            .apply("check error number", ParDo.of(new SettlementCollationCheckErroredNumberFn()));

        // Output(明細)
        PCollection<String> outputTargetForOfficer =
            PCollectionList.of(diffResultOutboundTransferTuple.get(settlementCollationOfficerDetailFileTag))
                .and(diffResultOutboundNotTransferTuple.get(settlementCollationOfficerDetailFileTag))
                .and(diffResultInboundTransferTuple.get(settlementCollationOfficerDetailFileTag))
                .and(diffResultInboundNotTransferTuple.get(settlementCollationOfficerDetailFileTag))
                .apply("merge error detail records",
                    Flatten.<KV<List<String>, SettlementCollationOfficerDetailFile>>pCollections())
                .apply(GroupByKey.<List<String>, SettlementCollationOfficerDetailFile>create())
                .apply("transform into detail file format", ParDo.of(new SettlementCollationMergeForOfficerDetailFn()))
                .apply(GroupByKey.<List<String>, Map<String, List<DataClassBase>>>create())
                .apply(ParDo.of(new SettlementCollationStringifyForOfficerFn(OUTPUT_TYPE_DETAIL)))
                .apply(Combine.globally(new SettlementCollationFileOutputEmptyCheckFn(OUTPUT_TYPE_DETAIL)))
                .apply(ParDo
                    .of(new SettlementCollationFileCreateFn(targetDateView, targetBucket,
                        "detail-settlement-collation.{0}.JSON"))
                    .withSideInputs(targetDateView));

        // Flatten→GroupByでひとつなぎのデータに変換(サマリ)
        PCollectionView<Integer> diffResultOutboundTransferDetailErrorNumView =
            diffResultOutboundTransferDetailErrorNum.apply(View.asSingleton());
        PCollectionView<Integer> diffResultOutboundNotTransferDetailErrorNumView =
            diffResultOutboundNotTransferDetailErrorNum.apply(View.asSingleton());
        PCollectionView<Integer> diffResultInboundTransferDetailErrorNumView =
            diffResultInboundTransferDetailErrorNum.apply(View.asSingleton());
        PCollectionView<Integer> diffResultInboundNotTransferDetailErrorNumView =
            diffResultInboundNotTransferDetailErrorNum.apply(View.asSingleton());
        PCollection<String> outputTargetSummaryForOfficer =
            // ↓突合したデータ
            PCollectionList.of(diffResultOutboundTransferSummaryTuple.get(settlementCollationOfficerSummaryFileTag)
                .apply(ParDo
                    .of(new SettlementCollationSetSummaryResultToErrorFn(diffResultOutboundTransferDetailErrorNumView))
                    .withSideInputs(diffResultOutboundTransferDetailErrorNumView)))
                .and(diffResultOutboundNotTransferSummaryTuple.get(settlementCollationOfficerSummaryFileTag)
                    .apply(ParDo
                        .of(new SettlementCollationSetSummaryResultToErrorFn(
                            diffResultOutboundNotTransferDetailErrorNumView))
                        .withSideInputs(diffResultOutboundNotTransferDetailErrorNumView)))
                .and(diffResultInboundTransferSummaryTuple.get(settlementCollationOfficerSummaryFileTag)
                    .apply(ParDo
                        .of(new SettlementCollationSetSummaryResultToErrorFn(
                            diffResultInboundTransferDetailErrorNumView))
                        .withSideInputs(diffResultInboundTransferDetailErrorNumView)))
                .and(diffResultInboundNotTransferSummaryTuple.get(settlementCollationOfficerSummaryFileTag)
                    .apply(ParDo
                        .of(new SettlementCollationSetSummaryResultToErrorFn(
                            diffResultInboundNotTransferDetailErrorNumView))
                        .withSideInputs(diffResultInboundNotTransferDetailErrorNumView)))
                // ↓突合しないデータ
                .and(dbSumUnsettledOutbound)
                .and(dbSumUnsettledInbound)
                .and(dbResultLargeOutboundTransferSummary)
                .and(dbResultLargeInboundTransferSummary)
                .apply("merge summary", Flatten.<KV<List<String>, SettlementCollationBase>>pCollections())
                .apply(GroupByKey.<List<String>, SettlementCollationBase>create())
                .apply("transform into summary file format",
                    ParDo.of(new SettlementCollationMergeForOfficerSummaryFn()))
                .apply(GroupByKey.<List<String>, Map<String, List<DataClassBase>>>create())
                .apply(ParDo.of(new SettlementCollationStringifyForOfficerFn(OUTPUT_TYPE_SUMMARY)))
                .apply("wait complete outputTargetForOfficer", Wait.on(outputTargetForOfficer))
                .apply(ParDo
                    .of(new SettlementCollationFileCreateFn(targetDateView, targetBucket,
                        "summary-settlement-collation.{0}.JSON"))
                    .withSideInputs(targetDateView));

        PCollection<String> resultOutputZenginReconcile = todaySettlementTarget
            .apply("wait complete outputTargetSummaryForOfficer", Wait.on(outputTargetSummaryForOfficer))
            .apply("filter output target for reconcile",
                ParDo.of(new SettlementCollationFilterOutputTargetReconcileFn()))
            .apply(GroupByKey.<List<String>, SettlementCollationBase>create())
            .apply(ParDo.of(new SettlementCollationStringifyForReconcileFn()))
            .apply(Combine.globally(new SettlementCollationFileOutputEmptyCheckFn(OUTPUT_TYPE_RECONCILE)))
            .apply(ParDo
                .of(new SettlementCollationFileCreateFn(nextWorkDay, targetBucket, "TransferScheduledDate.{0}.JSON"))
                .withSideInputs(nextWorkDay));

        PCollection<KV<List<String>, SettlementCollationBase>> resultRegisterPending =
            fileDataTuple.get(smallFutureDataTag)
                .apply("wait complete outputTargetSummaryForOfficer", Wait.on(outputTargetSummaryForOfficer))
                .apply("register pending data", ParDo.of(new SettlementCollationResisterPendingFn(spannerDriver,
                    getGrpcQueryConnector(options), dateTimeUtils, options.getTargetDate())));

        targetDate.apply("wait complete resultOutputZenginReconcile", Wait.on(resultOutputZenginReconcile))
            .apply("wait complete resultRegisterPending", Wait.on(resultRegisterPending))
            .apply("move file", ParDo.of(new SettlementCollationMoveCompletedFile(targetBucket)));

        return pipeline.run();
    }

    private GrpcConnector getGrpcCommandConnector(SettlementCollationOptions options) {
        HashMap<String, Object> context = options.getPipelineContext();
        String host = (String) context.get(GRPC_COMMAND_HOST);
        Integer port = (Integer) context.get(GRPC_COMMAND_PORT);
        boolean tls = (boolean) context.get(GRPC_COMMAND_ENABLE_TLS);
        String version = (String) context.get(GRPC_COMMAND_VERSION);

        return new GrpcConnector(host, port, tls, version);
    }

    private GrpcConnector getGrpcQueryConnector(SettlementCollationOptions options) {
        HashMap<String, Object> context = options.getPipelineContext();
        String host = (String) context.get(GRPC_QUERY_HOST);
        Integer port = (Integer) context.get(GRPC_QUERY_PORT);
        boolean tls = (boolean) context.get(GRPC_QUERY_ENABLE_TLS);
        String version = (String) context.get(GRPC_QUERY_VERSION);

        return new GrpcConnector(host, port, tls, version);
    }
}
