/**
 * PipelineにおけるStepの間でデータを受け渡す際に利用するDTOクラスを格納するパッケージ。
 */
package com.neobank.fcore.demanddeposit.dto;
