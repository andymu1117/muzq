SELECT
  a.AccountId,
  a.CustomerId,
  a.AccountManageKey,
  a.AccountNo,
  c.CustomerNo,
  a.CreationUserId,
  a.CreationDate,
  a.UpdatedUserId,
  a.UpdatedDate,
  a.PublishedDate
FROM
  Accounts@{FORCE_INDEX=IDX_Accounts_Status_Valid} a
INNER JOIN
  Customers c
ON
  a.customerId = c.customerId
INNER JOIN
  ItemBsInformations ib
ON
  a.CompanyCode = ib.CompanyCode
AND
  a.ItemCode = ib.ItemCode
WHERE
  (a.AccountStatus = @accountStatusInit or a.AccountStatus = @accountStatusNormal)
AND
  a.AccountCreateDate <= @balanceDateTimeISO
AND
  NOT EXISTS(
    SELECT
      *
    FROM
      DailyBalances db
    WHERE
      a.accountId = db.accountId
    AND
      db.BalanceDate = @balanceDate
   )
AND
  ib.AccountBalanceUpdateFlag = @accountBalanceUpdateFlagUpdate
AND
  NOT EXISTS (
    SELECT
      CancelRevivalType
    FROM
       (
      SELECT
         ac.CancelRevivalType
      FROM
        AccountCancelHistories ac
      WHERE
        a.accountId = ac.accountId
      AND
        ac.CreationDate <= @balanceDateTimeISO
      ORDER BY
        ac.CreationDate DESC
      LIMIT 1
      )
      where
        CancelRevivalType = @accountCancelCustomer
      OR
        CancelRevivalType = @accountCancelBankClerk
    )


