package com.neobank.fcore.demanddeposit.utils;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.date.DateTimeUtils;
import com.accenture.mainri.core.pipeline.options.DefaultOptions;

public class OffsetDateTimeUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(OffsetDateTimeUtils.class);

    private DateTimeFormatter datetimeFormatterWithoutHyphen;
    private DateTimeFormatter datetimeFormatterIso8601;
    private DateTimeUtils dateTimeUtils;
    private ZoneOffset zoneOffset;

    /**
     * DateUtilsのインスタンス取得する。
     * 
     * @param options option
     */
    public OffsetDateTimeUtils(DefaultOptions options) {
        ZoneId zoneId = ZoneId.from(new DateTimeUtils(options).now());
        datetimeFormatterWithoutHyphen = DateTimeFormatter.ofPattern("yyyyMMdd")
            .withZone(zoneId);
        datetimeFormatterIso8601 = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            .withZone(zoneId);
        dateTimeUtils = new DateTimeUtils(options);
        zoneOffset = dateTimeUtils.now()
            .getOffset();
    }

    /**
     * 特定書式(yyyyMMdd)の日付文字列をLocalDateに変換する。
     * 
     * @param date 処理対象
     * @return 処理後の日付
     */
    public LocalDate parserIso8601WithoutHyphenToLocalDate(String date) {
        return LocalDate.parse(date, datetimeFormatterWithoutHyphen);
    }

    /**
     * OffsetDateTimeを特定書式(yyyyMMdd)の日付に変換する。
     * 
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public String formatOffetDateTimeToIso8601WithoutHyphen(OffsetDateTime date) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd")
            .withZone(ZoneId.from(date));
        return date.format(dateTimeFormatter);
    }

    /**
     * OffsetDateTimeを特定書式(yyyy-MM-dd)の日付に変換する。
     * 
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public String formatOffsetDateTimeToIso8601(OffsetDateTime date) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            .withZone(ZoneId.from(date));
        return date.format(dateTimeFormatter);
    }

    /**
     * OffsetDateTimeを今日の最後の時間のStringに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public String formatOffsetDateTimeAsMaxTimeString(OffsetDateTime date) {
        OffsetDateTime todayMaxTime = OffsetDateTime.of(date.toLocalDate(), LocalTime.MAX, date.getOffset());
        return todayMaxTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    /**
     * dateを今日の最後の時間のOffsetDateTimeに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換する。
     *
     * @param date 処理対象
     * @return 処理後のOffsetDateTime
     */
    public OffsetDateTime parserStringDateAsMaxOffsetTime(String date) {
        return OffsetDateTime.of(LocalDate.parse(date), LocalTime.MAX, zoneOffset);
    }

    /**
     * OffsetDateTimeを今日の最初の時間のZonedDateTimeに変更する、そして特定書式(yyyy-MM-ddT00:00:00+Zone)の日付文字列に変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public String formatOffsetDateTimeAsMinTimeString(OffsetDateTime date) {
        OffsetDateTime todayMinTime = OffsetDateTime.of(date.toLocalDate(), LocalTime.MIN, date.getOffset());
        return todayMinTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    /**
     * 特定書式(yyyy-MM-dd)の日付文字列であるかをバリテーションする。
     * 
     * @param date 処理対象
     * @return バリテーション結果（チェックOK：true、チェックNG：false）
     */
    public boolean checkIso8601DateFormat(String date) {
        if (StringUtils.isBlank(date)) {
            LOGGER.debug("inputDate is Null!");
            return false;
        }
        try {
            LocalDate.parse(date, datetimeFormatterIso8601);
        } catch (DateTimeParseException e) {
            LOGGER.debug("inputDate format invalidated! inputDate: {}", date);
            return false;
        }
        return true;
    }

    /**
     * 処理対象日付が未来日ではないかをバリテーションする。
     * 
     * @param date 処理対象
     * @return バリテーション結果（チェックOK：true、チェックNG：false）
     */
    public boolean checkDateIsNotFutureDay(String date) {
        if (!checkIso8601DateFormat(date)) {
            return false;
        }

        OffsetDateTime targetDate = parserStringDateAsMaxOffsetTime(date).minusDays(1);
        if (!dateTimeUtils.now()
            .isAfter(targetDate)) {
            LOGGER.debug("inpueDate can not be after of today! inputDate: {}", date);
            return false;
        }
        return true;

    }

}
