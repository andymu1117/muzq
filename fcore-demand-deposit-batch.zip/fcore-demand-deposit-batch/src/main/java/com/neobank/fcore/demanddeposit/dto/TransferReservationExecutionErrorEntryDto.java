package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.neobank.fcore.demanddeposit.pb.command.message.TransferReservationExecuteRequestOrBuilder;

/**
 * 実行に失敗した予約振込の情報。
 */
@SuppressWarnings("serial")
public class TransferReservationExecutionErrorEntryDto implements Serializable {

    private String outboundTransferId;
    private String errorMessage;

    public String getOutboundTransferId() {
        return outboundTransferId;
    }

    public void setOutboundTransferId(String value) {
        outboundTransferId = value;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String value) {
        errorMessage = value;
    }

    public TransferReservationExecutionErrorEntryDto() {
    }

    /**
     * 失敗した予約振込の情報でオブジェクトを作成する。
     *
     * @param reservation 失敗したリクエスト。
     * @param exception 例外情報
     */
    public TransferReservationExecutionErrorEntryDto(TransferReservationExecuteRequestOrBuilder reservation,
        Exception exception) {
        this.outboundTransferId = reservation.getOutboundTransferId();
        this.errorMessage = exception.getMessage();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.NO_CLASS_NAME_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
