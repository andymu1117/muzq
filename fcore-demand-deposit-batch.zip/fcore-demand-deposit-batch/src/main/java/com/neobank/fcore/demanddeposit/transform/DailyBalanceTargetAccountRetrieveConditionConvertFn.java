package com.neobank.fcore.demanddeposit.transform;

import java.time.OffsetDateTime;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

import com.neobank.fcore.demanddeposit.dto.DailyBalanceTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.pipeline.options.DailyBalanceCreateOption;
import com.neobank.fcore.demanddeposit.utils.OffsetDateTimeUtils;

@SuppressWarnings("serial")
public class DailyBalanceTargetAccountRetrieveConditionConvertFn
    extends DoFn<String, DailyBalanceTargetAccountRetrieveConditionDto> {

    private static final Logger LOGGER =
        LoggerFactory.getLogger(DailyBalanceTargetAccountRetrieveConditionConvertFn.class);

    /**
     * 日次残高確定処理対象口座抽出条件エンティティを作成する。
     *
     * @param element バッチ実行パラメータ（processDate）
     * @param context プロセスコンテクスト
     */
    @ProcessElement
    public void processElement(@Element String element, ProcessContext context) {
        LOGGER.debug("processDate: {}", element);
        DefaultOptions options = context.getPipelineOptions()
            .as(DailyBalanceCreateOption.class);
        OffsetDateTimeUtils offsetDateTimeUtils = new OffsetDateTimeUtils(options);
        if (!offsetDateTimeUtils.checkIso8601DateFormat(element)) {
            LOGGER.error("processDate is illegal argument! processDate: {}", element);
            throw new IllegalArgumentException("element processDate is illegal argument!");
        }
        if (!offsetDateTimeUtils.checkDateIsNotFutureDay(element)) {
            LOGGER.error("inpueDate can not be after of today! inputDate: {}", element);
            throw new IllegalArgumentException("element processDate is illegal argument!");
        }

        OffsetDateTime balanceDateOffsetTime = offsetDateTimeUtils.parserStringDateAsMaxOffsetTime(element)
            .minusDays(1);
        context.output(new DailyBalanceTargetAccountRetrieveConditionDto(
            offsetDateTimeUtils.formatOffetDateTimeToIso8601WithoutHyphen(balanceDateOffsetTime),
            offsetDateTimeUtils.formatOffsetDateTimeAsMaxTimeString(balanceDateOffsetTime)));

    }
}
