package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.commons.collections.IteratorUtils;

import com.accenture.mainri.core.entity.DataClassBase;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile;

/**
 * データ種別ごとにわかれた処理対象データを出力用にまとめる為にキー付与する。
 */
@SuppressWarnings("serial")
public class SettlementCollationMergeForOfficerDetailFn
    extends DoFn<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>,
        // SonarQube対策の為改行
        KV<List<String>, Map<String, List<DataClassBase>>>> {

    /**
     * データ種別ごとにわかれた処理対象データを出力用にまとめる為にキー付与する。
     *
     * @param target 処理対象データ
     * @param context コンテキスト
     */
    @SuppressWarnings("unchecked")
    @ProcessElement
    public void processElement(@Element KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>> target,
        ProcessContext context) {
        Iterable<SettlementCollationOfficerDetailFile> input = context.element()
            .getValue();

        List<SettlementCollationOfficerDetailFile> result = IteratorUtils.toList(input.iterator());

        result.sort((obj1, obj2) -> this.compareTo(obj1.getZenginManageNo(), obj2.getZenginManageNo()));
        result.sort((obj1, obj2) -> this.compareTo(obj1.getAccountManageNo(), obj2.getAccountManageNo()));

        List<DataClassBase> resultDataClassBase = new ArrayList<>();
        result.forEach(resultDataClassBase::add);

        List<String> outputKey = new ArrayList<>();
        outputKey.add("output");

        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(target.getKey()
            .get(0), resultDataClassBase);

        context.output(KV.of(outputKey, resultMap));
    }

    private int compareTo(String str1, String str2) {
        if (java.util.Objects.isNull(str1) && java.util.Objects.isNull(str2)) {
            return 0;
        }
        if (java.util.Objects.isNull(str1)) {
            return 1;
        }
        if (java.util.Objects.isNull(str2)) {
            return -1;
        }
        return str1.compareTo(str2);
    }
}
