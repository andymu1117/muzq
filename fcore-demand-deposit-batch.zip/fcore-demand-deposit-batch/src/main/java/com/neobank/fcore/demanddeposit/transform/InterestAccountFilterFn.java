package com.neobank.fcore.demanddeposit.transform;

import java.time.LocalDate;

import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.commons.lang3.StringUtils;

import com.neobank.fcore.demanddeposit.code.InterestFlag;
import com.neobank.fcore.demanddeposit.code.ItemReferenceFlag;
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity;

@SuppressWarnings("serial")
public class InterestAccountFilterFn
    implements SerializableFunction<InterestAccountFilterWithLocalDateOfInterestDateEntity, Boolean> {

    @Override
    public Boolean apply(InterestAccountFilterWithLocalDateOfInterestDateEntity input) {
        return filterInterestAccount(input);
    }

    /**
     * 利息無しの預金口座をフィルターする。
     *
     * @param element 処理対象の預金口座
     * @return 処理結果（true：フィルターしない、false：フィルターする）
     */
    private boolean filterInterestAccount(InterestAccountFilterWithLocalDateOfInterestDateEntity element) {
        // 口座テーブル.オファリングIDがNULLである場合、抽出対象とする（厳密性のために、普段あり得ないデータも抽出）
        if (StringUtils.isBlank(element.getOfferingId())) {
            return true;
        }

        // オファリングテーブル.オファリングIDがNULLである場合
        if (StringUtils.isBlank(element.getOfferingsOfferingId())) {
            return true;
        }

        LocalDate startDate = element.getSalesStartDate();
        LocalDate endDate = element.getSalesEndDate();
        // 利息基準日 NOT BETWEEN 販売開始日 AND 販売終了日
        if (element.getInterestDateWithoutHyphenToLocalDate()
            .isBefore(startDate)
            || element.getInterestDateWithoutHyphenToLocalDate()
                .isAfter(endDate)) {
            return true;
        }
        // オファリングテーブル.基本商品BS参照フラグ = 0(参照しない) の場合 オファリングテーブル.利息有無フラグ = 1(有)
        // の場合、処理対象の預金口座IDとして抽出する
        return StringUtils.equals(element.getItemReferenceFlag(), ItemReferenceFlag.NO.getCode())
            && StringUtils.equals(element.getOfferingsInterestFlag(), InterestFlag.YES.getCode())
            // オファリングテーブル.基本商品BS参照フラグ = 1(参照する) の場合、基本商品BS情報テーブル.利息有無フラグ = 1(有)
            // の場合、処理対象の預金口座IDとして抽出する
            || (StringUtils.equals(element.getItemReferenceFlag(), ItemReferenceFlag.YES.getCode())
                && StringUtils.equals(element.getInterestFlag(), InterestFlag.YES.getCode()));
    }
}
