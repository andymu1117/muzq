package com.neobank.fcore.demanddeposit.transform;

import java.util.List;

import com.google.gson.Gson;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.join.CoGbkResult;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.commons.collections.IteratorUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerSummaryFile;

/**
 * 不整合条件(ファイルとテーブルのいずれか一方にしか存在しないデータ、「金額」が一致しないデータ)を確認する。
 */
@SuppressWarnings("serial")
public class SettlementCollationCheckAmountSummaryFn extends DoFn<KV<List<String>, CoGbkResult>, Integer> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationCheckAmountSummaryFn.class);

    private TupleTag<SettlementCollationBase> fileDataTag;
    private TupleTag<SettlementCollationBase> databaseDataTag;
    private PCollectionView<Integer> fileBeforeSettlementNum;
    private TupleTag<Integer> errorNumTag;
    private TupleTag<KV<List<String>, SettlementCollationBase>> settlementCollationOfficerSummaryFileTag;

    private Enum<SettlementCollationDataTypeCode> dataType;

    /**
     * 値設定のコンストラクタ。
     *
     * @param fileDataTag リコンサイルファイル用のタグ
     * @param databaseDataTag リコンサイル情報用のタグ
     * @param errorNumTag エラー数出力用タグ
     * @param settlementCollationOfficerSummaryFileTag 結果データ出力用タグ
     * @param dataType 処理種別
     * @param fileBeforeSettlementNum ファイルの前営業日決済レコード数
     */
    public SettlementCollationCheckAmountSummaryFn(TupleTag<SettlementCollationBase> fileDataTag,
        TupleTag<SettlementCollationBase> databaseDataTag, TupleTag<Integer> errorNumTag,
        TupleTag<KV<List<String>, SettlementCollationBase>> settlementCollationOfficerSummaryFileTag,
        Enum<SettlementCollationDataTypeCode> dataType, PCollectionView<Integer> fileBeforeSettlementNum) {
        this.fileDataTag = fileDataTag;
        this.databaseDataTag = databaseDataTag;
        this.errorNumTag = errorNumTag;
        this.settlementCollationOfficerSummaryFileTag = settlementCollationOfficerSummaryFileTag;
        this.dataType = dataType;
        this.fileBeforeSettlementNum = fileBeforeSettlementNum;
    }

    /**
     * 不整合条件(ファイルとテーブルのいずれか一方にしか存在しないデータ、「金額」が一致しないデータ)を確認する。
     *
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(ProcessContext context) {
        KV<List<String>, CoGbkResult> element = context.element();
        Gson gson = new Gson();

        // 本機能内で生成した変数で型が自明な為、チェック対象外とする。
        @SuppressWarnings("unchecked")
        List<SettlementCollationBase> fileList = IteratorUtils.toList(element.getValue()
            .getAll(fileDataTag)
            .iterator());
        // 本機能内で生成した変数で型が自明な為、チェック対象外とする。
        @SuppressWarnings("unchecked")
        List<SettlementCollationBase> dbList = IteratorUtils.toList(element.getValue()
            .getAll(databaseDataTag)
            .iterator());

        boolean errorFlag = false;
        // DB/FILEデータのリストは1/0件以外取り得ない
        if (fileList.size() == 1 && dbList.size() == 1) {
            // 「金額」一致を確認する
            Long fileAmount = fileList.get(0)
                .getAmount();
            Long dbAmount = dbList.get(0)
                .getAmount();
            if (!fileAmount.equals(dbAmount)) {
                errorFlag = true;
            }
        } else {
            // ファイルとテーブルのいずれか一方にしか存在しないデータ
            errorFlag = true;
        }

        SettlementCollationOfficerSummaryFile result = new SettlementCollationOfficerSummaryFile();
        SettlementCollationOfficerSummaryFile db =
            (SettlementCollationOfficerSummaryFile) (dbList.isEmpty() ? new SettlementCollationOfficerSummaryFile()
                : dbList.get(0));

        // ファイルの数量項目には前営業日決済レコードの数を入れている
        result.setAmount(db.getAmount());
        Long number;
        if (context.sideInput(fileBeforeSettlementNum) > 0) {
            number = db.getNumber() + context.sideInput(fileBeforeSettlementNum) - 1;
        } else {
            number = db.getNumber();
        }
        result.setNumber(number);
        if (errorFlag) {
            String fileListString = gson.toJson(fileList);
            String dbListString = gson.toJson(dbList);
            LOGGER.warn(
                "settlement collation summary collation failed: "
                    + "settlementCollationDataTypeCode[{}], file records{}, db records{}",
                ((SettlementCollationDataTypeCode) dataType).getCode(), fileListString, dbListString);
            result.setErrorFlag("1");
            context.output(errorNumTag, 1);
        } else {
            result.setErrorFlag("0");
            context.output(errorNumTag, 0);
        }
        LOGGER.debug("summary collation result keys[{}], result[{}]", element.getKey(), result);
        context.output(settlementCollationOfficerSummaryFileTag, KV.of(element.getKey(), result));
    }
}
