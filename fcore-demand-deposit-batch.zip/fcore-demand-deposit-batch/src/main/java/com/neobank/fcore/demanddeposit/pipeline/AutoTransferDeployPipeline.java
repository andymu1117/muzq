package com.neobank.fcore.demanddeposit.pipeline;

import java.util.HashMap;
import java.util.List;

import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.spanner.ReadOperation;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.resultset.SpannerResultToEntitiesConverter;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.dto.AutoTransferResponseDto;
import com.neobank.fcore.demanddeposit.entity.AutoTransferEntity;
import com.neobank.fcore.demanddeposit.pipeline.options.AutoTransferDeployOptions;
import com.neobank.fcore.demanddeposit.repository.AutoTransferStatementBuilder;
import com.neobank.fcore.demanddeposit.transform.AutoTransferDeployRequestConvertFn;
import com.neobank.fcore.demanddeposit.transform.grpc.AutoTransferDeployApiCaller;
import com.neobank.fcore.demanddeposit.utils.DemandDepositGrpcPropertyUtil;

/**
 * AutoTransferDeploy 自動振込展開 [--pipelineName=auto-transfer-deploy --targetDate=YYYY-MM-DD。
 *
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "auto-transfer-deploy", optionClass = AutoTransferDeployOptions.class)
public class AutoTransferDeployPipeline extends PipelineTemplate<AutoTransferDeployOptions> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AutoTransferDeployPipeline.class);
    private SpannerResultToEntitiesConverter converter = new SpannerResultToEntitiesConverter();

    @Override
    public PipelineResult run(AutoTransferDeployOptions options) {

        LOGGER.info("Auto Transfer Deploy - start");
        Pipeline pipeline = Pipeline.create(options);
        final SpannerDriver spannerDriver = new SpannerDriver(options);
        PCollection<KV<String, Iterable<AutoTransferEntity>>> processTargets =
            selectProcessTargetRecords(pipeline, spannerDriver, options);
        autoTransferDeploy(processTargets, options);
        LOGGER.info("Auto Transfer Deploy - end");
        return pipeline.run();
    }

    /**
     * 自動振込対象をspannerから取得。
     *
     * @param pipeline pipelineのインスタンス
     * @param spannerDriver spannerアクセス用のDriver
     * @param options pipelineのオプション
     * @return PCollection
     */
    private PCollection<KV<String, Iterable<AutoTransferEntity>>> selectProcessTargetRecords(Pipeline pipeline,
        final SpannerDriver spannerDriver, final AutoTransferDeployOptions options) {

        LOGGER.info("selectProcessTargetRecords - start");
        final HashMap<String, Object> ctx = options.getPipelineContext();

        PCollection<KV<String, Iterable<AutoTransferEntity>>> processTargets =
            pipeline.apply("Read parameter", Create.ofProvider(options.getTargetDate(), StringUtf8Coder.of()))
                .apply("Create Read operation", MapElements.into(TypeDescriptor.of(ReadOperation.class))
                    .via((String targetDate) -> {
                        Statement statement =
                            new AutoTransferStatementBuilder().createSelectBatchTargets(ctx, targetDate);
                        return ReadOperation.create()
                            .withQuery(statement);
                    }))
                .apply("Read data from Spanner", spannerDriver.readAll(false))
                .apply("Create AutoTransferEntity", MapElements.into(TypeDescriptor.of(AutoTransferEntity.class))
                    .via((Struct input) -> {
                        AutoTransferEntity result = converter.convert(input, AutoTransferEntity.class);

                        LOGGER.info("read entity: {}", result);
                        return result;
                    }))
                .apply(ParDo.of(new MakeKeyValue()))
                .apply(GroupByKey.<String, AutoTransferEntity>create());

        LOGGER.info("selectProcessTargetRecords - end");
        return processTargets;
    }

    /**
     * 自動振込展開API実行。
     *
     * @param autoTransferSuccessResult AutoTransferEntity
     * @param options AutoTransferDeployOptions
     * @return PCollection
     */
    private PCollection<List<AutoTransferResponseDto>> autoTransferDeploy(
        PCollection<KV<String, Iterable<AutoTransferEntity>>> autoTransferSuccessResult,
        AutoTransferDeployOptions options) {
        final TupleTag<List<AutoTransferResponseDto>> successTag = new TupleTag<List<AutoTransferResponseDto>>() {};

        return autoTransferSuccessResult.apply(ParDo.of(new AutoTransferDeployRequestConvertFn()))
            .apply(ParDo
                .of(new AutoTransferDeployApiCaller(
                    new GrpcConnector(DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceHost(options),
                        DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServicePort(options),
                        DemandDepositGrpcPropertyUtil.isTlsEnabledForGrpcDemandDepositService(options),
                        DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceVersion(options)),
                    successTag, options.getProgramId()))
                .withOutputTags(successTag, TupleTagList.empty()))
            .get(successTag);
    }

    private static class MakeKeyValue extends DoFn<AutoTransferEntity, KV<String, AutoTransferEntity>> {
        @ProcessElement
        public void processElement(ProcessContext pc) {
            pc.output(KV.of(pc.element()
                .getAccountId(), pc.element()));
        }
    }
}
