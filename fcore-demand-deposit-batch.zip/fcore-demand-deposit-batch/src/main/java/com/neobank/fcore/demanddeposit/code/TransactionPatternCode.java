package com.neobank.fcore.demanddeposit.code;

/**
 * 取引パターンコード。
 */
public enum TransactionPatternCode {
    /** 利息決算(元加)。 */
    TRANSACTIONPATTERNCODEINTERESTSETTLEMENT("A004", "00");

    private final String code;
    private final String subCode;

    TransactionPatternCode(String code, String subCode) {
        this.code = code;
        this.subCode = subCode;
    }

    public String getCode() {
        return code;
    }

    public String getSubCode() {
        return subCode;
    }
}
