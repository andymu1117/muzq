package com.neobank.fcore.demanddeposit.transform;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("serial")
public class SettlementCollationCheckErroredNumberFn extends DoFn<Integer, Integer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationCheckErroredNumberFn.class);

    /**
     * エラーがあった場合、突合内容とエラー数をログ出力する。
     *
     * @param errorCount エラー数
     * @param out エラー数
     */
    @ProcessElement
    public void processElement(@Element Integer errorCount, OutputReceiver<Integer> out) {

        if (errorCount != 0) {
            LOGGER.warn("settlement collation detail error records found: errorCount:{}", errorCount);
        }
        out.output(errorCount);
    }
}
