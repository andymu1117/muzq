package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.GsonBuilder;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;

/**
 * オブジェクトを出力用に文字列化する。
 */
@SuppressWarnings("serial")
public class SettlementCollationStringifyForReconcileFn
    extends DoFn<KV<List<String>, Iterable<SettlementCollationBase>>, String> {

    /**
     * オブジェクトを出力用に文字列化する。
     *
     * @param target target
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, Iterable<SettlementCollationBase>> target,
        ProcessContext context) {
        Iterable<SettlementCollationBase> input = context.element()
            .getValue();

        List<SettlementCollationBase> result = new ArrayList<>();
        input.forEach(result::add);

        context.output(new GsonBuilder().serializeNulls()
            .create()
            .toJson(result));
    }
}
