package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.ReadOnlyTransaction;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.accenture.mainri.core.io.SpannerDriver;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.repository.SettlementCollationStatementBuilder;

/**
 * 保留中のデータから突合の対象となるDBレコードを取得する。
 */
@SuppressWarnings({"serial", "squid:S1948"})
public class SettlementCollationSelectPendingsFn extends DoFn<String, KV<List<String>, SettlementCollationBase>> {

    private transient DatabaseClient dbClient;
    private transient Spanner spanner;
    // シリアライズ可能な値が設定される
    private HashMap<String, Object> ctx;
    private SpannerDriver spannerDriver;

    private SettlementCollationStatementBuilder settlementCollationStatementBuilder;

    /**
     * 値設定用のコンストラクタ。
     *
     * @param spannerDriver SpannerDriver
     * @param ctx コンテキスト
     */
    // 引数のctxにHashMapが設定される前提のメソッドであるため
    @SuppressWarnings("squid:S1319")
    public SettlementCollationSelectPendingsFn(SpannerDriver spannerDriver, HashMap<String, Object> ctx) {
        this.spannerDriver = spannerDriver;
        this.ctx = ctx;
    }

    /**
     * 初期処理（DB）。
     */
    @Setup
    public void setUp() {
        this.spanner = this.spannerDriver.createService();
        this.dbClient = this.spannerDriver.createDatabaseClient(this.spanner);
        this.settlementCollationStatementBuilder = new SettlementCollationStatementBuilder();
    }

    /**
     * 保留中のデータから突合の対象となるDBレコードを取得する。 出力形式はKV構造で、キーはDBレコードとの紐づけに必要な管理番号。
     *
     * @param targetDate 対象日付
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element String targetDate, ProcessContext context) {
        try (ReadOnlyTransaction tx = this.dbClient.readOnlyTransaction()) {
            Statement statement =
                this.settlementCollationStatementBuilder.selectSettlementCollationPendings(ctx, targetDate);
            ResultSet selectResult = tx.executeQuery(statement);

            while (selectResult.next()) {
                SettlementCollationFile entity = new SettlementCollationFile(selectResult.getCurrentRowAsStruct());
                List<String> keys = new ArrayList<>();
                keys.add(entity.getManagementNumber());
                context.output(KV.of(keys, entity));
            }
        }
    }

    /**
     * DB接続を閉じる。
     */
    @Teardown
    public void tearDown() {
        this.spanner.close();
    }
}
