package com.neobank.fcore.demanddeposit.code;

/**
 * 口座残高更新フラグ。
 *
 */
public enum AccountBalanceUpdateFlag {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:226] 口座残高更新フラグ
    UPDATE("1"), NOT_UPDATE("2");
    // --- Generated Code Ends---

    private String code;

    AccountBalanceUpdateFlag(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
