package com.neobank.fcore.demanddeposit.grpc;

public class GrpcFieldError {
    String field;
    String message;

    public GrpcFieldError(String field, String message) {
        this.field = field;
        this.message = message;
    }

    public String getField() {
        return field;
    }

    public String getMessage() {
        return message;
    }
}
