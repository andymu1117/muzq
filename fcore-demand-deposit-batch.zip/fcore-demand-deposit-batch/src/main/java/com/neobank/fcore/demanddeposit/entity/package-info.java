/**
 * DBのレコードを表すEntityクラスを格納するパッケージ。
 */
package com.neobank.fcore.demanddeposit.entity;
