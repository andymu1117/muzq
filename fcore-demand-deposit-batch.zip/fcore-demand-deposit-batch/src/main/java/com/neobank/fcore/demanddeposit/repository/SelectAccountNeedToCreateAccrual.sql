SELECT DISTINCT
  a.AccountId
  , a.AccountNo
  , a.AccountManageKey
  , a.CustomerId
  , c.CustomerNo
  , a.OfferingId
  , ib.InterestFlag
  , o.SalesStartDate
  , o.SalesEndDate
  , o.ItemReferenceFlag
  , o.InterestFlag AS OfferingsInterestFlag
  , o.OfferingId AS OfferingsOfferingId
  , @interestDate AS InterestDate
  , a.CreationUserId
  , a.CreationDate
  , a.UpdatedUserId
  , a.UpdatedDate
  , a.PublishedDate
FROM
  Accounts@{FORCE_INDEX=IDX_Accounts_Status_Valid} a
  INNER JOIN Customers c
    ON a.CustomerId = c.CustomerId
    AND c.CustomerStatus = @customerStatusNormal
  INNER JOIN ItemBsInformations ib
    ON a.CompanyCode = ib.CompanyCode
    AND a.ItemCode = ib.ItemCode
  INNER JOIN AccountInterests acti
    ON a.accountId = acti.accountId
    AND acti.InterestDate <= @interestDate
    AND acti.PaymentStatus = @unpaid
  LEFT JOIN Offerings o
    ON a.OfferingId = o.OfferingId
    AND a.CompanyCode = o.CompanyCode
WHERE
  a.AccountManageKey = @accountManageKeyOrdinary
  AND a.AccountCreateDate <= @interestDateMaxTime
  AND a.AccountStatus = @accountStatusNormal
  AND NOT EXISTS (
    SELECT
      *
    FROM
      AccountSuspensionCauses atsc
    WHERE
      a.AccountId = atsc.AccountId
      AND atsc.SuspensionFlag = @suspensionFlagOn
      AND (
        atsc.SuspensionCausesCode = @accountAccrualNot
        OR atsc.SuspensionCausesCode = @accountDormant
      )
  )
