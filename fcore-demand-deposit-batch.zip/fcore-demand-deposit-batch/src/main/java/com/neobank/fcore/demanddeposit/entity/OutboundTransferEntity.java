package com.neobank.fcore.demanddeposit.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;

import com.accenture.mainri.core.entity.BaseEntity;
import com.accenture.mainri.core.entity.annotation.PrimaryKey;
import com.accenture.mainri.core.entity.annotation.Table;

/**
 * 仕向振込に必要な情報。 ADIPから生成し、不要な項目を削除、必要な項目を追加しています。
 */
@SuppressWarnings("serial")
@Table("OutboundTransfers")
public class OutboundTransferEntity extends BaseEntity implements Serializable {
    // 仕向振込ID
    @PrimaryKey(order = 1)
    private String outboundTransferId;
    // 預金口座ID
    private String accountId;
    // 取引パターンコード
    private String transactionPatternCode;
    // 取引パターンサブコード
    private String transactionPatternSubCode;
    // 自動振込の作成時刻
    private OffsetDateTime autoTransferCreationDate;

    public void setOutboundTransferId(String outboundTransferId) {
        this.outboundTransferId = outboundTransferId;
    }

    public String getOutboundTransferId() {
        return outboundTransferId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setTransactionPatternCode(String transactionPatternCode) {
        this.transactionPatternCode = transactionPatternCode;
    }

    public String getTransactionPatternCode() {
        return transactionPatternCode;
    }

    public void setTransactionPatternSubCode(String transactionPatternSubCode) {
        this.transactionPatternSubCode = transactionPatternSubCode;
    }

    public String getTransactionPatternSubCode() {
        return transactionPatternSubCode;
    }

    public void setAutoTransferCreationDate(OffsetDateTime autoTransferCreationDate) {
        this.autoTransferCreationDate = autoTransferCreationDate;
    }

    public OffsetDateTime getAutoTransferCreationDate() {
        return autoTransferCreationDate;
    }
}
