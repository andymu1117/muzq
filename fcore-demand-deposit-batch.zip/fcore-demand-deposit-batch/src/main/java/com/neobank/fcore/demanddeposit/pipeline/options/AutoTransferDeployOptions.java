package com.neobank.fcore.demanddeposit.pipeline.options;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.Validation;
import org.apache.beam.sdk.options.ValueProvider;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

/**
 * 起動パラメータ。
 *
 */
public interface AutoTransferDeployOptions extends DefaultOptions {

    @Description("Parameter")
    @Validation.Required
    ValueProvider<String> getTargetDate();

    @Description("ProgramId")
    @Default.String("DBT002F")
    String getProgramId();

    void setProgramId(String programId);

    void setTargetDate(ValueProvider<String> value);
}
