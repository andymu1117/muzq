package com.neobank.fcore.demanddeposit.pipeline;

import java.util.HashMap;

import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.spanner.ReadOperation;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Filter;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.resultset.SpannerResultToEntitiesConverter;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineRepartitioner;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.dto.ErrorLogEntryDto;
import com.neobank.fcore.demanddeposit.dto.UnpaidInterestCreateResponseDto;
import com.neobank.fcore.demanddeposit.dto.UnpaidInterestTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterEntity;
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity;
import com.neobank.fcore.demanddeposit.pipeline.options.UnpaidInterestCreateOptions;
import com.neobank.fcore.demanddeposit.repository.AccountDeterminationStatementBuilder;
import com.neobank.fcore.demanddeposit.transform.InterestAccountFilterFn;
import com.neobank.fcore.demanddeposit.transform.InterestAccountFilterWithLocalDateOfInterestDateConvertFn;
import com.neobank.fcore.demanddeposit.transform.UnpaidInterestTargetAccountRetrieveConditionConvertFn;
import com.neobank.fcore.demanddeposit.transform.grpc.UnpaidInterestCreateApiCaller;
import com.neobank.fcore.demanddeposit.utils.DemandDepositGrpcPropertyUtil;

/**
 * UnpaidInterestCreate 未払い利息計算バッチ [--pipelineName=unpaid-interest-create --processDate=YYYY-MM-DD]。
 *
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "unpaid-interest-create", optionClass = UnpaidInterestCreateOptions.class)
public class UnpaidInterestCreatePipeline extends PipelineTemplate<UnpaidInterestCreateOptions> {
    private static final Logger LOGGER = LoggerFactory.getLogger(UnpaidInterestCreatePipeline.class);
    private SpannerResultToEntitiesConverter converter = new SpannerResultToEntitiesConverter();

    @Override
    public PipelineResult run(UnpaidInterestCreateOptions options) {
        LOGGER.info("unpaid interest create - start");
        Pipeline pipeline = Pipeline.create(options);
        final SpannerDriver spannerDriver = new SpannerDriver(options);
        PCollection<UnpaidInterestTargetAccountRetrieveConditionDto> retrieveConditionPCollection =
            unpaidInterestCreateOpitionConverter(pipeline, options);
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> processTargets =
            selectAccountNeedToCreateUnpaidInterest(retrieveConditionPCollection, spannerDriver, options);
        createUnpaidInterest(processTargets, options);
        LOGGER.info("unpaid interest create - end");
        return pipeline.run();
    }

    /**
     * バッチ実行パラメータを変換する。
     *
     * @param pipeline pipelineのインスタンス
     * @param options アクセス用のoptions
     * @return バッチ実行パラメータ（processDate）のPCollection
     */
    private PCollection<UnpaidInterestTargetAccountRetrieveConditionDto> unpaidInterestCreateOpitionConverter(
        Pipeline pipeline, final UnpaidInterestCreateOptions options) {
        return pipeline.apply("Read parameters", Create.ofProvider(options.getProcessDate(), StringUtf8Coder.of()))
            .apply("Convert options", ParDo.of(new UnpaidInterestTargetAccountRetrieveConditionConvertFn()));
    }

    /**
     * 未払い利息計算処理対象口座をspannerから取得。
     *
     * @param retrieveConditionPCollection 処理対象抽出条件のPCollection
     * @param spannerDriver spannerアクセス用のDriver
     * @param options アクセス用のoptions
     * @return 処理対象口座のPCollection
     */
    private PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> selectAccountNeedToCreateUnpaidInterest(
        PCollection<UnpaidInterestTargetAccountRetrieveConditionDto> retrieveConditionPCollection,
        final SpannerDriver spannerDriver, final UnpaidInterestCreateOptions options) {
        final HashMap<String, Object> ctx = options.getPipelineContext();
        return retrieveConditionPCollection
            .apply("Create Read operation", MapElements.into(TypeDescriptor.of(ReadOperation.class))
                .via((UnpaidInterestTargetAccountRetrieveConditionDto conditionEntity) -> {
                    LOGGER.debug("interestDate: {}", conditionEntity.getInterestDateWithoutHyphen());
                    Statement statement = new AccountDeterminationStatementBuilder()
                        .createSelectAccountsNeedToCreateUnpaidInterestStatement(ctx, conditionEntity);
                    LOGGER.debug("sql: {}", statement);
                    return ReadOperation.create()
                        .withQuery(statement);
                }))
            .apply("Read data from Spanner", spannerDriver.readAll(false))
            .apply("Create interestAccountFilterEntity",
                MapElements.into(TypeDescriptor.of(InterestAccountFilterEntity.class))
                    .via((Struct input) -> {
                        InterestAccountFilterEntity result =
                            converter.convert(input, InterestAccountFilterEntity.class);
                        LOGGER.debug("read interestAccountFilterEntity entity: {}", result);
                        return result;
                    }))
            .apply("Convert interestAccountFilterEntity to interestAccountFilterWithLocalDateOfInterestDateEntity",
                ParDo.of(new InterestAccountFilterWithLocalDateOfInterestDateConvertFn()))
            .apply(ParDo.of(new PipelineRepartitioner.AddArbitraryKey<>()))
            .apply(GroupByKey.create())
            .apply(ParDo.of(new PipelineRepartitioner.RemoveArbitraryKey<>()))
            .apply("Filter interestAccountFilterWithLocalDateOfInterestDateEntity",
                Filter.by(new InterestAccountFilterFn()));
    }

    /**
     * 未払い利息計算API実行。
     *
     * @param selectResult 未払い利息計算処理対象口座
     * @param options アクセス用のoptions
     * @return 処理結果のPCollection
     */
    private PCollection<UnpaidInterestCreateResponseDto> createUnpaidInterest(
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> selectResult,
        UnpaidInterestCreateOptions options) {
        final TupleTag<UnpaidInterestCreateResponseDto> successTag = new TupleTag<UnpaidInterestCreateResponseDto>() {};
        final TupleTag<ErrorLogEntryDto> errorTag = new TupleTag<ErrorLogEntryDto>() {};
        final TupleTag<ErrorLogEntryDto> warnTag = new TupleTag<ErrorLogEntryDto>() {};
        PCollectionTuple apiResult = selectResult.apply(ParDo
            .of(new UnpaidInterestCreateApiCaller(
                new GrpcConnector(DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceHost(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServicePort(options),
                    DemandDepositGrpcPropertyUtil.isTlsEnabledForGrpcDemandDepositService(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceVersion(options)),
                successTag, errorTag, warnTag))
            .withOutputTags(successTag, TupleTagList.of(errorTag)
                .and(warnTag)));
        // warn、errorが発生する際に、ログ出力だけをするので、warnTagとerrorTagに対する処理が不要
        return apiResult.get(successTag);
    }
}
