package com.neobank.fcore.demanddeposit.pipeline;

import java.util.HashMap;
import java.util.List;

import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.spanner.ReadOperation;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.resultset.SpannerResultToEntitiesConverter;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.dto.TransferReservationExecuteResponseDto;
import com.neobank.fcore.demanddeposit.entity.OutboundTransferEntity;
import com.neobank.fcore.demanddeposit.pipeline.options.TransferReservationExecuteOptions;
import com.neobank.fcore.demanddeposit.repository.OutboundTransferStatementBuilder;
import com.neobank.fcore.demanddeposit.transform.TransferReservationExecuteRequestConvertFn;
import com.neobank.fcore.demanddeposit.transform.grpc.TransferReservationExecuteApiCaller;
import com.neobank.fcore.demanddeposit.utils.DemandDepositGrpcPropertyUtil;

/**
 * TransferReservationExecute 振込予約実行 [--pipelineName=transfer-reservation-execute
 * --targetDate=YYYY-MM-DD]。
 *
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "transfer-reservation-execute", optionClass = TransferReservationExecuteOptions.class)
public class TransferReservationExecutePipeline extends PipelineTemplate<TransferReservationExecuteOptions> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransferReservationExecutePipeline.class);
    private SpannerResultToEntitiesConverter converter = new SpannerResultToEntitiesConverter();

    @Override
    public PipelineResult run(TransferReservationExecuteOptions options) {

        LOGGER.info("Transfer Reservation Execute - start");
        Pipeline pipeline = Pipeline.create(options);

        final SpannerDriver spannerDriver = new SpannerDriver(options);

        PCollection<KV<String, Iterable<OutboundTransferEntity>>> processTargets =
            selectProcessTargetRecords(pipeline, spannerDriver, options);

        transferReservationExecute(processTargets, options);
        LOGGER.info("Transfer Reservation Execute - end");
        return pipeline.run();
    }

    /**
     * 振込対象をspannerから取得。
     *
     * @param pipeline pipelineのインスタンス
     * @param spannerDriver spannerアクセス用のDriver
     * @param options pipelineのオプション
     * @return PCollection
     */
    private PCollection<KV<String, Iterable<OutboundTransferEntity>>> selectProcessTargetRecords(Pipeline pipeline,
        final SpannerDriver spannerDriver, final TransferReservationExecuteOptions options) {

        LOGGER.info("selectProcessTargetRecords - start");
        final HashMap<String, Object> ctx = options.getPipelineContext();

        PCollection<KV<String, Iterable<OutboundTransferEntity>>> processTargets =
            pipeline.apply("Read parameter", Create.ofProvider(options.getTargetDate(), StringUtf8Coder.of()))
                .apply("Create Read operation", MapElements.into(TypeDescriptor.of(ReadOperation.class))
                    .via((String targetDate) -> {
                        Statement statement =
                            new OutboundTransferStatementBuilder().createSelectBatchTargets(ctx, targetDate);
                        return ReadOperation.create()
                            .withQuery(statement);
                    }))
                .apply("Read data from Spanner", spannerDriver.readAll(false))
                .apply("Create OutboundTransferEntity",
                    MapElements.into(TypeDescriptor.of(OutboundTransferEntity.class))
                        .via((Struct input) -> {

                            OutboundTransferEntity result = converter.convert(input, OutboundTransferEntity.class);

                            LOGGER.debug("read entity: {}", result);
                            return result;
                        }))
                .apply(ParDo.of(new MakeKeyValue()))
                .apply(GroupByKey.<String, OutboundTransferEntity>create());

        LOGGER.info("selectProcessTargetRecords - end");
        return processTargets;
    }

    /**
     * 振込予約実行API実行。
     *
     * @param transferReservationExecuteSuccessResult OutboundTransferEntity
     * @param options TransferReservationExecuteOptions
     * @return PCollection
     */
    private PCollection<List<TransferReservationExecuteResponseDto>> transferReservationExecute(
        PCollection<KV<String, Iterable<OutboundTransferEntity>>> transferReservationExecuteSuccessResult,
        TransferReservationExecuteOptions options) {
        final TupleTag<List<TransferReservationExecuteResponseDto>> successTag =
            new TupleTag<List<TransferReservationExecuteResponseDto>>() {};

        return transferReservationExecuteSuccessResult.apply(ParDo.of(new TransferReservationExecuteRequestConvertFn()))
            .apply(ParDo
                .of(new TransferReservationExecuteApiCaller(
                    new GrpcConnector(DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceHost(options),
                        DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServicePort(options),
                        DemandDepositGrpcPropertyUtil.isTlsEnabledForGrpcDemandDepositService(options),
                        DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceVersion(options)),
                    successTag, options.getProgramId()))
                .withOutputTags(successTag, TupleTagList.empty()))
            .get(successTag);
    }

    private static class MakeKeyValue extends DoFn<OutboundTransferEntity, KV<String, OutboundTransferEntity>> {
        @ProcessElement
        public void processElement(ProcessContext pc) {
            pc.output(KV.of(pc.element()
                .getAccountId(), pc.element()));
        }
    }

}
