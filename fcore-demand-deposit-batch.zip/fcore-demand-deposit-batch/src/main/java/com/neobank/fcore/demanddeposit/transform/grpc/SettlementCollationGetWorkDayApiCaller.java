package com.neobank.fcore.demanddeposit.transform.grpc;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.grpc.ManagedChannel;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.io.GrpcConnector;

import com.neobank.fcore.demanddeposit.exception.SystemFailureException;
import com.neobank.fcore.demanddeposit.pb.query.PublicHolidayQueryForOperationGrpc;
import com.neobank.fcore.demanddeposit.pb.query.PublicHolidayQueryForOperationGrpc.PublicHolidayQueryForOperationBlockingStub;
import com.neobank.fcore.demanddeposit.pb.query.QueryVersion;
import com.neobank.fcore.demanddeposit.pb.query.message.PublicHolidayCalculateBusinessDateRequest;
import com.neobank.fcore.demanddeposit.pb.query.message.PublicHolidayCalculateBusinessDateResponse;
import com.neobank.fcore.demanddeposit.utils.DateUtils;
import com.neobank.fcore.demanddeposit.utils.GrpcUtils;

/**
 * 祝日取得API(営業日取得)を呼び出す。
 */
public class SettlementCollationGetWorkDayApiCaller extends DoFn<String, String> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationGetWorkDayApiCaller.class);

    private GrpcConnector grpcConnector;
    private transient PublicHolidayQueryForOperationBlockingStub stub;
    private transient ManagedChannel channel;
    private int workDays;

    /**
     * コンストラクタ。
     *
     * @param grpcConnector GrpcConnector
     * @param workDays 取得する営業日(+-数値)
     */
    public SettlementCollationGetWorkDayApiCaller(GrpcConnector grpcConnector, int workDays) {
        this.grpcConnector = grpcConnector;
        this.workDays = workDays;
    }

    /**
     * gRPCクライアントの初期化。
     */
    @Setup
    public void setup() {
        // stub, channelともにThreadsafeのためstubはここでキャッシュ。
        channel = grpcConnector.createManagedChannel();
        stub = PublicHolidayQueryForOperationGrpc.newBlockingStub(channel);
    }

    /**
     * 祝日取得API(営業日取得)を呼び出す。
     *
     * @param targetDate 対象日付
     * @param out 出力用変数
     * @throws JsonProcessingException Jsonのパースに失敗した際の例外
     */
    @ProcessElement
    public void processElement(@Element String targetDate, OutputReceiver<String> out) throws JsonProcessingException {
        PublicHolidayCalculateBusinessDateRequest grpcRequest = PublicHolidayCalculateBusinessDateRequest.newBuilder()
            .setDays(workDays)
            .setTargetDate(DateUtils.parseIso8601WithoutHyphenToLocalDate(targetDate)
                .toString())
            .build();
        PublicHolidayCalculateBusinessDateResponse grpcResponse = null;

        stub = MetadataUtils.attachHeaders(stub, GrpcUtils.createGrpcHeaders(QueryVersion.API_VERSION));
        try {
            grpcResponse = stub.calculateBusinessDate(grpcRequest);
        } catch (RuntimeException e) {
            LOGGER.error("grpc request failed, Request:{}", grpcRequest);
            throw e;
        }

        if (grpcResponse != null) {
            out.output(grpcResponse.getBusinessDate());
        } else {
            LOGGER.error("grpc request failed, Request:{}", grpcRequest);
            throw new SystemFailureException("grpc request failed");
        }
    }

    /**
     * gRPCクライアントのシャットダウン。
     */
    @Teardown
    public void teardown() {
        if (!channel.isShutdown()) {
            channel.shutdown();
        }
    }
}
