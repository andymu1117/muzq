package com.neobank.fcore.demanddeposit.code;

/**
 * ラインコード。
 *
 */
public enum LineSeparator {

    // 改行
    NEW_LINE("\r\n");

    private String code;

    LineSeparator(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
