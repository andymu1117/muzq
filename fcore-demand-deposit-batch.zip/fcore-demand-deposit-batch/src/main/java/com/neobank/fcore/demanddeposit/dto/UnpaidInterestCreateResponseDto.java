package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.neobank.fcore.demanddeposit.pb.command.message.AccountInterestCreateResponse;

@SuppressWarnings("serial")
public class UnpaidInterestCreateResponseDto implements Serializable {
    private AccountInterestCreateResponse accountInterestCreateResponse;

    /**
     * 未払い利息計算APIのレスポンスと後続処理に必要な情報を渡す。
     *
     * @param accountInterestCreateResponse 未払い利息計算APIのレスポンス
     */
    public UnpaidInterestCreateResponseDto(AccountInterestCreateResponse accountInterestCreateResponse) {
        super();
        this.accountInterestCreateResponse = accountInterestCreateResponse;
    }

    public AccountInterestCreateResponse getAccountInterestCreateResponse() {
        return accountInterestCreateResponse;
    }

    public void setAccountInterestCreateResponse(AccountInterestCreateResponse accountInterestCreateResponse) {
        this.accountInterestCreateResponse = accountInterestCreateResponse;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    public UnpaidInterestCreateResponseDto() {

    }
}
