package com.neobank.fcore.demanddeposit.transform;

import java.time.OffsetDateTime;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.dto.UnpaidInterestTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.pipeline.options.UnpaidInterestCreateOptions;
import com.neobank.fcore.demanddeposit.utils.OffsetDateTimeUtils;

@SuppressWarnings("serial")
public class UnpaidInterestTargetAccountRetrieveConditionConvertFn
    extends DoFn<String, UnpaidInterestTargetAccountRetrieveConditionDto> {

    private static final Logger LOGGER =
        LoggerFactory.getLogger(UnpaidInterestTargetAccountRetrieveConditionConvertFn.class);

    /**
     * 未払い利息計算処理対象口座抽出条件エンティティを作成する。
     *
     * @param element バッチ実行パラメータ（processDate）
     * @param context プロセスコンテクスト
     */
    @ProcessElement
    public void processElement(@Element String element, ProcessContext context) {
        LOGGER.debug("processDate: {}", element);
        UnpaidInterestCreateOptions options = context.getPipelineOptions()
            .as(UnpaidInterestCreateOptions.class);
        OffsetDateTimeUtils offsetDateTimeUtils = new OffsetDateTimeUtils(options);
        if (!offsetDateTimeUtils.checkIso8601DateFormat(element)) {
            throw new IllegalArgumentException("The format of element's processDate is invalid.");
        }
        if (!offsetDateTimeUtils.checkDateIsNotFutureDay(element)) {
            throw new IllegalArgumentException("The element's processDate requires a future date.");
        }
        OffsetDateTime interestDateOffsetTime = offsetDateTimeUtils.parserStringDateAsMaxOffsetTime(element)
            .minusDays(1);
        context.output(new UnpaidInterestTargetAccountRetrieveConditionDto(
            offsetDateTimeUtils.formatOffetDateTimeToIso8601WithoutHyphen(interestDateOffsetTime),
            offsetDateTimeUtils.formatOffsetDateTimeAsMinTimeString(interestDateOffsetTime),
            offsetDateTimeUtils.formatOffsetDateTimeAsMaxTimeString(interestDateOffsetTime)));
    }
}
