package com.neobank.fcore.demanddeposit.transform;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.dto.CustomerAdvantageConditionUpdateResponseDto;

@SuppressWarnings("serial")
public class CustomerAdvantageConditionResponseConvertFn
    extends DoFn<CustomerAdvantageConditionUpdateResponseDto, String> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerAdvantageConditionResponseConvertFn.class);

    /**
     * 顧客優遇条件更新APIのレスポンスは出力CSVレコードに変換する。
     *
     * @param element 顧客優遇条件更新APIのレスポンス
     * @param context プロセスコンテクスト
     */
    @ProcessElement
    public void processElement(@Element CustomerAdvantageConditionUpdateResponseDto element, ProcessContext context) {
        LOGGER.debug("CustomerAdvantageConditionUpdateResponseDto: {}", element);
        if (element.getCustomerAdvantageConditionUpdateResponse() != null
            && element.getCustomerAdvantageConditionUpdateResponse()
                .getResultList() != null) {
            element.getCustomerAdvantageConditionUpdateResponse()
                .getResultList()
                .forEach(context::output);
        }
    }
}
