package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.neobank.fcore.demanddeposit.entity.AccountEntity;

@SuppressWarnings("serial")
public class ErrorLogEntryDto implements Serializable {
    // 預金口座ID
    private String accountId;
    // 顧客ID
    private String customerId;
    // 口座科目
    private String accountManageKey;
    // 口座番号
    private String accountNo;
    // 顧客番号
    private String customerNo;
    // エラーメッセージ
    private String errorMessage;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAccountManageKey() {
        return accountManageKey;
    }

    public void setAccountManageKey(String accountManageKey) {
        this.accountManageKey = accountManageKey;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }

    /**
     * アカウント情報と異常情報の組み合わせのコンストラクタ。
     *
     * @param entity 口座情報
     * @param ex 異常対象
     */
    public ErrorLogEntryDto(AccountEntity entity, Exception ex) {
        this.accountId = entity.getAccountId();
        this.accountManageKey = entity.getAccountManageKey();
        this.accountNo = entity.getAccountNo();
        this.customerId = entity.getCustomerId();
        this.customerNo = entity.getCustomerNo();
        this.errorMessage = ex.getMessage();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.NO_CLASS_NAME_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
