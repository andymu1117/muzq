### 仕向（振込以外） 集計値

SELECT
  SUM(CAST(TransactionAmount AS INT64)) as Amount,
  COUNT(TransactionSlipId) as Number
FROM (


--以下提供のSQL
### 仕向（振込以外）
--- 行内振替
SELECT
    ATD.TransactionSlipId
    , ATD.TransactionAmount
    , InnerT.AccManageNo AS ManagementNo
    , ATD.TransactionPatternCode
    , ATD.TransactionPatternSubCode
FROM
    AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_GLCode_AccountTransactionDetails} AS ATD
    INNER JOIN InnerTransfers@{FORCE_INDEX=IDX_First_Hit_Column_TransactionSlipId_InnerTransfers} AS InnerT ON
        ATD.TransactionSlipId = InnerT.TransactionSlipId
    LEFT JOIN
      (
        SELECT
            DISTINCT CANCEL.BaseTransactionSlipId
        FROM
            AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_BaseTransactionSlipId_AccountTransactionDetails} AS CANCEL
        WHERE
            (CANCEL.TransactionPatternCode = 'A003' AND CANCEL.TransactionPatternSubCode = '90')
            AND CANCEL.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan') -- TODO 時間の条件は要確認
            AND CANCEL.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    ) AS CANCEL ON
      ATD.TransactionSlipId = CANCEL.BaseTransactionSlipId
WHERE
    ATD.GLCode = '017400000' -- 未決済為替借
    AND ATD.DrCrType = '2' -- Cr
    AND ATD.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan')
    AND ATD.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    AND ATD.TransactionPatternCode = 'A003' AND ATD.TransactionPatternSubCode = '00'
    AND CANCEL.BaseTransactionSlipId is NULL

--- 他行被仕向入金（振込不能自動返却、先日付振込不能自動返却）
UNION ALL
SELECT
    ATD.TransactionSlipId
    , ATD.TransactionAmount
    , IT.ZenginOperationServerManagementNo AS ManagementNo
    , ATD.TransactionPatternCode
    , ATD.TransactionPatternSubCode
FROM
    InboundTransfers AS IT
    INNER JOIN AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_GLCode_AccountTransactionDetails} AS ATD ON
        IT.TransactionSlipId = ATD.TransactionSlipId
    INNER JOIN
    (
        SELECT * FROM
        (
            SELECT
                ValueDate
                , CoreMoreTimeTypes.CoreMoreTimeType
                , AmPm
                , TIMESTAMP_ADD(TIMESTAMP(ValueDate, 'Japan'), INTERVAL FromHour HOUR) AS BeginDateTime
                , TIMESTAMP_ADD(TIMESTAMP(ValueDate, 'Japan'), INTERVAL ToHour HOUR) AS EndDateTime
            FROM
                UNNEST(GENERATE_DATE_ARRAY(@PreviousBusinessDate, @CurrentBusinessDate)) AS ValueDate
                CROSS JOIN (
                    SELECT '1' AS CoreMoreTimeType
                    UNION ALL SELECT '2') AS CoreMoreTimeTypes
                CROSS JOIN (
                    SELECT 'AM' AS AmPm, 0 AS FromHour, 12 AS ToHour
                    UNION ALL SELECT 'PM', 12, 24) AS AmPms
        ) AS Matrix
        WHERE
            (ValueDate = @PreviousBusinessDate AND CoreMoreTimeType = '2' AND AmPm = 'PM')
            OR  (ValueDate > @PreviousBusinessDate AND ValueDate < @CurrentBusinessDate)
            OR  (ValueDate = @CurrentBusinessDate AND CoreMoreTimeType = '1')
            OR  (ValueDate = @CurrentBusinessDate AND CoreMoreTimeType = '2' AND AmPm = 'AM')
    ) AS VD ON
        ATD.AccountingTime >= VD.BeginDateTime
        AND ATD.AccountingTime < VD.EndDateTime
        AND IT.CoreMoreTimeType = VD.CoreMoreTimeType
    LEFT JOIN
      (
        SELECT
            DISTINCT CANCEL.BaseTransactionSlipId
        FROM
            AccountTransactionDetails@{FORCE_INDEX=IDX_First_Hit_Column_BaseTransactionSlipId_AccountTransactionDetails} AS CANCEL
        WHERE
            (CANCEL.TransactionPatternCode = 'A003' AND CANCEL.TransactionPatternSubCode = '90')
            AND CANCEL.AccountingTime >= TIMESTAMP(DATE_ADD(@PreviousBusinessDate, INTERVAL 1 DAY), 'Japan') -- TODO 時間の条件は要確認
            AND CANCEL.AccountingTime < TIMESTAMP(DATE_ADD(@CurrentBusinessDate, INTERVAL 1 DAY), 'Japan')
    ) AS CANCEL ON
      ATD.TransactionSlipId = CANCEL.BaseTransactionSlipId
WHERE
    ATD.GLCode = '017400000' -- 未決済為替借
    AND ATD.DrCrType = '2' -- Cr
    AND ATD.TransactionPatternCode = 'R008'
    AND ATD.TransactionPatternSubCode IN ('00','01')
    AND CANCEL.BaseTransactionSlipId is NULL



)
