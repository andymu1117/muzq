package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.List;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.StorageException;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.io.GcsHelper;
import com.accenture.mainri.core.io.GcsOperationFailureException;

import com.neobank.fcore.demanddeposit.code.LineSeparator;
import com.neobank.fcore.demanddeposit.utils.Conversion;

/**
 * Google Cloud Storageのファイルを開きバイト配列を取得する。。
 */
@SuppressWarnings("serial")
public class GoogleCloudStorageByteReaderFn extends DoFn<String, List<String>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(GoogleCloudStorageByteReaderFn.class);

    /**
     * GCSのファイルを開きバイト配列を取得する。
     *
     * @param filePath ファイルPath
     * @param out 読み込んだバイト配列
     */
    @ProcessElement
    public void processElement(@Element String filePath, OutputReceiver<List<String>> out) {

        List<String> ret = new ArrayList<>();

        // GCSのファイルをオープンする
        try {
            Blob blob = GcsHelper.getFile(filePath);
            // byte列をUTF8で文字列へ変換する。
            String csvData = Conversion.byteToString(blob.getContent());
            String[] temp = csvData.split(LineSeparator.NEW_LINE.getCode());

            for (String csvLine : temp) {
                if (StringUtils.isNotEmpty(csvLine)) {
                    ret.add(csvLine);
                }
            }
        } catch (StorageException se) {
            // GCS上の処理エラー
            LOGGER.error("File open error", se);
        } catch (GcsOperationFailureException ge) {
            // 処理を行う際のアプリ側例外
            LOGGER.error("File read error", ge);
        }
        // 取得したString配列を返却する
        out.output(ret);
    }
}
