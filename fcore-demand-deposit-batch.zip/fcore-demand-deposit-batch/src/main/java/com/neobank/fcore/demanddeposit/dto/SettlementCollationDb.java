package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import com.google.cloud.spanner.Struct;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@SuppressWarnings("serial")
public class SettlementCollationDb extends SettlementCollationBase implements Serializable {

    // 管理番号
    private String transactionSlipId;
    // 管理番号
    private String managementNumber;

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        // FINDBUGS回避のため、値を変数に設定。
        boolean zenginBankFileHashCode = false;
        return HashCodeBuilder.reflectionHashCode(this, zenginBankFileHashCode);
    }

    public SettlementCollationDb() {
    }

    /**
     * DBレコードを設定する。
     *
     * @param struct DBレコード
     */
    public SettlementCollationDb(Struct struct) {
        transactionSlipId = struct.getString("TransactionSlipId");
        amount = struct.getLong("TransactionAmount");
        managementNumber = struct.getString("ManagementNo");
    }

    public String getTransactionSlipId() {
        return transactionSlipId;
    }

    public void setTransactionSlipId(String transactionSlipId) {
        this.transactionSlipId = transactionSlipId;
    }

    public String getManagementNumber() {
        return managementNumber;
    }

    public void setManagementNumber(String managementNumber) {
        this.managementNumber = managementNumber;
    }

}
