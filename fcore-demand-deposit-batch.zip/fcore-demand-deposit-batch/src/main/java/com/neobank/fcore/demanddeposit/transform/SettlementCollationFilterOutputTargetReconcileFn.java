package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationTransferScheduledDate;

/**
 * オブジェクトを出力用に前営業日決済のデータだけを出力する。
 */
@SuppressWarnings("serial")
public class SettlementCollationFilterOutputTargetReconcileFn
    extends DoFn<KV<List<String>, SettlementCollationBase>, KV<List<String>, SettlementCollationBase>> {

    /**
     * オブジェクトを出力用に前営業日決済のデータだけを出力する。
     *
     * @param target target
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, SettlementCollationBase> target, ProcessContext context) {
        SettlementCollationFile input = (SettlementCollationFile) context.element()
            .getValue();

        if (CommunicationTypeCode.isBeforeSettlementTarget(input.getCommunicationTypeCode())) {
            SettlementCollationTransferScheduledDate output = new SettlementCollationTransferScheduledDate();
            output.setZenginProcessCode(input.getZenginProcessCode());
            output.setManagementNumber(input.getManagementNumber());
            output.setAmount(input.getAmount());
            List<String> outputKey = new ArrayList<>();
            outputKey.add("output");
            context.output(KV.of(outputKey, output));
        }
    }
}
