package com.neobank.fcore.demanddeposit.transform.grpc;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.grpc.Metadata;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.auth.IdToken;
import com.accenture.mainri.core.io.GrpcConnector;

import com.neobank.fcore.demanddeposit.dto.AutoTransferDeploymentErrorEntryDto;
import com.neobank.fcore.demanddeposit.dto.AutoTransferResponseDto;
import com.neobank.fcore.demanddeposit.grpc.GrpcErrorParser;
import com.neobank.fcore.demanddeposit.grpc.GrpcSystemException;
import com.neobank.fcore.demanddeposit.grpc.GrpcValidationException;
import com.neobank.fcore.demanddeposit.pb.command.AutoTransferCommandGrpc;
import com.neobank.fcore.demanddeposit.pb.command.AutoTransferCommandGrpc.AutoTransferCommandBlockingStub;
import com.neobank.fcore.demanddeposit.pb.command.message.AutoTransferDeployRequest;
import com.neobank.fcore.demanddeposit.pb.command.message.AutoTransferDeployResponse;

/**
 * 自動振込展開APIのCaller。
 */
@SuppressWarnings("serial")
public class AutoTransferDeployApiCaller extends DoFn<List<AutoTransferDeployRequest>, List<AutoTransferResponseDto>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AutoTransferDeployApiCaller.class);

    private GrpcConnector grpcConnector;
    private transient AutoTransferCommandBlockingStub stub;
    private TupleTag<List<AutoTransferResponseDto>> successTag;

    private String programId;

    /**
     * エラーハンドリング用のタグとgRPC用の接続を設定するコンストラクタ。
     *
     * @param grpcConnector gRPCのコネクタ
     * @param successTag 正常時の出力先
     * @param programId プログラムId
     */
    public AutoTransferDeployApiCaller(GrpcConnector grpcConnector, TupleTag<List<AutoTransferResponseDto>> successTag,
        String programId) {
        this.grpcConnector = grpcConnector;
        this.successTag = successTag;
        this.programId = programId;
    }

    /**
     * gRPCクライアント初期化。
     */
    @Setup
    public void setup() {
        LOGGER.debug("SetUp Stub.");
        stub = AutoTransferCommandGrpc.newBlockingStub(grpcConnector.createManagedChannel());
    }

    /**
     * 自動振込展開API実行部分。
     *
     * @param element 実行対象のデータ
     * @param context ProcessのContext
     * @throws JsonProcessingException JsonProcessingException
     */
    @ProcessElement
    public void processElement(@Element List<AutoTransferDeployRequest> element, ProcessContext context)
        throws JsonProcessingException {
        long startTimeMillis = System.currentTimeMillis();
        stub = MetadataUtils.attachHeaders(stub, this.createHeaders());
        List<AutoTransferResponseDto> list = new ArrayList<>();

        for (AutoTransferDeployRequest autoTransferDeployRequest : element) {
            deploy(autoTransferDeployRequest, list);
            long processingTimeMillis = System.currentTimeMillis() - startTimeMillis;
            LOGGER.debug("[Processing Time] The processing time of the Interest Rate API is {} ms.",
                processingTimeMillis);
        }
        context.output(successTag, list);
    }

    private void deploy(AutoTransferDeployRequest request, List<AutoTransferResponseDto> list) {
        AutoTransferDeployResponse response;
        LOGGER.debug(request.getAutoTransferId());
        try {
            response = stub.deploy(request);
        } catch (StatusRuntimeException srEx) {
            try {
                GrpcErrorParser.parseErrorResponse(srEx);
            } catch (GrpcSystemException sysEx) {
                AutoTransferDeploymentErrorEntryDto errorLogEntry =
                    new AutoTransferDeploymentErrorEntryDto(request, sysEx);

                LOGGER.error("api request error: {}", errorLogEntry);
            } catch (GrpcValidationException valEx) {
                AutoTransferDeploymentErrorEntryDto errorLogEntry =
                    new AutoTransferDeploymentErrorEntryDto(request, valEx);

                LOGGER.warn("api request warn: {}", errorLogEntry);
            }

            return;
        } catch (RuntimeException ex) {
            AutoTransferDeploymentErrorEntryDto errorLogEntry = new AutoTransferDeploymentErrorEntryDto(request, ex);
            LOGGER.error("api runtime error: {}", errorLogEntry);

            return;
        }

        AutoTransferResponseDto result = new AutoTransferResponseDto(response);
        list.add(result);
        LOGGER.debug("response: {}", result);
    }

    /**
     * リクエストヘッダ生成。
     *
     * @return リクエストヘッダ
     * @throws JsonProcessingException JsonProcessingException
     */
    private Metadata createHeaders() throws JsonProcessingException {
        IdToken idToken = new IdToken();
        ObjectMapper mapper = new ObjectMapper();
        idToken.setSubject(programId);

        String idTokenJson = mapper.writeValueAsString(idToken);
        Metadata headers = new Metadata();
        Metadata.Key<String> idTokenKey = Metadata.Key.of("X-Id-Token", io.grpc.Metadata.ASCII_STRING_MARSHALLER);
        headers.put(idTokenKey, idTokenJson);

        return headers;
    }
}
