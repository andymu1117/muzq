/**
 * 処理対象のデータをSpannerに書き込みを行う{@link org.apache.beam.sdk.io.gcp.spanner.MutationGroup}に変換するTransformを格納するパッケージ。<br>
 *
 * @see com.google.cloud.spanner.Mutation
 */
package com.neobank.fcore.demanddeposit.transform.mutation;
