package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.ReadOnlyTransaction;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollectionView;

import com.accenture.mainri.core.io.SpannerDriver;

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerSummaryFile;
import com.neobank.fcore.demanddeposit.exception.SystemFailureException;
import com.neobank.fcore.demanddeposit.repository.SettlementCollationStatementBuilder;

/**
 * 決済照合の対象となる仕訳明細の集計値を取得する。
 */
@SuppressWarnings({"serial", "squid:S1948"})
public class SettlementCollationSelectSettlementSummaryFn
    extends DoFn<String, KV<List<String>, SettlementCollationBase>> {

    private transient DatabaseClient dbClient;
    private transient Spanner spanner;
    // シリアライズ可能な値が設定される
    private HashMap<String, Object> ctx;
    private SpannerDriver spannerDriver;
    private Enum<SettlementCollationDataTypeCode> dataType;
    private PCollectionView<String> beforeWorkDay;

    private SettlementCollationStatementBuilder settlementCollationStatementBuilder;

    /**
     * 値設定用のコンストラクタ。
     *
     * @param spannerDriver SpannerDriver
     * @param ctx コンテキスト
     * @param dataType 取得する種類
     * @param beforeWorkDay 前営業日
     */
    // 引数のctxにHashMapが設定される前提のメソッドであるため
    @SuppressWarnings("squid:S1319")
    public SettlementCollationSelectSettlementSummaryFn(SpannerDriver spannerDriver, HashMap<String, Object> ctx,
        Enum<SettlementCollationDataTypeCode> dataType, PCollectionView<String> beforeWorkDay) {
        this.spannerDriver = spannerDriver;
        this.ctx = ctx;
        this.dataType = dataType;
        this.beforeWorkDay = beforeWorkDay;
    }

    /**
     * 初期処理（DB）。
     */
    @Setup
    public void setUp() {
        this.spanner = this.spannerDriver.createService();
        this.dbClient = this.spannerDriver.createDatabaseClient(this.spanner);
        this.settlementCollationStatementBuilder = new SettlementCollationStatementBuilder();
    }

    /**
     * 決済照合の対象となる仕訳明細の集計値を取得する。
     *
     * @param targetDate 対象日付
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element String targetDate, ProcessContext context) {
        try (ReadOnlyTransaction tx = this.dbClient.readOnlyTransaction()) {
            Statement statement = this.getSql(targetDate, context);
            ResultSet selectResult = tx.executeQuery(statement);

            while (selectResult.next()) {

                SettlementCollationBase entity = null;
                switch ((SettlementCollationDataTypeCode) dataType) {
                    case DATA_TYPE_INBOUND_TRANSFER:
                    case DATA_TYPE_OUTBOUND_TRANSFER:
                    case DATA_TYPE_INBOUND_NOT_TRANSFER:
                    case DATA_TYPE_OUTBOUND_NOT_TRANSFER:
                        entity = new SettlementCollationOfficerSummaryFile(selectResult.getCurrentRowAsStruct());
                        break;

                    case DATA_TYPE_LARGE_IN:
                    case DATA_TYPE_LARGE_OUT:
                    case DATA_TYPE_INBOUND:
                    case DATA_TYPE_OUTBOUND:
                        entity = new SettlementCollationBase(selectResult.getCurrentRowAsStruct());
                        break;

                    default:
                        throw new SystemFailureException("invalid data type");
                }

                List<String> keys = new ArrayList<>();
                keys.add(((SettlementCollationDataTypeCode) dataType).getCode());
                context.output(KV.of(keys, entity));
            }
        }
    }

    private Statement getSql(String targetDate, ProcessContext context) {
        switch ((SettlementCollationDataTypeCode) dataType) {
            case DATA_TYPE_INBOUND_TRANSFER:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationInboundTransferSummary");
            case DATA_TYPE_OUTBOUND_TRANSFER:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationOutboundTransferSummary");
            case DATA_TYPE_INBOUND_NOT_TRANSFER:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationInboundNotTransferSummary");
            case DATA_TYPE_OUTBOUND_NOT_TRANSFER:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate,
                    "SelectSettlementCollationOutboundNotTransferSummary");

            case DATA_TYPE_LARGE_IN:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationLargeInbound");
            case DATA_TYPE_LARGE_OUT:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationLargeOutbound");
            case DATA_TYPE_INBOUND:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationInbound");
            case DATA_TYPE_OUTBOUND:
                return this.settlementCollationStatementBuilder.selectSettlementCollationData(this.ctx,
                    context.sideInput(beforeWorkDay), targetDate, "SelectSettlementCollationOutbound");

            default:
                throw new SystemFailureException("invalid data type");
        }
    }

    /**
     * DB接続を閉じる。
     */
    @Teardown
    public void tearDown() {
        this.spanner.close();
    }
}
