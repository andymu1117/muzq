package com.neobank.fcore.demanddeposit.utils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.google.common.io.ByteStreams;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.fs.EmptyMatchTreatment;
import org.apache.beam.sdk.io.fs.MatchResult;
import org.apache.beam.sdk.io.fs.MatchResult.Metadata;
import org.apache.beam.sdk.io.fs.MoveOptions.StandardMoveOptions;
import org.apache.beam.sdk.io.fs.ResourceId;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.exception.SystemFailureException;

public class FileUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtils.class);

    private FileUtils() {
    }

    /**
     * 対象のファイルを指定したバケット、フォルダに末尾にsuffixをつけてリネームする。
     *
     * @param renameFromPath リネーム元ファイルのパス
     * @param renameToBucket リネーム先のバケット
     * @param renameToFolder リネーム先のフォルダー
     * @param suffix リネームファイル名の末尾に付けるsuffix null、空文字許容
     * @throws IOException ファイルのリネームが失敗した場合の例外
     */
    public static void renameFile(String renameFromPath, String renameToBucket, String renameToFolder, String suffix)
        throws IOException {
        // ファイルの存在チェック
        List<Metadata> fileMetadataList = FileUtils.matchFile(renameFromPath);

        if (!fileMetadataList.isEmpty()) {
            List<ResourceId> srcRenameIdList = new ArrayList<>();
            List<ResourceId> destRenameIdList = new ArrayList<>();
            for (Metadata metadata : fileMetadataList) {
                ResourceId resourceId = metadata.resourceId();
                srcRenameIdList.add(resourceId);

                StringBuilder destRenameFile = new StringBuilder();
                destRenameFile.append(renameToBucket);
                destRenameFile.append(renameToFolder);
                destRenameFile.append(resourceId.getFilename());
                if (!StringUtils.isEmpty(suffix)) {
                    destRenameFile.append('_');
                    destRenameFile.append(suffix);
                }
                destRenameIdList.add(FileSystems.matchNewResource(destRenameFile.toString(), false));
            }
            // リネーム
            try {
                FileSystems.rename(srcRenameIdList, destRenameIdList, StandardMoveOptions.IGNORE_MISSING_FILES);
            } catch (IOException e) {
                LOGGER.error("file rename error. sourceId:{}, destinationId:{}", ArrayUtils.toString(srcRenameIdList),
                    ArrayUtils.toString(destRenameIdList));
                throw e;
            }
        }
    }

    /**
     * 対象のファイルを読み込みbyte配列を返却する。
     *
     * @param resourceId 対象ファイルのResourceId
     * @return byte配列
     * @throws IOException ファイルの読み込みが失敗した場合の例外
     */
    public static byte[] readFile(ResourceId resourceId) throws IOException {
        byte[] result = null;

        ReadableByteChannel targetChan = FileSystems.open(resourceId);
        try (InputStream targetInputStream = Channels.newInputStream(targetChan);) {
            result = ByteStreams.toByteArray(targetInputStream);
        } catch (IOException e) {
            LOGGER.error("file open error, resourceId:{}", resourceId);
            throw e;
        }
        return result;
    }

    /**
     * 指定された検索条件に合致するファイルを読み込み、バイト配列を返却する。（条件に合致するファイルが１件では無い場合、例外をスロー）
     *
     * @param searchFilePath 読み込むファイルのパス(ワイルドカード利用可能)
     * @return 読み込んだファイルの内容のbyte配列のリスト
     * @throws IOException ファイルの読み込みが失敗した場合の例外
     * @throws SystemFailureException 条件に合致するファイルが1件ではない場合の例外
     */
    public static byte[] readMatchedOnlyOneFile(String searchFilePath) throws IOException {
        List<Metadata> fileMetadataList = FileUtils.matchFile(searchFilePath);

        if (fileMetadataList.size() != 1) {
            throw new SystemFailureException("invalid file number");
        }

        // ファイル取得
        return FileUtils.readFile(fileMetadataList.get(0)
            .resourceId());
    }

    /**
     * 指定された検索条件に合致するファイルを読み込み、バイト配列を返却する。（条件に合致するファイルが１件以上の場合、例外をスロー。0件の場合空の配列文字列("[]")を返却）
     *
     * @param searchFilePath 読み込むファイルのパス(ワイルドカード利用可能)
     * @return 読み込んだファイルの内容のbyte配列のリスト(0件の場合空の配列文字列("[]")を返却)
     * @throws IOException ファイルの読み込みが失敗した場合の例外
     * @throws SystemFailureException 条件に合致するファイルが1件以上の場合に発生する例外
     */
    public static byte[] readMatchedOneOrNoFile(String searchFilePath) throws IOException {
        List<Metadata> fileMetadataList = FileUtils.matchFile(searchFilePath);

        if (fileMetadataList.size() > 1) {
            throw new SystemFailureException("invalid file number");
        } else if (fileMetadataList.isEmpty()) {
            LOGGER.warn("file not found in path: {}", searchFilePath);
            return "[]".getBytes(StandardCharsets.UTF_8);
        }

        // ファイル取得
        return FileUtils.readFile(fileMetadataList.get(0)
            .resourceId());
    }

    /**
     * 対象ファイルの一覧を取得する。
     *
     * @param filePath 対象ファイルのパス
     * @return 対象ファイル一覧
     * @throws IOException ファイル一覧取得が失敗した場合の例外
     */
    public static List<Metadata> matchFile(String filePath) throws IOException {
        // ファイルの存在チェック
        MatchResult match = null;
        try {
            match = FileSystems.match(filePath, EmptyMatchTreatment.ALLOW_IF_WILDCARD);
        } catch (IOException e) {
            LOGGER.error("match resource error, FilePath:{}", filePath);
            throw e;
        }
        return match.metadata();
    }

    /**
     * バイト配列を基に、引数のファイルパスにファイルを出力する。
     *
     * @param filePath 対象ファイルのResourceId
     * @param targetByte byte配列
     * @throws IOException ファイルの出力が失敗した場合の例外
     */
    public static void writeFile(String filePath, byte[] targetByte) throws IOException {
        try (WritableByteChannel chan =
            FileSystems.create(FileSystems.matchNewResource(filePath, false), "text/plain");) {
            chan.write(ByteBuffer.wrap(targetByte));
        } catch (IOException e) {
            LOGGER.error("file output error, FilePath:{}", filePath);
            throw e;
        }
    }
}
