/**
 * {@link com.accenture.mainri.core.pipeline.PipelineTemplate} を実装しているPipelineクラスを格納するパッケージ。
 */
package com.neobank.fcore.demanddeposit.pipeline;
