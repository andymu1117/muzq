package com.neobank.fcore.demanddeposit.pipeline.options;

import javax.validation.constraints.NotBlank;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.ValueProvider;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

/**
 * Google Cloud Storage からファイルを読み込むPipeline用のオプション。
 */
public interface SettlementCollationOptions extends DefaultOptions {
    @Description("Parameter targetDate.")
    @NotBlank
    ValueProvider<String> getTargetDate();

    void setTargetDate(ValueProvider<String> value);

    @Description("Parameter callApi.")
    @Default.Boolean(true)
    ValueProvider<Boolean> getCallApi();

    void setCallApi(ValueProvider<Boolean> value);
}
