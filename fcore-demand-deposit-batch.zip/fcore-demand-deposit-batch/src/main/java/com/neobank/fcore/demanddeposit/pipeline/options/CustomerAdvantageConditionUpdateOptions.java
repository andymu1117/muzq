package com.neobank.fcore.demanddeposit.pipeline.options;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.Validation;
import org.apache.beam.sdk.options.ValueProvider;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

/**
 * 起動パラメータ。
 *
 */
public interface CustomerAdvantageConditionUpdateOptions extends DefaultOptions {
    @Description("ProgramId")
    @Default.String("CBT007F")
    String getProgramId();

    // 起動パラメータから InputFile ["gs://bucket/folder/file"] を受け取る
    @Description("InputFile")
    @Validation.Required
    ValueProvider<String> getInputFile();

    // 起動パラメータから OutputFile ["gs://bucket/folder/file"] を受け取る
    @Description("OutputFile")
    @Validation.Required
    ValueProvider<String> getOutputFile();

    void setInputFile(ValueProvider<String> value);

    void setOutputFile(ValueProvider<String> value);

    void setProgramId(String programId);
}
