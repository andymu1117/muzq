package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.commons.collections.IteratorUtils;

import com.accenture.mainri.core.entity.DataClassBase;

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode;
import com.neobank.fcore.demanddeposit.pipeline.SettlementCollationPipeline;

/**
 * オブジェクトを出力用に文字列化する。
 */
@SuppressWarnings("serial")
public class SettlementCollationStringifyForOfficerFn
    extends DoFn<KV<List<String>, Iterable<Map<String, List<DataClassBase>>>>, String> {

    private String processType;

    public SettlementCollationStringifyForOfficerFn(String processType) {
        this.processType = processType;
    }

    /**
     * オブジェクトを出力用に文字列化する。
     *
     * @param target target
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, Iterable<Map<String, List<DataClassBase>>>> target,
        ProcessContext context) {
        @SuppressWarnings("unchecked")
        Iterable<Map<String, List<DataClassBase>>> input = IteratorUtils.toList(target.getValue()
            .iterator());
        Gson gson = new GsonBuilder().serializeNulls()
            .create();

        if (SettlementCollationPipeline.OUTPUT_TYPE_DETAIL.equals(processType)) {
            Map<String, List<DataClassBase>> mergedMap = new HashMap();
            for (Map<String, List<DataClassBase>> item : input) {
                mergedMap = this.mergeMap(item, mergedMap);
            }
            this.detailSetNull(mergedMap, context, gson);
        } else {
            Map<String, List<DataClassBase>> mergedMap = new HashMap();
            for (Map<String, List<DataClassBase>> item : input) {
                mergedMap = this.mergeMap(item, mergedMap);
            }
            this.summarySetNull(mergedMap, context, gson);
        }

    }

    private Map<String, List<DataClassBase>> mergeMap(Map<String, List<DataClassBase>> input,
        Map<String, List<DataClassBase>> mergedMap) {
        if (input.isEmpty()) {
            return mergedMap;
        } else if (mergedMap.isEmpty()) {
            return input;
        } else {
            return Stream.concat(mergedMap.entrySet()
                .stream(),
                input.entrySet()
                    .stream())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (beforeval, inputval) -> inputval));
        }
    }

    private void summarySetNull(Map<String, List<DataClassBase>> entity, ProcessContext context, Gson gson) {
        Map<String, DataClassBase> result = new HashMap<>();
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_IN.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_IN.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_IN.getCode())
                    .get(0));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_OUT.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_OUT.getCode())) ? null
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_OUT.getCode())
                    .get(0));
        context.output(gson.toJson(result));
    }

    private void detailSetNull(Map<String, List<DataClassBase>> entity, ProcessContext context, Gson gson) {
        Map<String, List<DataClassBase>> result = new HashMap<>();
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode()))
                ? new ArrayList<>()
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode()));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode()))
                ? new ArrayList<>()
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode()));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode()))
                ? new ArrayList<>()
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode()));
        result.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode(),
            Objects.isNull(entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode()))
                ? new ArrayList<>()
                : entity.get(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode()));
        context.output(gson.toJson(result));
    }
}
