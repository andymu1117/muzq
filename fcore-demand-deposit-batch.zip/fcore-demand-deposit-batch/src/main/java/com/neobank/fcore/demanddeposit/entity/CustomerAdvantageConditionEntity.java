package com.neobank.fcore.demanddeposit.entity;

import java.util.List;

import com.accenture.mainri.core.entity.BaseEntity;

public class CustomerAdvantageConditionEntity extends BaseEntity {

    private static final long serialVersionUID = 6386434398450547472L;
    // 更新時間
    private String updatedTime;
    // 顧客優遇条件
    private List<String> customerAdvantageConditions;

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    public List<String> getCustomerAdvantageConditions() {
        return customerAdvantageConditions;
    }

    public void setCustomerAdvantageConditions(List<String> customerAdvantageConditions) {
        this.customerAdvantageConditions = customerAdvantageConditions;
    }

}
