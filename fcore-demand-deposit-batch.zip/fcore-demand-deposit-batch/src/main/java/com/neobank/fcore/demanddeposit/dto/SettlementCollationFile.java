package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;
import java.util.List;

import com.google.cloud.spanner.Struct;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@SuppressWarnings("serial")
public class SettlementCollationFile extends SettlementCollationBase implements Serializable {
    // 全銀処理コード
    private String zenginProcessCode;
    // 管理番号
    private String managementNumber;
    // 通信種目コード
    private String communicationTypeCode;
    // 決済日
    private String settlementDate;
    // 振込指定日
    private String transferScheduledDate;
    // コア・モアタイプ
    private String coreMoreTimeType;
    // 大口フラグ
    private String largeValueTransactionFlag;

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        // FINDBUGS回避のため、値を変数に設定。
        boolean zenginBankFileHashCode = false;
        return HashCodeBuilder.reflectionHashCode(this, zenginBankFileHashCode);
    }

    public SettlementCollationFile() {
    }

    /**
     * DBの値を設定する(決済照合保留)。
     *
     * @param struct 決済照合保留レコード
     */
    public SettlementCollationFile(Struct struct) {
        zenginProcessCode = struct.getString("ZenginProcessCode");
        managementNumber = struct.getString("ManagementNumber");
        communicationTypeCode = struct.getString("CommunicationTypeCode");
        transferScheduledDate = struct.getDate("TransferDate")
            .toString()
            .replace("-", "");
        amount = struct.getLong("TransactionAmount");
        coreMoreTimeType = struct.getString("CoreMoreTimeType");
        largeValueTransactionFlag = struct.getString("LargeValueTransactionFlag");
    }

    /**
     * 値が入ったリストから本Entityのフィールド値を設定する。
     *
     * @param line ファイル値が入ったリスト
     */
    public SettlementCollationFile(List<String> line) {
        zenginProcessCode = line.get(0);
        managementNumber = line.get(1);
        communicationTypeCode = line.get(2);
        transferScheduledDate = line.get(3);
        amount = Long.valueOf(line.get(4));
        coreMoreTimeType = line.get(5);
        largeValueTransactionFlag = line.get(6);
    }

    public void setZenginProcessCode(String zenginProcessCode) {
        this.zenginProcessCode = zenginProcessCode;
    }

    public String getZenginProcessCode() {
        return this.zenginProcessCode;
    }

    public void setManagementNumber(String managementNumber) {
        this.managementNumber = managementNumber;
    }

    public String getManagementNumber() {
        return this.managementNumber;
    }

    public void setCommunicationTypeCode(String communicationTypeCode) {
        this.communicationTypeCode = communicationTypeCode;
    }

    public String getCommunicationTypeCode() {
        return this.communicationTypeCode;
    }

    public void setSettlementDate(String settlementDate) {
        this.settlementDate = settlementDate;
    }

    public String getSettlementDate() {
        return this.settlementDate;
    }

    public void setTransferScheduledDate(String transferScheduledDate) {
        this.transferScheduledDate = transferScheduledDate;
    }

    public String getTransferScheduledDate() {
        return this.transferScheduledDate;
    }

    public void setCoreMoreTimeType(String coreMoreTimeType) {
        this.coreMoreTimeType = coreMoreTimeType;
    }

    public String getCoreMoreTimeType() {
        return this.coreMoreTimeType;
    }

    public void setLargeValueTransactionFlag(String largeValueTransactionFlag) {
        this.largeValueTransactionFlag = largeValueTransactionFlag;
    }

    public String getLargeValueTransactionFlag() {
        return this.largeValueTransactionFlag;
    }
}
