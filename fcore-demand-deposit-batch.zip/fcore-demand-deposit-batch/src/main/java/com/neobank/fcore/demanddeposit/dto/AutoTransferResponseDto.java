package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.neobank.fcore.demanddeposit.pb.command.message.AutoTransferDeployResponse;

@SuppressWarnings("serial")
public class AutoTransferResponseDto implements Serializable {

    private AutoTransferDeployResponse autoTransferDeployResponse;

    /**
     * 自動振込展開APIのレスポンスと後続処理に必要な情報を渡す。
     *
     * @param autoTransferDeployResponse 自動振込展開APIのレスポンス
     */
    public AutoTransferResponseDto(AutoTransferDeployResponse autoTransferDeployResponse) {
        super();
        this.autoTransferDeployResponse = autoTransferDeployResponse;
    }

    public AutoTransferDeployResponse getInterestResponse() {
        return autoTransferDeployResponse;
    }

    public void autoTransferDeployResponse(AutoTransferDeployResponse autoTransferDeployResponse) {
        this.autoTransferDeployResponse = autoTransferDeployResponse;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
