package com.neobank.fcore.demanddeposit.code;

/**
 * 支払ステータス。
 *
 */
public enum PaymentStatus {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:1094] 支払ステータス
    UNPAID("0"), PAID("1");
    // --- Generated Code Ends---

    private String code;

    PaymentStatus(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
