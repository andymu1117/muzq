package com.neobank.fcore.demanddeposit.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.MessageSourceResolvable;
import org.springframework.validation.Errors;

@SuppressWarnings("serial")
public class BusinessFailureException extends RuntimeException {
    private final transient Errors errors;
    private final transient List<MessageSourceResolvable> resolvableList;

    /**
     * デフォルトコンストラクタ。
     */
    public BusinessFailureException() {
        super();
        this.errors = null;
        this.resolvableList = null;
    }

    /**
     * メッセージをセットしてインスタンス化する。
     *
     * @param message メッセージ
     */
    public BusinessFailureException(String message) {
        super(message);
        this.errors = null;
        this.resolvableList = null;
    }

    /**
     * 例外の原因をセットしてインスタンス化する。
     *
     * @param cause 例外の原因
     */
    public BusinessFailureException(Throwable cause) {
        super(cause);
        this.errors = null;
        this.resolvableList = null;
    }

    /**
     * メッセージ及び例外の原因をセットしてインスタンス化する。
     *
     * @param message メッセージ
     * @param cause 例外の原因
     */
    public BusinessFailureException(String message, Throwable cause) {
        super(message, cause);
        this.errors = null;
        this.resolvableList = null;
    }

    /**
     * Bean Validationの結果をセットしてインスタンス化する。
     *
     * @param errors Validation結果
     */
    public BusinessFailureException(Errors errors) {
        super();
        this.errors = errors;
        this.resolvableList = null;
    }

    /**
     * Global Errorとして表示するメッセージコードを含む{@link MessageSourceResolvable}をセットする。
     *
     * @param resolvable propertiesファイルに定義されたメッセージコードがセットされている{@link MessageSourceResolvable}
     */
    public BusinessFailureException(MessageSourceResolvable resolvable) {
        super();
        ArrayList<MessageSourceResolvable> list = new ArrayList<>();
        list.add(resolvable);
        this.resolvableList = list;
        this.errors = null;
    }

    /**
     * Global Errorとして表示するメッセージコードを含む{@link MessageSourceResolvable}のリストをセットする。
     *
     * @param resolvableList {@link MessageSourceResolvable}のリスト
     */
    public BusinessFailureException(List<MessageSourceResolvable> resolvableList) {
        super();
        this.resolvableList = resolvableList;
        this.errors = null;
    }

    public Errors getErrors() {
        return errors;
    }

    public List<MessageSourceResolvable> getResolvableList() {
        return resolvableList;
    }
}
