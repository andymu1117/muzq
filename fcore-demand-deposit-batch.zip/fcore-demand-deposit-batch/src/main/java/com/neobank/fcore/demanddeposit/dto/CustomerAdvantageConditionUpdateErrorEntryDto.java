package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.neobank.fcore.demanddeposit.entity.CustomerAdvantageConditionEntity;

/**
 * 失敗した顧客優遇条件の情報。
 *
 */
public class CustomerAdvantageConditionUpdateErrorEntryDto implements Serializable {

    private static final long serialVersionUID = 305477874786636022L;
    private List<String> customerAdvantageCondition;
    private String updatedTime;
    private String errorMessage;

    public CustomerAdvantageConditionUpdateErrorEntryDto() {
    }

    /**
     * 失敗した顧客優遇条件情報でオブジェクトを作成する。
     *
     * @param customerAdvantageCondition 失敗したリクエスト。
     * @param exception 例外情報
     */
    public CustomerAdvantageConditionUpdateErrorEntryDto(CustomerAdvantageConditionEntity customerAdvantageCondition,
        Exception exception) {

        this.customerAdvantageCondition = customerAdvantageCondition.getCustomerAdvantageConditions();
        this.updatedTime = customerAdvantageCondition.getUpdatedTime();
        this.errorMessage = exception.getMessage();
    }

    public List<String> getCustomerAdvantageCondition() {
        return customerAdvantageCondition;
    }

    public void setCustomerAdvantageCondition(List<String> customerAdvantageCondition) {
        this.customerAdvantageCondition = customerAdvantageCondition;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.NO_CLASS_NAME_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
