package com.neobank.fcore.demanddeposit.transform;

import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;

/**
 * ファイルレコードから前営業日決済データを削除する。
 */
@SuppressWarnings("serial")
public class SettlementCollationRemoveBeforeSettlementFn
    extends DoFn<KV<List<String>, SettlementCollationBase>, KV<List<String>, SettlementCollationBase>> {

    /**
     * ファイルレコードから前営業日決済データを削除する。
     *
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(ProcessContext context) {
        if (!CommunicationTypeCode.isBeforeSettlementTarget(((SettlementCollationFile) context.element()
            .getValue()).getCommunicationTypeCode())) {
            context.output(context.element());
        }
    }
}
