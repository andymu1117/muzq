/**
 * Pipelineから実行されるTransformにて実行されるロジックを実装しているクラスを格納するパッケージ。<br>
 * {@link org.apache.beam.sdk.transforms.DoFn} クラスを用いて実装を行う。
 */
package com.neobank.fcore.demanddeposit.transform;
