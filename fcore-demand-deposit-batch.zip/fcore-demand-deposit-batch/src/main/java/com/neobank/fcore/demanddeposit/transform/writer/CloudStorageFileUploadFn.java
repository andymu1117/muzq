package com.neobank.fcore.demanddeposit.transform.writer;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.beam.sdk.transforms.DoFn;

import com.accenture.mainri.core.io.GcsHelper;

/**
 * 作成したデータをGoogle Cloud Storage上のファイルに書き込む。
 */
@SuppressWarnings("serial")
public class CloudStorageFileUploadFn extends DoFn<String, Void> {
    private String filePath;

    public CloudStorageFileUploadFn(String filePath) {
        this.filePath = filePath;
    }

    /**
     * 出力結果をファイルとして書き込む。
     *
     * @param element 出力結果
     * @param context プロセスコンテクスト
     * 
     */
    @ProcessElement
    public void processElement(@Element String element, ProcessContext context) {

        InputStream inputStreamResult = new ByteArrayInputStream(element.getBytes(StandardCharsets.UTF_8));
        GcsHelper.uploadFile("application/octet-stream", inputStreamResult, filePath);
    }

}
