package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.accenture.mainri.core.entity.DataClassBase;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;

/**
 * バイト配列のListを受け取り、全銀リコンサイル用のオブジェクトListにする。
 */
@SuppressWarnings("serial")
public class SettlementCollationMergeForOfficerSummaryFn
    extends DoFn<KV<List<String>, Iterable<SettlementCollationBase>>,
        // SonarQube対策の為改行
        KV<List<String>, Map<String, List<DataClassBase>>>> {

    /**
     * 行員画面に出力するサマリ画面向けにオブジェクトをまとめる。 そのためにここではオブジェクトにキーを付け、マップ形式で出力する。
     *
     * @param target target
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, Iterable<SettlementCollationBase>> target,
        ProcessContext context) {
        Iterable<SettlementCollationBase> input = context.element()
            .getValue();
        List<DataClassBase> result = new ArrayList<>();
        input.forEach(result::add);

        List<String> outputKey = new ArrayList<>();
        outputKey.add("output");

        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(target.getKey()
            .get(0), result);

        context.output(KV.of(outputKey, resultMap));
    }
}
