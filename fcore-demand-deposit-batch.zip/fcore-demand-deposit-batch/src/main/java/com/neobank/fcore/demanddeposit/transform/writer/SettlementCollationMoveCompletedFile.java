package com.neobank.fcore.demanddeposit.transform.writer;

import java.io.IOException;
import java.util.List;

import org.apache.beam.sdk.io.fs.MatchResult.Metadata;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.utils.FileUtils;

@SuppressWarnings("serial")
public class SettlementCollationMoveCompletedFile extends DoFn<String, Integer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationMoveCompletedFile.class);

    private String bucket;

    /**
     * 値設定のコンストラクタ。
     *
     * @param bucket outerのバケット
     */
    public SettlementCollationMoveCompletedFile(String bucket) {
        this.bucket = bucket;
    }

    /**
     * GCSの対象ファイルを同じバケットのoldフォルダへ移動する。
     *
     * @param targetDate 対象日付
     * @param out エラー数
     * @throws IOException ファイルのリネーム、ファイルの読み込み時にエラーが発生した場合の例外
     */
    @ProcessElement
    public void processElement(@Element String targetDate, OutputReceiver<Integer> out) throws IOException {
        this.move(targetDate);
    }

    /**
     * 対象のファイルを移動する。
     *
     * @param paramDate パラメータで指定された対象日付(yyyyMMdd)
     * @throws IOException ファイルの読み込みが失敗した場合の例外
     */
    private void move(String paramDate) throws IOException {

        // 対象ファイル一覧取得
        String targetId = null;
        targetId = new StringBuilder().append(bucket)
            .append("settlement-collation/Dzgscollation_")
            .append(paramDate)
            .append("*")
            .toString();
        List<Metadata> fileMetadataList = FileUtils.matchFile(targetId);

        fileMetadataList.forEach(fileMetadata -> {
            String fromPath = new StringBuilder().append(bucket)
                .append("settlement-collation/")
                .append(fileMetadata.resourceId()
                    .getFilename())
                .toString();
            try {
                FileUtils.renameFile(fromPath, bucket, "settlement-collation/old/", "");
            } catch (IOException e) {
                LOGGER.error("file move failed: {}", fromPath, e);
            }
        });
    }

}
