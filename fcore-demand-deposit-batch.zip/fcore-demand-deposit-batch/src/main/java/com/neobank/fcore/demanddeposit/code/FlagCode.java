package com.neobank.fcore.demanddeposit.code;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

/**
 * フラグコード。
 */
public enum FlagCode {

    /** FALSE:0。 */
    FALSE("0", "FALSE"),

    /** TRUE:1。 */
    TRUE("1", "TRUE");

    private final String code;
    private final String decode;

    private FlagCode(String code, String decode) {
        this.code = code;
        this.decode = decode;
    }

    /**
     * コード値を真偽値へ変換する。
     *
     * @param flag フラグ
     * @return 真偽（"true"：稼働、"false"：非稼働）
     */
    public static boolean toBoolean(String flag) {
        return StringUtils.equals(flag, TRUE.getCode());
    }

    /**
     * 真偽値をコード値へ変換する。
     *
     * @param bool bool値
     * @return 真(1)/偽(0)
     */
    public static String toCode(Boolean bool) {
        if (!Objects.isNull(bool) && bool) {
            return TRUE.getCode();
        } else {
            return FALSE.getCode();
        }
    }

    public String getCode() {
        return this.code;
    }

    public String getDecode() {
        return this.decode;
    }
}
