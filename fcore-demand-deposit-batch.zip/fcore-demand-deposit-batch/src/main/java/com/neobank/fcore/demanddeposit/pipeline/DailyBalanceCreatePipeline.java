package com.neobank.fcore.demanddeposit.pipeline;

import java.util.HashMap;

import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.spanner.ReadOperation;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.converter.spanner.resultset.SpannerResultToEntitiesConverter;
import com.accenture.mainri.core.io.GrpcConnector;
import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.PipelineDefinition;
import com.accenture.mainri.core.pipeline.PipelineRepartitioner;
import com.accenture.mainri.core.pipeline.PipelineTemplate;

import com.neobank.fcore.demanddeposit.dto.DailyBalanceCreateResponseDto;
import com.neobank.fcore.demanddeposit.dto.DailyBalanceTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.dto.ErrorLogEntryDto;
import com.neobank.fcore.demanddeposit.entity.AccountEntity;
import com.neobank.fcore.demanddeposit.pipeline.options.DailyBalanceCreateOption;
import com.neobank.fcore.demanddeposit.repository.AccountStatementBuilder;
import com.neobank.fcore.demanddeposit.transform.DailyBalanceTargetAccountRetrieveConditionConvertFn;
import com.neobank.fcore.demanddeposit.transform.grpc.DailyBalanceCreateApiCaller;
import com.neobank.fcore.demanddeposit.utils.DemandDepositGrpcPropertyUtil;

/**
 * AccountsDailyCreate 日次残高確定バッチ [--pipelineName=daily-balance-create --processDate=YYYY-MM-DD]。
 *
 */
@SuppressWarnings("serial")
@PipelineDefinition(name = "daily-balance-create", optionClass = DailyBalanceCreateOption.class)
public class DailyBalanceCreatePipeline extends PipelineTemplate<DailyBalanceCreateOption> {
    private static final Logger LOGGER = LoggerFactory.getLogger(DailyBalanceCreatePipeline.class);
    private SpannerResultToEntitiesConverter converter = new SpannerResultToEntitiesConverter();

    @Override
    public PipelineResult run(DailyBalanceCreateOption options) {
        LOGGER.info("daily balance create - start");
        Pipeline pipeline = Pipeline.create(options);
        final SpannerDriver spannerDriver = new SpannerDriver(options);
        PCollection<DailyBalanceTargetAccountRetrieveConditionDto> retrieveConditionPCollection =
            dailyBalanceCreateOpitionConverter(pipeline, options);
        PCollection<AccountEntity> processTargets =
            selectAccountsNeedToCreateBalance(retrieveConditionPCollection, spannerDriver, options);
        createAccountsBalance(processTargets, options);
        LOGGER.info("daily balance create - end");
        return pipeline.run();
    }

    /**
     * バッチ実行パラメータを変換する。
     *
     * @param pipeline pipelineのインスタンス
     * @param options アクセス用のoptions
     * @return 処理対象抽出条件のPCollection
     */
    private PCollection<DailyBalanceTargetAccountRetrieveConditionDto> dailyBalanceCreateOpitionConverter(
        Pipeline pipeline, final DailyBalanceCreateOption options) {
        return pipeline.apply("Read parameters", Create.ofProvider(options.getProcessDate(), StringUtf8Coder.of()))
            .apply("Convert and check options", ParDo.of(new DailyBalanceTargetAccountRetrieveConditionConvertFn()));
    }

    /**
     * 日次残高確定処理対象口座をspannerから取得。
     *
     * @param retrieveConditionPCollection 処理対象抽出条件のPCollection
     * @param spannerDriver spannerアクセス用のDriver
     * @param options アクセス用のoptions
     * @return 処理対象口座のPCollection
     */
    private PCollection<AccountEntity> selectAccountsNeedToCreateBalance(
        PCollection<DailyBalanceTargetAccountRetrieveConditionDto> retrieveConditionPCollection,
        final SpannerDriver spannerDriver, final DailyBalanceCreateOption options) {
        final HashMap<String, Object> ctx = options.getPipelineContext();
        return retrieveConditionPCollection
            .apply("Create read operation", MapElements.into(TypeDescriptor.of(ReadOperation.class))
                .via((DailyBalanceTargetAccountRetrieveConditionDto conditionEntity) -> {
                    LOGGER.debug("balanceDate: {}", conditionEntity.getBalanceDateWithoutHyphen());
                    Statement statement = new AccountStatementBuilder()
                        .createSelectAccountsNeedToCreateBalanceStatement(ctx, conditionEntity);
                    LOGGER.debug("sql: {}", statement);
                    return ReadOperation.create()
                        .withQuery(statement);
                }))
            .apply("Read data from Spanner", spannerDriver.readAll(false))
            .apply(ParDo.of(new PipelineRepartitioner.AddArbitraryKey<>()))
            .apply(GroupByKey.create())
            .apply(ParDo.of(new PipelineRepartitioner.RemoveArbitraryKey<>()))
            .apply("Create accountEntity", MapElements.into(TypeDescriptor.of(AccountEntity.class))
                .via((Struct input) -> {
                    AccountEntity result = converter.convert(input, AccountEntity.class);
                    LOGGER.debug("read account entity: {}", result);
                    return result;
                }));
    }

    /**
     * 日次残高確定API実行。
     *
     * @param selectResult 日次残高確定処理対象口座
     * @param options アクセス用のoptions
     * @return 処理結果のPCollection
     */
    private PCollection<DailyBalanceCreateResponseDto> createAccountsBalance(PCollection<AccountEntity> selectResult,
        DailyBalanceCreateOption options) {
        final TupleTag<DailyBalanceCreateResponseDto> successTag = new TupleTag<DailyBalanceCreateResponseDto>() {};
        final TupleTag<ErrorLogEntryDto> errorTag = new TupleTag<ErrorLogEntryDto>() {};
        final TupleTag<ErrorLogEntryDto> warnTag = new TupleTag<ErrorLogEntryDto>() {};
        PCollectionTuple apiResult = selectResult.apply(ParDo
            .of(new DailyBalanceCreateApiCaller(
                new GrpcConnector(DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceHost(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServicePort(options),
                    DemandDepositGrpcPropertyUtil.isTlsEnabledForGrpcDemandDepositService(options),
                    DemandDepositGrpcPropertyUtil.getGrpcDemandDepositServiceVersion(options)),
                successTag, errorTag, warnTag))
            .withOutputTags(successTag, TupleTagList.of(errorTag)
                .and(warnTag)));
        // warn、errorが発生する際に、ログ出力だけをするので、warnTagとerrorTagに対する処理が不要
        return apiResult.get(successTag);
    }
}
