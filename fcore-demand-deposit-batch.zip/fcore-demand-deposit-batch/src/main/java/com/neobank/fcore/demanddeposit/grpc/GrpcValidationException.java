package com.neobank.fcore.demanddeposit.grpc;

import java.util.ArrayList;
import java.util.List;

/**
 * GRPCから {@code VALIDATION_FAILURE} がレスポンスされたことを示す例外。
 */
@SuppressWarnings("serial")
public class GrpcValidationException extends RuntimeException {

    private final transient String errorTitle;
    private final transient List<GrpcFieldError> fieldErrors = new ArrayList<>();
    private final transient List<GrpcGlobalError> globalErrors = new ArrayList<>();

    public GrpcValidationException() {
        super();
        this.errorTitle = "";
    }

    public GrpcValidationException(Throwable cause) {
        super(cause);
        this.errorTitle = "";
    }

    /**
     * コンストラクタ。
     *
     * @param errorTitle エラータイトル
     * @param ferrors 単項目チェックエラー
     * @param gerrors 相関・業務チェックエラー
     */
    public GrpcValidationException(String errorTitle, List<GrpcFieldError> ferrors, List<GrpcGlobalError> gerrors) {
        super(errorTitle);
        this.errorTitle = errorTitle;
        if (ferrors != null) {
            this.fieldErrors.addAll(ferrors);
        }
        if (gerrors != null) {
            this.globalErrors.addAll(gerrors);
        }
    }

    public String getErrorTitle() {
        return errorTitle;
    }

    public List<GrpcFieldError> getFieldErrors() {
        return fieldErrors;
    }

    public List<GrpcGlobalError> getGrpcGlobalErrors() {
        return globalErrors;
    }
}
