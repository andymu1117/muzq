-- AutoTransfersはTable full scanを回避するため、Indexを採用
-- AutoTransfersはWhere句指定なしのためIndex full scan
SELECT
  OutboundTransfers.OutboundTransferId,
  OutboundTransfers.AccountId,
  OutboundTransfers.TransactionPatternCode,
  OutboundTransfers.TransactionPatternSubCode,
  AutoTransfers.CreationDate AS AutoTransferCreationDate,
  OutboundTransfers.CreationDate,
  OutboundTransfers.CreationUserId,
  OutboundTransfers.UpdatedDate,
  OutboundTransfers.UpdatedUserId
FROM
  OutboundTransfers @{FORCE_INDEX=IDX_First_Hit_Column_TransactionPatternCode_OutboundTransfers}
  LEFT OUTER JOIN AutoTransfers@{FORCE_INDEX=IDX_First_Hit_Column_CreationDate_AutoTransfers}
  ON OutboundTransfers.AutoTransferId = AutoTransfers.AutoTransferId
WHERE
  (
    (
      OutboundTransfers.TransactionPatternCode = "R001" AND
      (
        OutboundTransfers.TransactionPatternSubCode = "01" OR
        OutboundTransfers.TransactionPatternSubCode = "02"
      )
    ) OR
    (
      OutboundTransfers.TransactionPatternCode = "R002" AND
      (
        OutboundTransfers.TransactionPatternSubCode = "02" OR
        OutboundTransfers.TransactionPatternSubCode = "03"
      )
    )
  ) AND
   OutboundTransfers.TransactionStatus = "1" AND
   OutboundTransfers.TransferDate = @TargetDate AND
   OutboundTransfers.DeleteFlag = "0"
ORDER BY
  OutboundTransfers.AccountId ASC
