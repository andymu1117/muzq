package com.neobank.fcore.demanddeposit.grpc;

import java.util.ArrayList;

import com.google.rpc.Code;
import com.google.rpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.protobuf.StatusProto;

/**
 * gRPC通信エラーをパース用ツール。
 *
 */
public class GrpcErrorParser {

    private GrpcErrorParser() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * gRPC通信にてエラーが返却された際のレスポンスをパースし、適切なExceptionクラスにWrapしてRethrowする。
     *
     * @param ex StatusRuntimeException
     */
    public static void parseErrorResponse(StatusRuntimeException ex) {
        Status sts;
        try {
            sts = StatusProto.fromThrowable(ex);
        } catch (IllegalArgumentException iaex) {
            throw new GrpcSystemException(iaex.getMessage(), ex);
        }

        if (sts == null) {
            throw new GrpcSystemException(ex.getStatus()
                .getCode()
                .name(), ex);
        }

        // gRPCからのエラーが存在していない場合
        if (sts.getDetailsList()
            .isEmpty()) {
            throw new GrpcSystemException("error response from gRPC is empty.");
        }

        // エラーレスポンスではない場合
        if (!sts.getDetails(0)
            .getTypeUrl()
            .endsWith(".ErrorResponse")) {
            throw new GrpcSystemException("error response from gRPC is invalid.");
        }

        // INVALID_ARGUMENTの場合はバリデーションエラー、それ以外はシステムエラーとする
        if (Code.INVALID_ARGUMENT_VALUE == sts.getCode()) {
            throw new GrpcValidationException(sts.getMessage(), new ArrayList<GrpcFieldError>(),
                new ArrayList<GrpcGlobalError>());
        }

        throw new GrpcSystemException(sts.getMessage(), new ArrayList<GrpcGlobalError>());
    }
}
