package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.neobank.fcore.demanddeposit.pb.command.message.DailyBalanceCalculateResponse;

@SuppressWarnings("serial")
public class DailyBalanceCreateResponseDto implements Serializable {
    private DailyBalanceCalculateResponse dailyBalanceCalculateResponse;

    /**
     * 日次残高確定APIのレスポンスと後続処理に必要な情報を渡す。
     *
     * @param dailyBalanceCalculateResponse 日次残高確定APIのレスポンス
     */
    public DailyBalanceCreateResponseDto(DailyBalanceCalculateResponse dailyBalanceCalculateResponse) {
        super();
        this.dailyBalanceCalculateResponse = dailyBalanceCalculateResponse;
    }

    public DailyBalanceCalculateResponse getDailyBalanceCalculateResponse() {
        return dailyBalanceCalculateResponse;
    }

    public void setDailyBalanceCalculateResponse(DailyBalanceCalculateResponse dailyBalanceCalculateResponse) {
        this.dailyBalanceCalculateResponse = dailyBalanceCalculateResponse;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    public DailyBalanceCreateResponseDto() {

    }
}
