package com.neobank.fcore.demanddeposit.transform;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.neobank.fcore.demanddeposit.entity.OutboundTransferEntity;
import com.neobank.fcore.demanddeposit.pb.command.message.TransferReservationExecuteRequest;

@SuppressWarnings("serial")
public class TransferReservationExecuteRequestConvertFn
    extends DoFn<KV<String, Iterable<OutboundTransferEntity>>, List<TransferReservationExecuteRequest>> {

    private static final String INTERNAL_TRANSFER = "R001";
    private static final String INTERNAL_RESERVED = "02";

    private static final String EXTERNAL_TRANSFER = "R002";
    private static final String EXTERNAL_RESERVED = "03";

    /**
     * 入力要素を出力要素に変換。
     *
     * @param element 仕向振込ID
     * @param context 処理のコンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<String, Iterable<OutboundTransferEntity>> element, ProcessContext context) {
        List<TransferReservationExecuteRequest> transferReservationExecuteRequest = StreamSupport
            .stream(element.getValue()
                .spliterator(), false)
            .sorted(Comparator.comparing(this::isTransferReservation)
                .thenComparing(Comparator.comparing(OutboundTransferEntity::getAutoTransferCreationDate,
                    Comparator.nullsLast(Comparator.naturalOrder())))
                .thenComparing(OutboundTransferEntity::getCreationDate))
            .map(item -> TransferReservationExecuteRequest.newBuilder()
                .setOutboundTransferId(item.getOutboundTransferId())
                .build())
            .collect(Collectors.toList());

        context.output(transferReservationExecuteRequest);
    }

    /**
     * 与えられた仕向振込が振込予約であることを確認する。
     *
     * @param item 仕向振込
     * @return 与えられた仕向振込が振込予約であるとき true を返す。
     */
    private boolean isTransferReservation(OutboundTransferEntity item) {
        final String patternCode = item.getTransactionPatternCode();
        final String subcode = item.getTransactionPatternSubCode();

        // 自行の振込予約である
        return (INTERNAL_TRANSFER.equals(patternCode) && INTERNAL_RESERVED.equals(subcode))
            // 他行の振込予約である
            || (EXTERNAL_TRANSFER.equals(patternCode) && EXTERNAL_RESERVED.equals(subcode));
    }
}
