package com.neobank.fcore.demanddeposit.transform.writer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.PCollectionView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.utils.FileUtils;

/**
 * ファイルをGCPの対象フォルダに格納する。
 */
@SuppressWarnings("serial")
public class SettlementCollationFileCreateFn extends DoFn<String, String> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationFileCreateFn.class);
    private String bucket;
    private PCollectionView<String> outputDate;
    private String fileFormat;

    /**
     * 値を設定するコンストラクタ。
     *
     * @param outputDate ファイル名に設定する日付
     * @param bucket bucket
     * @param fileFormat ファイル名のフォーマット
     */
    public SettlementCollationFileCreateFn(PCollectionView<String> outputDate, String bucket, String fileFormat) {
        this.outputDate = outputDate;
        this.bucket = bucket;
        this.fileFormat = fileFormat;
    }

    /**
     * ファイルをGCPの対象フォルダに格納する。
     *
     * @param target target
     * @param context PCollectionの出力やSideInput取得のためのProcessContext
     * @throws IOException ファイルの出力が失敗した場合の例外
     */
    @ProcessElement
    public void processElement(@Element String target, ProcessContext context) throws IOException {

        // 口座照会応答ファイルのbyte配列を暗号化し、対象ファイルと暗号化キーファイルをGCSへ格納する
        this.write(context.sideInput(outputDate)
            .replace("-", ""), target.getBytes(StandardCharsets.UTF_8));

        LOGGER.debug("AccountInquiryFileCreaterFn completed");
        context.output("complete");
    }

    /**
     * byte配列にファイル名を設定してGCSへ格納する。
     *
     * @param targetDate 対象日付(yyyyMMdd)
     * @param mergedTargetByte 出力するbyte配列
     * @throws IOException ファイルの出力が失敗した場合の例外
     */
    private void write(String targetDate, byte[] targetByte) throws IOException {
        // 対象ファイルパス生成
        String targetFilePath = new StringBuilder().append(bucket)
            .append("settlement-collation/")
            .append(MessageFormat.format(fileFormat, targetDate))
            .toString();
        // 対象ファイル出力
        FileUtils.writeFile(targetFilePath, targetByte);
    }
}
