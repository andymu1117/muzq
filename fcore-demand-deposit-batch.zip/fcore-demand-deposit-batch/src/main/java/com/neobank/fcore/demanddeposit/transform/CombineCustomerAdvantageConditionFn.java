package com.neobank.fcore.demanddeposit.transform;

import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.commons.lang3.StringUtils;

import com.neobank.fcore.demanddeposit.code.LineSeparator;

/**
 * Batchで顧客優遇条件情報処理結果をCombineする。
 *
 */

@SuppressWarnings("serial")
public class CombineCustomerAdvantageConditionFn implements SerializableFunction<Iterable<String>, String> {

    /**
     * Batchで顧客優遇条件情報処理結果をCombineする。
     *
     * @param input 顧客優遇条件情報処理結果
     */
    @Override
    public String apply(Iterable<String> input) {

        StringBuilder csvSb = new StringBuilder();

        input.forEach(csv -> {
            if (StringUtils.isNotEmpty(csv)) {
                csvSb.append(csv);
                csvSb.append(LineSeparator.NEW_LINE.getCode());// 改行
            }
        });
        return csvSb.toString();
    }

}
