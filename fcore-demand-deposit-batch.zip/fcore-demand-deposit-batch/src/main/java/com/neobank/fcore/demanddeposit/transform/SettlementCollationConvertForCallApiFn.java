package com.neobank.fcore.demanddeposit.transform;

import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;

/**
 * ベースオブジェクトをファイルのオブジェクトへ変換する。
 */
@SuppressWarnings("serial")
public class SettlementCollationConvertForCallApiFn extends DoFn<KV<List<String>, SettlementCollationBase>,
    // SonarQube対策の為改行
    KV<List<String>, SettlementCollationFile>> {

    /**
     * ベースオブジェクトをファイルのオブジェクトへ変換する。
     *
     * @param input ベースオブジェクト
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, SettlementCollationBase> input, ProcessContext context) {
        if (CommunicationTypeCode
            .isBeforeSettlementTarget(((SettlementCollationFile) input.getValue()).getCommunicationTypeCode())) {
            context.output(KV.of(input.getKey(), (SettlementCollationFile) input.getValue()));
        }
    }
}
