package com.neobank.fcore.demanddeposit.transform;

import org.apache.beam.sdk.transforms.DoFn;

import com.neobank.fcore.demanddeposit.utils.ValidationUtils;

/**
 * 日付をチェックする。
 */
@SuppressWarnings("serial")
public class SettlementCollationValidateDateFn extends DoFn<String, String> {

    /**
     * 日付をチェックする。
     *
     * @param target 対象日付
     * @param out 対象日付
     */
    @ProcessElement
    public void processElement(@Element String target, OutputReceiver<String> out) {
        // 入力パラメータチェック
        ValidationUtils.checkParamDate(target);
        out.output(target);
    }
}
