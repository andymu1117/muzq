package com.neobank.fcore.demanddeposit.code;

/**
 * 利息有無フラグ。
 *
 */
public enum InterestFlag {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:1254] 利息有無フラグ
    NO("0"), YES("1");
    // --- Generated Code Ends---

    private String code;

    InterestFlag(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
