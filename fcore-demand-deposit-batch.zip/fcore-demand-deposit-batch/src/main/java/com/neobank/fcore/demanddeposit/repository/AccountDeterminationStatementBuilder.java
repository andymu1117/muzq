package com.neobank.fcore.demanddeposit.repository;

import java.util.HashMap;
import java.util.Map;

import com.google.cloud.spanner.Statement;

import com.accenture.mainri.core.spanner.SpannerQueryBuilder;
import com.accenture.mainri.core.spanner.SpannerStatementHelper;
import com.accenture.mainri.core.sql.template.FileTemplateProvider;

import com.neobank.fcore.demanddeposit.code.AccountManageKey;
import com.neobank.fcore.demanddeposit.code.AccountStatus;
import com.neobank.fcore.demanddeposit.code.CancelRevivalType;
import com.neobank.fcore.demanddeposit.code.CustomerStatus;
import com.neobank.fcore.demanddeposit.code.PaymentStatus;
import com.neobank.fcore.demanddeposit.code.SuspensionCausesCode;
import com.neobank.fcore.demanddeposit.code.SuspensionFlag;
import com.neobank.fcore.demanddeposit.code.TransactionPatternCode;
import com.neobank.fcore.demanddeposit.dto.AccrualRegularTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.dto.UnpaidInterestTargetAccountRetrieveConditionDto;

public class AccountDeterminationStatementBuilder {
    /**
     * 利息決算を元加する口座を見つける為に、Spannerに流すSQL文を組み立てる。
     *
     * @param ctx pipelineのコンテキスト
     * @param conditionEntity 処理対象抽出条件
     * @return ステートメント
     */
    public Statement createSelectAccountsNeedToCreateAccrualStatement(Map<String, Object> ctx,
        AccrualRegularTargetAccountRetrieveConditionDto conditionEntity) {
        FileTemplateProvider templateProvider = new FileTemplateProvider(ctx, "SelectAccountNeedToCreateAccrual");
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("accountManageKeyOrdinary", AccountManageKey.ORDINARY.getCode());
        parameters.put("interestDate", conditionEntity.getInterestDateWithoutHyphen());
        parameters.put("interestDateMaxTime", conditionEntity.getInterestDateTodayMaxTime());
        parameters.put("accountStatusNormal", AccountStatus.NORMAL.getCode());
        parameters.put("customerStatusNormal", CustomerStatus.NORMAL.getCode());
        parameters.put("suspensionFlagOn", SuspensionFlag.ON.getCode());
        parameters.put("accountAccrualNot", SuspensionCausesCode.ACCOUNT_ACCRUAL_NOT.getCode());
        parameters.put("accountDormant", SuspensionCausesCode.ACCOUNT_DORMANT.getCode());
        parameters.put("unpaid", PaymentStatus.UNPAID.getCode());
        SpannerQueryBuilder statementBuilder = new SpannerQueryBuilder();
        String query = statementBuilder.setQueryProvider(templateProvider)
            .setParameters(parameters)
            .build();
        return SpannerStatementHelper.build(query, parameters);
    }

    /**
     * 未払い利息計算する口座を見つける為に、Spannerに流すSQL文を組み立てる。
     *
     * @param ctx pipelineのコンテキスト
     * @param conditionEntity 処理対象抽出条件
     * @return ステートメント
     */
    public Statement createSelectAccountsNeedToCreateUnpaidInterestStatement(Map<String, Object> ctx,
        UnpaidInterestTargetAccountRetrieveConditionDto conditionEntity) {
        FileTemplateProvider templateProvider =
            new FileTemplateProvider(ctx, "SelectAccountNeedToCreateUnpaidInterest");
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("accountManageKeyOrdinary", AccountManageKey.ORDINARY.getCode());
        parameters.put("interestDate", conditionEntity.getInterestDateWithoutHyphen());
        parameters.put("customerStatusNormal", CustomerStatus.NORMAL.getCode());
        parameters.put("paymentStatusPaid", PaymentStatus.PAID.getCode());
        parameters.put("interestDateMinTime", conditionEntity.getInterestDateTodayMinTime());
        parameters.put("interestDateMaxTime", conditionEntity.getInterestDateTodayMaxTime());
        parameters.put("TransactionPatternCodeInterestSettlement",
            TransactionPatternCode.TRANSACTIONPATTERNCODEINTERESTSETTLEMENT.getCode());
        parameters.put("TransactionPatternSubCodeInterestSettlement",
            TransactionPatternCode.TRANSACTIONPATTERNCODEINTERESTSETTLEMENT.getSubCode());
        parameters.put("accountCancelCustomer", CancelRevivalType.ACCOUNT_CANCEL_CUSTOMER.getCode());
        parameters.put("accountCancelBankClerk", CancelRevivalType.ACCOUNT_CANCEL_BANK_CLERK.getCode());
        parameters.put("suspensionFlagOn", SuspensionFlag.ON.getCode());
        parameters.put("accountDormant", SuspensionCausesCode.ACCOUNT_DORMANT.getCode());

        SpannerQueryBuilder statementBuilder = new SpannerQueryBuilder();
        String query = statementBuilder.setQueryProvider(templateProvider)
            .setParameters(parameters)
            .build();
        return SpannerStatementHelper.build(query, parameters);
    }
}
