package com.neobank.fcore.demanddeposit.repository;

import java.util.HashMap;
import java.util.Map;

import com.google.cloud.spanner.Statement;

import com.accenture.mainri.core.spanner.SpannerQueryBuilder;
import com.accenture.mainri.core.spanner.SpannerStatementHelper;
import com.accenture.mainri.core.sql.template.FileTemplateProvider;

import com.neobank.fcore.demanddeposit.code.AccountBalanceUpdateFlag;
import com.neobank.fcore.demanddeposit.code.AccountStatus;
import com.neobank.fcore.demanddeposit.code.CancelRevivalType;
import com.neobank.fcore.demanddeposit.dto.DailyBalanceTargetAccountRetrieveConditionDto;

public class AccountStatementBuilder {

    /**
     * 日次残高を生成する口座を見つける為に、Spannerに流すSQL文を組み立てる。
     *
     * @param ctx pipelineのコンテキスト
     * @param conditionEntity 処理対象抽出条件
     * @return ステートメント
     */
    public Statement createSelectAccountsNeedToCreateBalanceStatement(Map<String, Object> ctx,
        DailyBalanceTargetAccountRetrieveConditionDto conditionEntity) {
        FileTemplateProvider templateProvider = new FileTemplateProvider(ctx, "SelectAccountsNeedToCreateBalance");
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("balanceDate", conditionEntity.getBalanceDateWithoutHyphen());
        parameters.put("accountStatusInit", AccountStatus.INIT.getCode());
        parameters.put("accountStatusNormal", AccountStatus.NORMAL.getCode());
        parameters.put("accountBalanceUpdateFlagUpdate", AccountBalanceUpdateFlag.UPDATE.getCode());
        parameters.put("balanceDateTimeISO", conditionEntity.getBalanceDateTodayMaxTime());
        parameters.put("accountCancelCustomer", CancelRevivalType.ACCOUNT_CANCEL_CUSTOMER.getCode());
        parameters.put("accountCancelBankClerk", CancelRevivalType.ACCOUNT_CANCEL_BANK_CLERK.getCode());
        SpannerQueryBuilder statementBuilder = new SpannerQueryBuilder();
        String query = statementBuilder.setQueryProvider(templateProvider)
            .setParameters(parameters)
            .build();
        return SpannerStatementHelper.build(query, parameters);
    }
}
