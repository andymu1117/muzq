package com.neobank.fcore.demanddeposit.transform;

import java.util.List;
import java.util.Objects;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollectionView;
import org.springframework.beans.BeanUtils;

import com.neobank.fcore.demanddeposit.code.FlagCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerSummaryFile;

/**
 * サマリレコードにエラーフラグを設定し出力する。
 */
@SuppressWarnings("serial")
public class SettlementCollationSetSummaryResultToErrorFn
    extends DoFn<KV<List<String>, SettlementCollationBase>, KV<List<String>, SettlementCollationBase>> {

    private PCollectionView<Integer> detailErrorNum;

    /**
     * 値受け渡しの為のタグを設定するコンストラクタ。
     *
     * @param detailErrorNum 明細のエラー数
     */
    public SettlementCollationSetSummaryResultToErrorFn(PCollectionView<Integer> detailErrorNum) {
        this.detailErrorNum = detailErrorNum;
    }

    /**
     * サマリレコードにエラーフラグを設定し出力する。
     *
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(ProcessContext context) {
        SettlementCollationOfficerSummaryFile result = new SettlementCollationOfficerSummaryFile();
        BeanUtils.copyProperties((SettlementCollationOfficerSummaryFile) context.element()
            .getValue(), result);
        if (context.sideInput(detailErrorNum) > 0) {
            result.setErrorFlag(FlagCode.TRUE.getCode());
            context.output(KV.of(context.element()
                .getKey(), result));
        } else {
            if (Objects.isNull(result.getErrorFlag())) {
                result.setErrorFlag(FlagCode.FALSE.getCode());
            }
            context.output(KV.of(context.element()
                .getKey(), result));
        }
    }
}
