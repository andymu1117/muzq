package com.neobank.fcore.demanddeposit.entity;

import java.time.LocalDate;
import java.util.Objects;

@SuppressWarnings("serial")
public class InterestAccountFilterWithLocalDateOfInterestDateEntity extends InterestAccountFilterEntity {

    // 利息基準日（LocalDate）
    private LocalDate interestDateWithoutHyphenToLocalDate;

    public LocalDate getInterestDateWithoutHyphenToLocalDate() {
        return interestDateWithoutHyphenToLocalDate;
    }

    public void setInterestDateWithoutHyphenToLocalDate(LocalDate interestDateWithoutHyphenToLocalDate) {
        this.interestDateWithoutHyphenToLocalDate = interestDateWithoutHyphenToLocalDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (!(obj instanceof InterestAccountFilterWithLocalDateOfInterestDateEntity)) {
            return false;
        }
        InterestAccountFilterWithLocalDateOfInterestDateEntity other =
            (InterestAccountFilterWithLocalDateOfInterestDateEntity) obj;
        return Objects.equals(interestDateWithoutHyphenToLocalDate, other.interestDateWithoutHyphenToLocalDate);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        return prime * super.hashCode()
            + ((interestDateWithoutHyphenToLocalDate == null) ? 0 : interestDateWithoutHyphenToLocalDate.hashCode());
    }

}
