package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;
import java.util.Objects;

@SuppressWarnings("serial")
public class UnpaidInterestTargetAccountRetrieveConditionDto implements Serializable {
    // 利息基準日（yyyyMMddフォーマットの文字列）
    private String interestDateWithoutHyphen;
    // 利息基準日（当日の最初の時間の文字列）
    private String interestDateTodayMinTime;
    // 利息基準日（当日の最後の時間の文字列）
    private String interestDateTodayMaxTime;

    /**
     * 未払い利息計算処理対象口座抽出条件エンティティのコンストラクタ。
     *
     * @param interestDateWithoutHyphen 利息基準日（yyyyMMddフォーマットの文字列）
     * @param interestDateTodayMinTime 利息基準日（当日の最初の時間の文字列）
     * @param interestDateTodayMaxTime 利息基準日（当日の最後の時間の文字列）
     */
    public UnpaidInterestTargetAccountRetrieveConditionDto(String interestDateWithoutHyphen,
        String interestDateTodayMinTime, String interestDateTodayMaxTime) {
        this.interestDateWithoutHyphen = interestDateWithoutHyphen;
        this.interestDateTodayMinTime = interestDateTodayMinTime;
        this.interestDateTodayMaxTime = interestDateTodayMaxTime;
    }

    public String getInterestDateWithoutHyphen() {
        return interestDateWithoutHyphen;
    }

    public String getInterestDateTodayMinTime() {
        return interestDateTodayMinTime;
    }

    public String getInterestDateTodayMaxTime() {
        return interestDateTodayMaxTime;
    }

    @Override
    public int hashCode() {
        return Objects.hash(interestDateTodayMaxTime, interestDateTodayMinTime, interestDateWithoutHyphen);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof UnpaidInterestTargetAccountRetrieveConditionDto)) {
            return false;
        }
        UnpaidInterestTargetAccountRetrieveConditionDto other = (UnpaidInterestTargetAccountRetrieveConditionDto) obj;
        return Objects.equals(interestDateTodayMaxTime, other.interestDateTodayMaxTime)
            && Objects.equals(interestDateTodayMinTime, other.interestDateTodayMinTime)
            && Objects.equals(interestDateWithoutHyphen, other.interestDateWithoutHyphen);
    }
}
