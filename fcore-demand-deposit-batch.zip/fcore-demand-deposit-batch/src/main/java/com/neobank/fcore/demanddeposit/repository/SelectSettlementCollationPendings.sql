SELECT * FROM SettlementCollationPendings
WHERE SettlementDate = @TargetDate