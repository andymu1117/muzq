package com.neobank.fcore.demanddeposit.utils;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

/**
 * GRPC関連情報取得ツール。
 *
 */
public class DemandDepositGrpcPropertyUtil {

    private DemandDepositGrpcPropertyUtil() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * Demand Deposit Service Host 取得。
     *
     * @param options パイプラインのオプション
     * @return サービスホスト
     */
    public static String getGrpcDemandDepositServiceHost(DefaultOptions options) {
        return (String) options.getPipelineContext()
            .get("grpc.demandDepositService.host");
    }

    /**
     * Demand Deposit Service port 取得。
     *
     * @param options パイプラインのオプション
     * @return サービスポート
     */
    public static Integer getGrpcDemandDepositServicePort(DefaultOptions options) {
        return (Integer) options.getPipelineContext()
            .get("grpc.demandDepositService.port");
    }

    /**
     * Demand Deposit Service TLSは利用可能 かどうかを判断する。
     *
     * @param options パイプラインのオプション
     * @return TLSは利用可能判断結果
     */
    public static boolean isTlsEnabledForGrpcDemandDepositService(DefaultOptions options) {
        return (boolean) options.getPipelineContext()
            .get("grpc.demandDepositService.enableTls");
    }

    /**
     * Demand Deposit Service version 取得。
     *
     * @param options パイプラインのオプション
     * @return サービスバージョン
     */
    public static String getGrpcDemandDepositServiceVersion(DefaultOptions options) {
        return (String) options.getPipelineContext()
            .get("grpc.demandDepositService.version");
    }
}
