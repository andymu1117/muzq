package com.neobank.fcore.demanddeposit.transform;

import java.util.List;

import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.commons.collections.IteratorUtils;

import com.neobank.fcore.demanddeposit.pipeline.SettlementCollationPipeline;

/**
 * ファイルを必ず出力するようにデータセットがない場合に出力対象へ空のデータを設定する。
 */
@SuppressWarnings("serial")
public class SettlementCollationFileOutputEmptyCheckFn implements SerializableFunction<Iterable<String>, String> {

    private String processType;

    public SettlementCollationFileOutputEmptyCheckFn(String processType) {
        this.processType = processType;
    }

    /**
     * ファイルを必ず出力するようにデータセットがない場合に出力対象へ空のデータを設定する。
     *
     * @param input 出力対象の文字列（1/0つのStringしか取り得ない）
     * @return 出力対象の文字列
     */
    @Override
    public String apply(Iterable<String> input) {
        @SuppressWarnings("unchecked")
        List<String> inputList = IteratorUtils.toList(input.iterator());
        if (inputList.isEmpty()) {
            switch (processType) {
                case SettlementCollationPipeline.OUTPUT_TYPE_SUMMARY:
                    return "{\"1\":null,\"2\":null,\"3\":null,\"4\":null,\"5\":null,\"6\":null,\"7\":null,\"8\":null}";
                case SettlementCollationPipeline.OUTPUT_TYPE_DETAIL:
                    return "{\"1\":[],\"2\":[],\"3\":[],\"4\":[]}";
                case SettlementCollationPipeline.OUTPUT_TYPE_RECONCILE:
                    return "[]";
                default:
                    return "{}";
            }
        } else {
            return inputList.get(0);
        }
    }
}
