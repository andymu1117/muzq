/**
 * {@link com.accenture.mainri.core.avro.identifier.Identifier} を実装しているクラスを格納するパッケージ。
 */
package com.neobank.fcore.demanddeposit.avro.identifier;
