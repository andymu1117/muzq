package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.neobank.fcore.demanddeposit.pb.command.message.CustomerAdvantageConditionUpdateResponse;

public class CustomerAdvantageConditionUpdateResponseDto implements Serializable {

    private static final long serialVersionUID = -410755250332142718L;
    private CustomerAdvantageConditionUpdateResponse customerAdvantageConditionUpdateResponse;

    public CustomerAdvantageConditionUpdateResponseDto() {

    }

    /**
     * 顧客優遇条件更新APIのレスポンスと後続処理に必要な情報を渡す。
     *
     * @param customerAdvantageConditionUpdateResponse 顧客優遇条件更新APIのレスポンス
     */
    public CustomerAdvantageConditionUpdateResponseDto(
        CustomerAdvantageConditionUpdateResponse customerAdvantageConditionUpdateResponse) {
        super();
        this.customerAdvantageConditionUpdateResponse = customerAdvantageConditionUpdateResponse;
    }

    public CustomerAdvantageConditionUpdateResponse getCustomerAdvantageConditionUpdateResponse() {
        return customerAdvantageConditionUpdateResponse;
    }

    public void setCustomerAdvantageConditionUpdateResponse(
        CustomerAdvantageConditionUpdateResponse customerAdvantageConditionUpdateResponse) {
        this.customerAdvantageConditionUpdateResponse = customerAdvantageConditionUpdateResponse;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
