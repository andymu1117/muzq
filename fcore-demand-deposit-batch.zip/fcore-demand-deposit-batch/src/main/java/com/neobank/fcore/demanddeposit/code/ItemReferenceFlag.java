package com.neobank.fcore.demanddeposit.code;

/**
 * 基本商品参照フラグ。
 *
 */
public enum ItemReferenceFlag {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:1255] 基本商品参照フラグ
    NO("0"), YES("1");
    // --- Generated Code Ends---

    private String code;

    ItemReferenceFlag(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
