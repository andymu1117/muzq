package com.neobank.fcore.demanddeposit.pipeline.options;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.Validation;
import org.apache.beam.sdk.options.ValueProvider;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

/**
 * 起動パラメータ。
 *
 */
public interface AccrualRegularCreateOptions extends DefaultOptions {
    @Description("ProcessDate")
    @Validation.Required
    ValueProvider<String> getProcessDate();

    @Description("ProgramId")
    @Default.String("CBT003F")
    String getProgramId();

    void setProcessDate(ValueProvider<String> value);

    void setProgramId(String programId);
}
