package com.neobank.fcore.demanddeposit.transform;

import java.io.IOException;
import java.text.ParseException;

import org.apache.beam.sdk.transforms.DoFn;

import com.neobank.fcore.demanddeposit.utils.FileUtils;

/**
 * GCSの対象ファイルを開き、バイト配列を取得する。
 */
public class SettlementCollationByteReaderFn extends DoFn<String, byte[]> {

    private String bucket;

    private static final String SETTLEMENT_COLLATION_SUBPATH = "settlement-collation/Dzgscollation_";

    /**
     * 初期値設定用コンストラクタ。
     *
     * @param bucket バケットパス
     */
    public SettlementCollationByteReaderFn(String bucket) {
        this.bucket = bucket;
    }

    /**
     * GCSの対象ファイルを開きバイト配列を取得する。
     *
     * @param paramDate パラメータで指定された対象日付(yyyyMMdd)
     * @param out 読み込んだバイト配列
     * @throws ParseException パラメータで設定された日付をyyyyMMddとしてparseできなかった場合の例外
     * @throws IOException ファイルのリネーム、ファイルの読み込み時にエラーが発生した場合の例外
     */
    @ProcessElement
    public void processElement(@Element String paramDate, OutputReceiver<byte[]> out)
        throws ParseException, IOException {
        // ファイル読み込み
        out.output(FileUtils.readMatchedOnlyOneFile(this.getSearchFilePath(SETTLEMENT_COLLATION_SUBPATH, paramDate)));
    }

    /**
     * ファイル検索用のパスを生成する。
     *
     * @param subPath パスの一部
     * @param paramDate パラメータで指定された対象日付(yyyyMMdd)
     * @return ファイル検索用パス
     */
    private String getSearchFilePath(String subPath, String paramDate) {
        return new StringBuilder().append(bucket)
            .append(subPath)
            .append(paramDate)
            .append("*")
            .toString();
    }
}
