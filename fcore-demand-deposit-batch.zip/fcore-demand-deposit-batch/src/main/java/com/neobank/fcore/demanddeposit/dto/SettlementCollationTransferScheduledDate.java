
package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@SuppressWarnings("serial")
public class SettlementCollationTransferScheduledDate extends SettlementCollationBase implements Serializable {
    // 全銀処理コード
    private String zenginProcessCode;
    // 管理番号
    private String managementNumber;

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        // FINDBUGS回避のため、値を変数に設定。
        boolean zenginBankFileHashCode = false;
        return HashCodeBuilder.reflectionHashCode(this, zenginBankFileHashCode);
    }

    public String getZenginProcessCode() {
        return zenginProcessCode;
    }

    public void setZenginProcessCode(String zenginProcessCode) {
        this.zenginProcessCode = zenginProcessCode;
    }

    public String getManagementNumber() {
        return managementNumber;
    }

    public void setManagementNumber(String managementNumber) {
        this.managementNumber = managementNumber;
    }

}
