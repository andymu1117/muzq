package com.neobank.fcore.demanddeposit.grpc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.grpc.Metadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.auth.IdToken;

/**
 * Grpc Request用Meta Dataを作成。
 *
 */
public class GrpcMetaBuilder {

    private static final Logger logger = LoggerFactory.getLogger(GrpcMetaBuilder.class);

    /**
     * ヘーダ。
     */
    private Metadata headers = new Metadata();

    /**
     * Grpc ヘーダーにAPI Version情報を追加する。
     *
     * @param apiVersion API Version
     * @return Meta Builder
     */
    public GrpcMetaBuilder apiVersion(String apiVersion) {
        Metadata.Key<String> verersion =
            Metadata.Key.of("x-grpc-api-version", io.grpc.Metadata.ASCII_STRING_MARSHALLER);
        headers.put(verersion, apiVersion);
        logger.debug("gRPC request Header : {}", headers);
        return this;
    }

    /**
     * Grpc ヘーダーにtoken情報を追加する。
     *
     * @param programId プログラムID
     * @return Meta Builder
     * @throws JsonProcessingException JSON処理異常
     */
    public GrpcMetaBuilder token(String programId) throws JsonProcessingException {
        IdToken idToken = new IdToken();
        ObjectMapper mapper = new ObjectMapper();
        idToken.setSubject(programId);
        String idTokenJson = mapper.writeValueAsString(idToken);
        Metadata.Key<String> token = Metadata.Key.of("X-Id-Token", io.grpc.Metadata.ASCII_STRING_MARSHALLER);
        headers.put(token, idTokenJson);
        logger.debug("gRPC request Header : {}", headers);
        return this;
    }

    public Metadata getHeaders() {
        return headers;
    }

}
