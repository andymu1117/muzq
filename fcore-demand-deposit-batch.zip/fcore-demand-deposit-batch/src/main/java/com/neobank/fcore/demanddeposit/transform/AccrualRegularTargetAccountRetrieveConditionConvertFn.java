package com.neobank.fcore.demanddeposit.transform;

import java.time.OffsetDateTime;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.dto.AccrualRegularTargetAccountRetrieveConditionDto;
import com.neobank.fcore.demanddeposit.pipeline.options.AccrualRegularCreateOptions;
import com.neobank.fcore.demanddeposit.utils.OffsetDateTimeUtils;

@SuppressWarnings("serial")
public class AccrualRegularTargetAccountRetrieveConditionConvertFn
    extends DoFn<String, AccrualRegularTargetAccountRetrieveConditionDto> {

    private static final Logger LOGGER =
        LoggerFactory.getLogger(AccrualRegularTargetAccountRetrieveConditionConvertFn.class);

    /**
     * 利息決算元加処理対象口座抽出条件エンティティを作成する。
     *
     * @param element バッチ実行パラメータ（processDate）
     * @param context プロセスコンテクスト
     */
    @ProcessElement
    public void processElement(@Element String element, ProcessContext context) {
        LOGGER.debug("processDate: {}", element);
        AccrualRegularCreateOptions options = context.getPipelineOptions()
            .as(AccrualRegularCreateOptions.class);
        OffsetDateTimeUtils offsetDateTimeUtils = new OffsetDateTimeUtils(options);
        if (!offsetDateTimeUtils.checkIso8601DateFormat(element)) {
            throw new IllegalArgumentException("element processDate is illegal argument!");
        }
        if (!offsetDateTimeUtils.checkDateIsNotFutureDay(element)) {
            throw new IllegalArgumentException("element processDate is illegal argument!");
        }
        OffsetDateTime interestDateOffsetTime = offsetDateTimeUtils.parserStringDateAsMaxOffsetTime(element)
            .minusDays(1);
        context.output(new AccrualRegularTargetAccountRetrieveConditionDto(
            offsetDateTimeUtils.formatOffetDateTimeToIso8601WithoutHyphen(interestDateOffsetTime),
            offsetDateTimeUtils.formatOffsetDateTimeAsMaxTimeString(interestDateOffsetTime)));
    }
}
