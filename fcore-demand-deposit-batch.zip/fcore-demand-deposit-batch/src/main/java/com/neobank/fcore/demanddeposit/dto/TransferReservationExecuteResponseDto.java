package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.neobank.fcore.demanddeposit.pb.command.message.TransferReservationExecuteResponse;

@SuppressWarnings("serial")
public class TransferReservationExecuteResponseDto implements Serializable {

    private TransferReservationExecuteResponse transferReservationExecuteResponse;

    /**
     * 振込予約実行APIのレスポンスと後続処理に必要な情報を渡す。
     *
     * @param transferReservationExecuteResponse 振込予約実行APIのレスポンス
     */
    public TransferReservationExecuteResponseDto(
        TransferReservationExecuteResponse transferReservationExecuteResponse) {
        super();
        this.transferReservationExecuteResponse = transferReservationExecuteResponse;
    }

    public TransferReservationExecuteResponse getTransferReservationExecuteResponse() {
        return transferReservationExecuteResponse;
    }

    public void setTransferReservationExecuteResponse(
        TransferReservationExecuteResponse transferReservationExecuteResponse) {
        this.transferReservationExecuteResponse = transferReservationExecuteResponse;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
