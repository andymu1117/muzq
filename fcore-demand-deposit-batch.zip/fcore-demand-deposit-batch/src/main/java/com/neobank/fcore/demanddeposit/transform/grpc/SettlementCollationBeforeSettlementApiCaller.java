package com.neobank.fcore.demanddeposit.transform.grpc;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.grpc.ManagedChannel;
import io.grpc.stub.MetadataUtils;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.mainri.core.io.GrpcConnector;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.exception.SystemFailureException;
import com.neobank.fcore.demanddeposit.pb.command.TransactionCommandGrpc;
import com.neobank.fcore.demanddeposit.pb.command.TransactionCommandGrpc.TransactionCommandBlockingStub;
import com.neobank.fcore.demanddeposit.pb.command.message.TransactionRegisterSuspenseReceiptRequest;
import com.neobank.fcore.demanddeposit.pb.command.message.TransactionRegisterSuspenseReceiptResponse;
import com.neobank.fcore.demanddeposit.pb.query.QueryVersion;
import com.neobank.fcore.demanddeposit.utils.GrpcUtils;

/**
 * 仮受金登録APIを呼び出す。
 */
@SuppressWarnings("serial")
public class SettlementCollationBeforeSettlementApiCaller extends
    // SonarQube
    DoFn<KV<List<String>, SettlementCollationFile>, Boolean> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationBeforeSettlementApiCaller.class);

    private GrpcConnector grpcConnector;
    private transient TransactionCommandBlockingStub stub;
    private transient ManagedChannel channel;
    private ValueProvider<Boolean> callApiFlag;

    /**
     * gRPC用の接続を設定するコンストラクタ。
     *
     * @param grpcConnector GrpcConnector
     * @param callApiFlag trueの場合APIを呼び出す
     */
    public SettlementCollationBeforeSettlementApiCaller(GrpcConnector grpcConnector,
        ValueProvider<Boolean> callApiFlag) {
        this.grpcConnector = grpcConnector;
        this.callApiFlag = callApiFlag;
    }

    /**
     * gRPCクライアントの初期化。
     */
    @Setup
    public void setup() {
        // stub, channelともにThreadsafeのためstubはここでキャッシュ。
        channel = grpcConnector.createManagedChannel();
        stub = TransactionCommandGrpc.newBlockingStub(channel);
    }

    /**
     * 仮受金登録APIを呼び出す。
     *
     * @param input 前営業日決済の合算値
     * @param out 成功時true
     * @throws JsonProcessingException JSONの処理に失敗した場合のException
     */
    @ProcessElement
    public void processElement(@Element KV<List<String>, SettlementCollationFile> input, OutputReceiver<Boolean> out)
        throws JsonProcessingException {

        if (!callApiFlag.get() || input.getValue()
            .getAmount() == 0) {
            return;
        }

        TransactionRegisterSuspenseReceiptRequest grpcRequest = TransactionRegisterSuspenseReceiptRequest.newBuilder()
            .setTransactionAmount(input.getValue()
                .getAmount())
            .build();
        TransactionRegisterSuspenseReceiptResponse grpcResponse = null;

        stub = MetadataUtils.attachHeaders(stub, GrpcUtils.createGrpcHeaders(QueryVersion.API_VERSION));
        try {
            grpcResponse = stub.registerSuspenseReceipt(grpcRequest);
        } catch (RuntimeException e) {
            LOGGER.error("grpc request failed, Request:{}", grpcRequest);
            throw e;
        }

        if (grpcResponse != null) {
            out.output(Boolean.TRUE);
        } else {
            LOGGER.error("grpc request failed, Request:{}", grpcRequest);
            throw new SystemFailureException("grpc request failed");
        }
    }

    /**
     * gRPCクライアントのシャットダウン。
     */
    @Teardown
    public void teardown() {
        if (!channel.isShutdown()) {
            channel.shutdown();
        }
    }
}
