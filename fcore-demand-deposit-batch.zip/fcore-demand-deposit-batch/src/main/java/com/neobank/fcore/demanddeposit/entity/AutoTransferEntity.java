package com.neobank.fcore.demanddeposit.entity;

import java.io.Serializable;

import com.accenture.mainri.core.entity.BaseEntity;
import com.accenture.mainri.core.entity.annotation.Table;

/**
 * 自動振込実行に必要な情報。 ADIP から生成し、不要な項目を削除しています。
 */
@SuppressWarnings("serial")
@Table("AutoTransfers")
public class AutoTransferEntity extends BaseEntity implements Serializable {
    // 自動振込ID
    private String autoTransferId;
    // 預金口座ID
    private String accountId;

    public void setAutoTransferId(String autoTransferId) {
        this.autoTransferId = autoTransferId;
    }

    public String getAutoTransferId() {
        return this.autoTransferId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return this.accountId;
    }
}
