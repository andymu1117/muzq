package com.neobank.fcore.demanddeposit.repository;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.google.cloud.spanner.Statement;

import com.accenture.mainri.core.spanner.SpannerQueryBuilder;
import com.accenture.mainri.core.spanner.SpannerStatementHelper;
import com.accenture.mainri.core.sql.template.FileTemplateProvider;

/**
 * 【全銀】金融機関取得用のクエリを生成する。
 */
public class SettlementCollationStatementBuilder implements Serializable {

    private static final String BEFORE_WORK_DAY_TEXT = "PreviousBusinessDate";
    private static final String TARGET_DATE_TEXT = "CurrentBusinessDate";

    public SettlementCollationStatementBuilder() {
        // CONSTRUCTOR
    }

    /**
     * ファイルからSQLを読み込み、変数を設定する。
     *
     * @param ctx PipelineContext
     * @param filename SQLのファイル名
     * @param parameters SQLに設定する変数マップ
     * @return Statement
     */
    protected Statement buildStatement(Map<String, Object> ctx, String filename, Map<String, Object> parameters) {
        FileTemplateProvider templateProvider = new FileTemplateProvider(ctx, filename);
        SpannerQueryBuilder statementBuilder = new SpannerQueryBuilder();
        String query = statementBuilder.setQueryProvider(templateProvider)
            .setParameters(parameters)
            .build();
        return SpannerStatementHelper.build(query, parameters);
    }

    /**
     * selectSettlementCollationInboundNotTransferSummary。
     *
     * @param ctx コンテキスト
     * @param targetDate 対象日付
     * @return Statement
     */
    public Statement selectSettlementCollationPendings(Map<String, Object> ctx, String targetDate) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("TargetDate", convertStringDateToSqlDate(targetDate));
        String filename = "SelectSettlementCollationPendings";
        return this.buildStatement(ctx, filename, parameters);
    }

    /**
     * selectSettlementCollationInboundNotTransferSummary。
     *
     * @param ctx コンテキスト
     * @param beforeWorkDay 抽出期間From
     * @param targetDate 抽出期間To
     * @param filename SQLファイル名
     * @return Statement
     */
    public Statement selectSettlementCollationData(Map<String, Object> ctx, String beforeWorkDay, String targetDate,
        String filename) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(BEFORE_WORK_DAY_TEXT, beforeWorkDay);
        parameters.put(TARGET_DATE_TEXT, convertStringDateToSqlDate(targetDate));
        return this.buildStatement(ctx, filename, parameters);
    }

    private String convertStringDateToSqlDate(String date) {
        return new StringBuilder().append(date.substring(0, 4))
            .append('-')
            .append(date.substring(4, 6))
            .append('-')
            .append(date.substring(6, 8))
            .toString();
    }

}
