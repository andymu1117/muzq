package com.neobank.fcore.demanddeposit.code;

/**
 * 顧客ステータス。
 *
 */
public enum CustomerStatus {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:4] 顧客ステータス
    NORMAL("1"), CANCELED("2"), LOGICAL_DELETED("9");
    // --- Generated Code Ends---

    private String code;

    CustomerStatus(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
