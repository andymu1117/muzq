package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import com.google.cloud.spanner.Struct;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@SuppressWarnings("serial")
public class SettlementCollationOfficerSummaryFile extends SettlementCollationBase implements Serializable {
    // 件数
    private Long number;
    // エラー有無
    private String errorFlag;

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        // FINDBUGS回避のため、値を変数に設定。
        boolean zenginBankFileHashCode = false;
        return HashCodeBuilder.reflectionHashCode(this, zenginBankFileHashCode);
    }

    public SettlementCollationOfficerSummaryFile() {
    }

    /**
     * DBの値を設定する(明細集計値)。
     *
     * @param struct 決済照合用に取得した明細集計値
     */
    public SettlementCollationOfficerSummaryFile(Struct struct) {
        // 集計値のため、後続の処理がnullを想定したものになっていない。
        // SQL仕様上データがない場合にnullになるため、ここでは値が無かった場合に0を設定する。
        amount = struct.isNull("Amount") ? 0L : struct.getLong("Amount");
        number = struct.isNull("Number") ? 0L : struct.getLong("Number");
    }

    public Long getNumber() {
        return number;
    }

    public void setNumber(Long number) {
        this.number = number;
    }

    public String getErrorFlag() {
        return errorFlag;
    }

    public void setErrorFlag(String errorFlag) {
        this.errorFlag = errorFlag;
    }

}
