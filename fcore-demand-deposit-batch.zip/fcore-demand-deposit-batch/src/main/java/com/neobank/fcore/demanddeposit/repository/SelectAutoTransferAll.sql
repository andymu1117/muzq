SELECT
  AutoTransferId,
  AccountId,
  CreationDate,
  CreationUserId,
  UpdatedDate,
  UpdatedUserId
FROM
  AutoTransfers@{FORCE_INDEX=IDX_First_Hit_Column_AutoTransferActiveDateFrom_AutoTransfers}
WHERE
  DeleteFlag = "0" AND
  (
    @TargetDate BETWEEN DATE_ADD(AutoTransferActiveDateFrom, INTERVAL  -2 MONTH) AND DATE_ADD(AutoTransferActiveDateTo, INTERVAL  1 MONTH) OR
    (
      @TargetDate >= DATE_ADD(AutoTransferActiveDateFrom, INTERVAL  -2 MONTH) AND AutoTransferActiveDateTo IS NULL
    )
  )
ORDER BY AccountId ASC
