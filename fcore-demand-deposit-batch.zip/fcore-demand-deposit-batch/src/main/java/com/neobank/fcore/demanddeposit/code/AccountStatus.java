package com.neobank.fcore.demanddeposit.code;

/**
 * 口座ステータス。
 *
 */
public enum AccountStatus {
    // --- DO NOT EDIT Generated from ADIP ---
    // [attrid:52] 口座ステータス
    INIT("0"), NORMAL("1"), CANCELED("2");
    // --- Generated Code Ends---

    private String code;

    AccountStatus(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
