package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.neobank.fcore.demanddeposit.pb.command.message.AccountInterestCreateAccrualRegularResponse;

@SuppressWarnings("serial")
public class AccountInterestCreateAccrualRegularResponseDto implements Serializable {
    private AccountInterestCreateAccrualRegularResponse accountInterestCreateAccrualRegularResponse;

    /**
     * 利息決算元加APIのレスポンスと後続処理に必要な情報を渡す。
     *
     * @param accountInterestCreateAccrualRegularResponse 利息決算元加APIのレスポンス
     */
    public AccountInterestCreateAccrualRegularResponseDto(
        AccountInterestCreateAccrualRegularResponse accountInterestCreateAccrualRegularResponse) {
        super();
        this.accountInterestCreateAccrualRegularResponse = accountInterestCreateAccrualRegularResponse;
    }

    public AccountInterestCreateAccrualRegularResponse getAccountInterestCreateAccrualRegularResponse() {
        return accountInterestCreateAccrualRegularResponse;
    }

    public void setAccountInterestCreateAccrualRegularResponse(
        AccountInterestCreateAccrualRegularResponse accountInterestCreateAccrualRegularResponse) {
        this.accountInterestCreateAccrualRegularResponse = accountInterestCreateAccrualRegularResponse;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    public AccountInterestCreateAccrualRegularResponseDto() {

    }
}
