/**
 * {@link com.accenture.mainri.core.pipeline.options.DefaultOptions}
 * を継承しているPipeline用Optionクラスを格納するパッケージ。
 */
package com.neobank.fcore.demanddeposit.pipeline.options;
