package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.join.CoGbkResult;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.commons.collections.IteratorUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationDb;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile;

/**
 * システムで作成がされる種類の明細向けチェック関数。 不整合条件(ファイルとテーブルのいずれか一方にしか存在しないデータ、「金額」が一致しないデータ)を確認する。
 */
@SuppressWarnings("serial")
public class SettlementCollationCheckAmountTransferFn extends DoFn<KV<List<String>, CoGbkResult>, Integer> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationCheckAmountTransferFn.class);

    private TupleTag<SettlementCollationBase> fileDataTag;
    private TupleTag<SettlementCollationBase> databaseDataTag;
    private TupleTag<Integer> errorNumTag;
    private TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>> errorDataTag;
    private PCollectionView<Integer> diffResultInboundTransferErrorNum;
    private Enum<SettlementCollationDataTypeCode> dataType;

    /**
     * 値受け渡しの為のタグを設定するコンストラクタ。
     *
     * @param fileDataTag リコンサイルファイル用のタグ
     * @param databaseDataTag リコンサイル情報用のタグ
     * @param errorNumTag エラー数出力用タグ
     * @param errorDataTag エラーデータ出力用タグ
     * @param diffResultInboundTransferErrorNum サマリのエラー数
     * @param dataType データ種別
     */
    public SettlementCollationCheckAmountTransferFn(TupleTag<SettlementCollationBase> fileDataTag,
        TupleTag<SettlementCollationBase> databaseDataTag, TupleTag<Integer> errorNumTag,
        TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>> errorDataTag,
        PCollectionView<Integer> diffResultInboundTransferErrorNum, Enum<SettlementCollationDataTypeCode> dataType) {
        this.fileDataTag = fileDataTag;
        this.databaseDataTag = databaseDataTag;
        this.errorNumTag = errorNumTag;
        this.errorDataTag = errorDataTag;
        this.diffResultInboundTransferErrorNum = diffResultInboundTransferErrorNum;
        this.dataType = dataType;
    }

    /**
     * システムで作成がされる種類の明細向けチェック関数。
     * システムでの登録のためシステム障害以外での明細不一致は考えにくく、サマリのエラーが無い場合は明細でもエラーがないものとしチェックをスキップする。
     *
     * @param context コンテキスト
     */
    @ProcessElement
    public void processElement(ProcessContext context) {
        // 振込系ではエラーがない場合は明細での突合処理をスキップする
        if (context.sideInput(diffResultInboundTransferErrorNum) > 0) {
            this.process(context);
        } else {
            context.output(errorNumTag, 0);
        }
    }

    /**
     * 不整合条件(ファイルとテーブルのいずれか一方にしか存在しないデータ、「金額」が一致しないデータ)を確認する。
     *
     * @param context コンテキスト
     */
    private void process(ProcessContext context) {
        KV<List<String>, CoGbkResult> element = context.element();

        // 本機能内で生成した変数で型が自明な為、チェック対象外とする。
        @SuppressWarnings("unchecked")
        List<SettlementCollationBase> fileList = IteratorUtils.toList(element.getValue()
            .getAll(fileDataTag)
            .iterator());
        // 本機能内で生成した変数で型が自明な為、チェック対象外とする。
        @SuppressWarnings("unchecked")
        List<SettlementCollationBase> dbList = IteratorUtils.toList(element.getValue()
            .getAll(databaseDataTag)
            .iterator());

        boolean errorFlag = false;
        // DB/FILEデータのリストは1/0件以外取り得ない
        if (fileList.size() == 1 && dbList.size() == 1) {
            // 「金額」一致を確認する
            Long fileAmount = fileList.get(0)
                .getAmount();
            Long dbAmount = dbList.get(0)
                .getAmount();
            if (!fileAmount.equals(dbAmount)) {
                errorFlag = true;
            }
            this.output(fileList.get(0), dbList.get(0), context, errorFlag, fileList, dbList);
        } else {
            // ファイルとテーブルのいずれか一方にしか存在しないデータ
            errorFlag = true;
            if (fileList.isEmpty()) {
                this.output(new SettlementCollationFile(), dbList.get(0), context, errorFlag, fileList, dbList);
            } else {
                this.output(fileList.get(0), new SettlementCollationDb(), context, errorFlag, fileList, dbList);
            }
        }
    }

    private void output(SettlementCollationBase file, SettlementCollationBase db, ProcessContext context,
        boolean errorFlag, List<SettlementCollationBase> fileList, List<SettlementCollationBase> dbList) {
        Gson gson = new Gson();

        if (errorFlag) {
            String fileListString = gson.toJson(fileList);
            String dbListString = gson.toJson(dbList);
            LOGGER.warn("settlement collation detail collation failed: file records{}, db records{}", fileListString,
                dbListString);
            SettlementCollationOfficerDetailFile result = new SettlementCollationOfficerDetailFile(file, db);
            List<String> keys = new ArrayList<>();
            keys.add(((SettlementCollationDataTypeCode) dataType).getCode());
            context.output(errorDataTag, KV.of(keys, result));
            context.output(errorNumTag, 1);
        } else {
            context.output(errorNumTag, 0);
        }
    }
}
