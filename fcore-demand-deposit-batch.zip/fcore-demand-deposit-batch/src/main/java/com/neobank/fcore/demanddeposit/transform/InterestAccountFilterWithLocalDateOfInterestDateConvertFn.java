package com.neobank.fcore.demanddeposit.transform;

import org.apache.beam.sdk.transforms.DoFn;
import org.springframework.beans.BeanUtils;

import com.accenture.mainri.core.pipeline.options.DefaultOptions;

import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterEntity;
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity;
import com.neobank.fcore.demanddeposit.utils.OffsetDateTimeUtils;

@SuppressWarnings("serial")
public class InterestAccountFilterWithLocalDateOfInterestDateConvertFn
    extends DoFn<InterestAccountFilterEntity, InterestAccountFilterWithLocalDateOfInterestDateEntity> {

    /**
     * 利息なし口座対象をフィルターする用エンティティ（利息基準日（LocalDate）付け）を作成する。
     *
     * @param element 処理対象フィルター用エンティティ
     * @param context プロセスコンテクスト
     */
    @ProcessElement
    public void processElement(@Element InterestAccountFilterEntity element, ProcessContext context) {
        OffsetDateTimeUtils offsetDateTimeUtils = new OffsetDateTimeUtils(context.getPipelineOptions()
            .as(DefaultOptions.class));
        InterestAccountFilterWithLocalDateOfInterestDateEntity entity =
            new InterestAccountFilterWithLocalDateOfInterestDateEntity();

        BeanUtils.copyProperties(element, entity);
        entity.setInterestDateWithoutHyphenToLocalDate(
            offsetDateTimeUtils.parserIso8601WithoutHyphenToLocalDate(element.getInterestDate()));
        context.output(entity);
    }
}
