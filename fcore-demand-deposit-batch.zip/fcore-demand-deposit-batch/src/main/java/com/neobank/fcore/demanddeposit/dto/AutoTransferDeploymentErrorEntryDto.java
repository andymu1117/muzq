package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.neobank.fcore.demanddeposit.pb.command.message.AutoTransferDeployRequestOrBuilder;

/**
 * 失敗した自動振込の情報。
 *
 */
@SuppressWarnings("serial")
public class AutoTransferDeploymentErrorEntryDto implements Serializable {

    private String autoTransferId;
    private String errorMessage;

    public String getAutoTransferId() {
        return autoTransferId;
    }

    public void setAutoTransferId(String value) {
        autoTransferId = value;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String value) {
        errorMessage = value;
    }

    public AutoTransferDeploymentErrorEntryDto() {
    }

    /**
     * 失敗した自動振込の情報でオブジェクトを作成する。
     *
     * @param autoTransfer 失敗したリクエスト。
     * @param exception 例外情報
     */
    public AutoTransferDeploymentErrorEntryDto(AutoTransferDeployRequestOrBuilder autoTransfer, Exception exception) {
        this.autoTransferId = autoTransfer.getAutoTransferId();
        this.errorMessage = exception.getMessage();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.NO_CLASS_NAME_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }
}
