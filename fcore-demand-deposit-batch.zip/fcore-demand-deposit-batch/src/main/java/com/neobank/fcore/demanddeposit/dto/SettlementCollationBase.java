
package com.neobank.fcore.demanddeposit.dto;

import java.io.Serializable;

import com.google.cloud.spanner.Struct;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.accenture.mainri.core.entity.DataClassBase;

/**
 * 決済照合の比較に必要な項目は本クラスで保持し、子クラスではCoGroupByにてレコードの紐づけに必要なキー情報を保持する事。
 */
@SuppressWarnings("serial")
public class SettlementCollationBase extends DataClassBase implements Serializable {

    // 金額
    protected Long amount;

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, false);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    public SettlementCollationBase() {
    }

    /**
     * DBの値を設定する(明細集計値)。
     *
     * @param struct 決済照合用に取得した明細集計値
     */
    public SettlementCollationBase(Struct struct) {
        if (struct.isNull("Amount")) {
            amount = 0L;
        } else {
            amount = struct.getLong("Amount");
        }
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

}
