package com.neobank.fcore.demanddeposit.utils;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.exception.SystemFailureException;

public class Conversion {
    private static final Logger LOGGER = LoggerFactory.getLogger(Conversion.class);

    private Conversion() {
    }

    /**
     * byte配列を文字列化し、セミコロン";"で区切ってList化する。
     *
     * @param target 変換対象のバイト列
     * @return セミコロンで区切ってList化された文字列
     */
    public static List<String> separateBytesBySemicolon(byte[] target) {
        return Arrays.asList(Conversion.byteToString(target)
            .split(";", -1));
    }

    /**
     * byte配列を文字列化し、改行文字列で行に、セミコロン";"で項目に区切って2次元List化する。
     *
     * @param target 変換対象のバイト列
     * @return セミコロンで区切ってList化された文字列
     */
    public static List<List<String>> separateBytesBySemicolonAndBreakLine(byte[] target) {
        List<List<String>> result = new ArrayList<>();
        Arrays.asList(
            // 最後の改行を除去する
            Conversion.trimTrailingLf(Conversion.byteToString(target))
                .split("\n", -1))
            .forEach(element -> result.add(Arrays.asList(element.split(";", -1))));
        return result;
    }

    /**
     * byte列をUTF8で文字列へ変換する。
     *
     * @param target 対象値
     * @return 処理結果
     */
    public static String byteToString(byte[] target) {
        try {
            CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();
            ByteBuffer in = ByteBuffer.wrap(target);
            decoder.decode(in);
        } catch (CharacterCodingException e) {
            LOGGER.error("can't encode target: {}", target);
            throw new SystemFailureException(e);
        }
        return new String(target, 0, target.length, StandardCharsets.UTF_8);
    }

    /**
     * 後方改行(LF)を除去する。
     *
     * @param target 対象値
     * @return 処理結果
     */
    public static String trimTrailingLf(String target) {
        return StringUtils.stripEnd(target, "\n");
    }
}
