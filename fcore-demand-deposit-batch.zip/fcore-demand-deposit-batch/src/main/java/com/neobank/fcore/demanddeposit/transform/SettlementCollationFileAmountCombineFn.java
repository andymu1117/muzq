package com.neobank.fcore.demanddeposit.transform;

import java.util.ArrayList;
import java.util.List;

import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile;

/**
 * 金額値を合算する。
 */
@SuppressWarnings("serial")
public class SettlementCollationFileAmountCombineFn
    implements SerializableFunction<Iterable<KV<List<String>, SettlementCollationFile>>,
        // SONARQUBE
        KV<List<String>, SettlementCollationFile>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCollationFileAmountCombineFn.class);

    private String key;

    public SettlementCollationFileAmountCombineFn(String key) {
        this.key = key;
    }

    /**
     * 金額値を合算する。
     *
     * @param input ファイルレコード
     * @return 合算値
     */
    @Override
    public KV<List<String>, SettlementCollationFile> apply(Iterable<KV<List<String>, SettlementCollationFile>> input) {

        Long sumAmount = 0L;
        for (KV<List<String>, SettlementCollationFile> item : input) {
            sumAmount += item.getValue()
                .getAmount();
        }
        SettlementCollationFile result = new SettlementCollationFile();
        result.setAmount(sumAmount);
        List<String> keys = new ArrayList<>();
        keys.add(key);
        LOGGER.debug("result summarize file type:{}, {}", keys, result);
        return KV.of(keys, result);
    }
}
