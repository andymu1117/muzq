package com.neobank.fcore.demanddeposit.utils;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateUtils {
    private DateUtils() {
        throw new IllegalStateException("Utility class");
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);

    private static final ZoneId DEFAULT_TIME_ZONE = ZoneId.of("Asia/Tokyo");
    private static final DateTimeFormatter DATETIME_FORMATTER_WITHOUT_HYPHEN = DateTimeFormatter.ofPattern("yyyyMMdd")
        .withZone(DEFAULT_TIME_ZONE);
    public static final DateTimeFormatter DATETIME_FORMATTER_ISO8601 = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        .withZone(DEFAULT_TIME_ZONE);

    /**
     * 特定書式(yyyy-MM-dd)の日付文字列をLocalDateに変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付
     */
    public static LocalDate parseIso8601ToLocalDate(String date) {
        return LocalDate.parse(date, DATETIME_FORMATTER_ISO8601);
    }

    /**
     * 特定書式(yyyyMMdd)の日付文字列をLocalDateに変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付
     */
    public static LocalDate parseIso8601WithoutHyphenToLocalDate(String date) {
        return LocalDate.parse(date, DATETIME_FORMATTER_WITHOUT_HYPHEN);
    }

    /**
     * ChronoLocalDateを特定書式(yyyyMMdd)の日付に変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public static String formatLocalDateToIso8601WithoutHyphen(ChronoLocalDate date) {
        return date.format(DATETIME_FORMATTER_WITHOUT_HYPHEN);
    }

    /**
     * ChronoLocalDateを特定書式(yyyy-MM-dd)の日付に変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public static String formatLocalDateToIso8601(ChronoLocalDate date) {
        return date.format(DATETIME_FORMATTER_ISO8601);
    }

    /**
     * LocalDateを今日の最後の時間のZonedDateTimeに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public static String formatLocalDateToTodayMaxTime(LocalDate date) {
        ZonedDateTime zonedDateTime = ZonedDateTime.of(date, LocalTime.MAX, DEFAULT_TIME_ZONE);
        return zonedDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    /**
     * LocalDateを今日の最初の時間のZonedDateTimeに変更する、そして特定書式(yyyy-MM-ddT00:00:00+Zone)の日付文字列に変換する。
     *
     * @param date 処理対象
     * @return 処理後の日付文字列
     */
    public static String formatLocalDateToTodayMinTime(LocalDate date) {
        ZonedDateTime zonedDateTime = ZonedDateTime.of(date, LocalTime.MIN, DEFAULT_TIME_ZONE);
        return zonedDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    /**
     * LocalDateを今日の最初の時間のZonedDateTimeに変更する、そして特定書式(yyyy-MM-ddT00:00:00+Zone)の日付文字列に変換する。
     *
     * @return 処理後の日付文字列
     */
    public static LocalDate getCurrentTimeOfDefaultTimeZone() {
        return LocalDate.now(DateUtils.DEFAULT_TIME_ZONE);
    }

    /**
     * 処理対象日付が未来日ではないかをバリテーションする。
     *
     * @param date 処理対象
     * @return バリテーション結果（チェックOK：true、チェックNG：false）
     */
    public static boolean checkDateIsNotFutureDay(String date) {
        if (!checkDateFormat(date)) {
            return false;
        }

        LocalDate now = DateUtils.getCurrentTimeOfDefaultTimeZone();
        LocalDate targetDate = LocalDate.parse(date, DateUtils.DATETIME_FORMATTER_ISO8601)
            .minusDays(1);
        if (!now.isAfter(targetDate)) {
            LOGGER.debug("inpueDate can not be after of today! inputDate: {}", date);
            return false;
        }
        return true;

    }

    /**
     * 特定書式(yyyy-MM-dd)の日付文字列であるかをバリテーションする。
     *
     * @param date 処理対象
     * @return バリテーション結果（チェックOK：true、チェックNG：false）
     */
    private static boolean checkDateFormat(String date) {
        if (StringUtils.isBlank(date)) {
            LOGGER.debug("inputDate is Null!");
            return false;
        }

        try {
            LocalDate.parse(date, DateUtils.DATETIME_FORMATTER_ISO8601);
        } catch (DateTimeParseException e) {
            LOGGER.debug("inputDate format invalidated! inputDate: {}", date);
            return false;
        }
        return true;
    }

}
