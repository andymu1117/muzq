package com.neobank.fcore.demanddeposit.transform;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

import com.neobank.fcore.demanddeposit.entity.AutoTransferEntity;
import com.neobank.fcore.demanddeposit.pb.command.message.AutoTransferDeployRequest;

@SuppressWarnings("serial")
public class AutoTransferDeployRequestConvertFn
    extends DoFn<KV<String, Iterable<AutoTransferEntity>>, List<AutoTransferDeployRequest>> {

    /**
     * 入力要素を出力要素に変換。
     *
     * @param element 自動振込ID
     * @param context 処理のコンテキスト
     */
    @ProcessElement
    public void processElement(@Element KV<String, Iterable<AutoTransferEntity>> element, ProcessContext context) {
        List<AutoTransferDeployRequest> autoTransferDeployRequest = StreamSupport.stream(element.getValue()
            .spliterator(), false)
            .sorted(Comparator.comparing(AutoTransferEntity::getCreationDate))
            .map(item -> AutoTransferDeployRequest.newBuilder()
                .setAutoTransferId(item.getAutoTransferId())
                .build())
            .collect(Collectors.toList());

        context.output(autoTransferDeployRequest);
    }

}
