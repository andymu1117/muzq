package com.neobank.fcore.demanddeposit.transform;

import java.util.List;
import java.util.stream.IntStream;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;

@SuppressWarnings("serial")
public class CustomerAdvantageConditionFlatFn extends DoFn<List<String>, KV<Integer, String>> {

    /**
     * 入力要素を出力要素に変換。
     * 
     * @param element 顧客優遇条件情報リスト
     * @param context 処理のコンテキスト
     */
    @ProcessElement
    public void processElement(@Element List<String> element, ProcessContext context) {
        // 確実に分散処理を発生させるため大量のデータを流す
        int modCnt = (int) Math.ceil(element.size() / (double) 1000);
        IntStream.range(0, element.size())
            .mapToObj(i -> KV.of(i % modCnt, element.get(i)))
            .forEach(context::output);
    }
}
