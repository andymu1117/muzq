package com.accenture.mainri.test.utils.spanner;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 
 * Spanner Driver Mocker保持する用Pool
 *
 */
public class SpannerMockerPool {
    private static ConcurrentHashMap<String, SpannerDriverMocker> spannerDriverMockerPool = new ConcurrentHashMap<>();

    /**
     * PoolにSpanner Driver Mockerを保存する。
     * 
     * @param key Spanner Driver Mockerに紐づくキー。Spanner Driver Mockerのインスタンス毎に唯一必要。
     * @param mocker Spanner Driver Mocker
     */
    public static void registerSpannerDriverMocker(String key, SpannerDriverMocker mocker) {
        spannerDriverMockerPool.putIfAbsent(key, mocker);
    }

    /**
     * PoolからSpanner Driver Mockerを取得する。
     * 
     * @param key key Spanner Driver Mockerに紐づくキー
     * @return Spanner Driver Mocker
     */
    public static SpannerDriverMocker getSpannerDriverMocker(String key) {
        return spannerDriverMockerPool.get(key);
    }
}
