package com.accenture.mainri.test.utils.grpc;

import java.io.IOException;

import io.grpc.BindableService;
import io.grpc.ManagedChannel;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import io.grpc.testing.GrpcCleanupRule;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

/**
 * <p>
 * Junitテスト用Grpc関連するテストルール
 * <p>
 * 
 * 下記のFunctionを提供している。<br/>
 * <li>Grpc Client用GrpcConnector</li>
 * <li>Grpc Service登録しIn-process サーバーを立ち上げる。</li>
 * <li>Junitテスト実行後にChannelとサーバーをCleanupする。</li>
 *
 */
public class GrpcTestRule implements TestRule {

    private GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();
    private String serverName;

    /**
     * GrpcTestRuleを作成する。
     */
    public GrpcTestRule() {
        this.serverName = InProcessServerBuilder.generateName();
        this.grpcCleanup = new GrpcCleanupRule();
    }

    /**
     * サーバー名を取得する、
     * 
     * @return サーバー名
     */
    public String getServerName() {
        return serverName;
    }

    /**
     * Junit用GrpcConnectorを作成する。
     * 
     * @return GrpcConnector
     */
    public FakeGrpcConnector newFakeGrpcConnector() {
        ManagedChannel channel = InProcessChannelBuilder.forName(serverName)
            .directExecutor()
            .build();
        return new FakeGrpcConnector(serverName, channel);
    }

    /**
     * Grpc サービスを登録しサーバーを立ち上げる。
     * 
     * @param bindableService Grpcサービス
     * @throws IOException異常の場合
     */
    public void addService(BindableService bindableService) throws IOException {
        grpcCleanup.register(InProcessServerBuilder.forName(serverName)
            .directExecutor()
            .addService(bindableService)
            .build()
            .start());
    }

    /**
     * Junitテスト実行後にChannelとサーバーをCleanupする。
     */
    @Override
    public Statement apply(Statement base, Description description) {
        return grpcCleanup.apply(base, description);
    }

}
