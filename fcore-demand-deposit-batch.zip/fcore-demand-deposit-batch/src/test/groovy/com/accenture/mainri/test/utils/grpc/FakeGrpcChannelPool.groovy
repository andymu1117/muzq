package com.accenture.mainri.test.utils.grpc;

import java.util.concurrent.ConcurrentHashMap;

import io.grpc.ManagedChannel;

/**
 * 
 * <p>
 * Junitテスト用Grpc Channel を保持する用Pool
 * </p>
 *
 */
public class FakeGrpcChannelPool {
    private static ConcurrentHashMap<String, ManagedChannel> channelPool = new ConcurrentHashMap<>();

    /**
     * PoolにGrpc Channel を保持する。
     * 
     * @param key Grpc Channelに紐づくキー。Grpc Channel のインスタンス毎に唯一必要。
     * @param channel Grpc Channel
     */
    public static void registerChannel(String key, ManagedChannel channel) {
        channelPool.putIfAbsent(key, channel);
    }

    /**
     * PoolからGrpc Channelを取得する。
     * 
     * @param key Grpc Channelに紐づくキー
     * @return Grpc Channel
     */
    public static ManagedChannel getChannel(String key) {
        return channelPool.get(key);
    }
}
