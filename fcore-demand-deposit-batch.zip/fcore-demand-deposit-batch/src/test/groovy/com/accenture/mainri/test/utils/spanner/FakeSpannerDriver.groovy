package com.accenture.mainri.test.utils.spanner;

import java.util.function.Consumer;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.TransactionContext;
import org.apache.beam.sdk.io.gcp.spanner.Transaction;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.CreateTransaction;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Read;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.ReadAll;
import org.apache.beam.sdk.values.PCollectionView;
import org.mockito.Mockito;

import com.accenture.mainri.core.io.SpannerDriver;
import com.accenture.mainri.core.pipeline.options.DefaultOptions;

/**
 * 
 * <p>
 * Junit テスト用Spanner Driver
 * </p>
 * {@code FakeSpannerDriver}を作成する際に、{@code SpannerDriverMocker}が事前に作成する必要。
 * {@code SpannerDriver}のメソッドの実行は、{@code SpannerDriverMocker}にdelegate したので、<br/>
 * Mockitoで{@code FakeSpannerDriver}をモックする可能。 例：
 * 
 * <pre>
 * // SpannerDriver Mockerを生成する。
 * SpannerDriverMocker mocker = Mockito.mock(SpannerDriverMocker.class);
 * // 意図的に、Spanner DriverのWriteが実行された際に、Exceptionがスローされる。
 * Mockito.doThrow(SpannerException.class)
 *     .when(mocker)
 *     .write(Mockito.any(), (DatabaseClient) Mockito.any());
 * 
 * // FakeSpannerDriverでWriterを作成する。
 * AccountTransactionMessageWriter writer =
 *     new AccountTransactionMessageWriter(new FakeSpannerDriver(mocker), successTag, errorTag);
 * </pre>
 */
@SuppressWarnings("serial")
public class FakeSpannerDriver extends SpannerDriver {

    private String uuid;
    private transient Spanner spanner;
    private transient DatabaseClient databaseClient;
    private transient SpannerDriverMocker delegate;

    /**
     * FakeSpannerDriverを作成する。
     * 
     * @param mocker MockitoでSpannerDriverMockerのMock
     */
    public FakeSpannerDriver(SpannerDriverMocker mocker) {
        super(Mockito.mock(DefaultOptions.class));
        this.spanner = Mockito.mock(Spanner.class);
        this.databaseClient = Mockito.mock(DatabaseClient.class);
        this.delegate = mocker;
        this.uuid = UUID.randomUUID()
                .toString();
        SpannerMockerPool.registerSpannerDriverMocker(uuid, delegate);
    }

    @Override
    public DatabaseClient createDatabaseClient(Spanner service) {
        return databaseClient;
    }

    private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException {
        inputStream.defaultReadObject();
        this.spanner = Mockito.mock(Spanner.class);
        this.databaseClient = Mockito.mock(DatabaseClient.class);
        this.delegate = SpannerMockerPool.getSpannerDriverMocker(uuid);
    }

    @Override
    public Spanner createService() {
        return spanner;
    }

    @Override
    public CreateTransaction createTransaction() {
        return delegate.createTransaction();
    }

    @Override
    public Read read(Statement statement, boolean isBatching) {
        return delegate.read(statement, isBatching);
    }

    @Override
    public Read read(Statement statement, PCollectionView<Transaction> tx, boolean isBatching) {
        return delegate.read(statement, tx, isBatching);
    }

    @Override
    public ReadAll readAll(boolean isBatching) {
        return delegate.readAll(isBatching);
    }

    @Override
    public void write(Iterable<Mutation> mutations, DatabaseClient dbClient) {
        delegate.write(mutations, dbClient);
    }

    @Override
    public void write(DatabaseClient dbClient, Consumer<TransactionContext> consumer) {
        delegate.write(dbClient, consumer);
    }

    @Override
    public void writeAtLeastOnce(Iterable<Mutation> mutations, DatabaseClient dbClient) {
        delegate.writeAtLeastOnce(mutations, dbClient);
    }
}
