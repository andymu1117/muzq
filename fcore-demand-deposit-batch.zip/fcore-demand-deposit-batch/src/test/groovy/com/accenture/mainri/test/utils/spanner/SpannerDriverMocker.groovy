package com.accenture.mainri.test.utils.spanner;

import java.util.function.Consumer;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.TransactionContext;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.Transaction;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Read;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.ReadAll;
import org.apache.beam.sdk.values.PCollectionView;

/**
 * 
 * <p>
 * Junit テスト用Spanner Driverのインターフェース
 * </p>
 *
 * {@code SpannerDriver}と一致する必要。
 */
trait SpannerDriverMocker {

    /**
     * コンフィグを元にトランザクションを生成します。
     *
     * @return 生成したトランザクション
     */
    SpannerIO.CreateTransaction createTransaction() {
        return null;
    }

    /**
     * SELECT Statementを実行するBeamの{@link org.apache.beam.sdk.transforms.PTransform}を生成します。
     *
     * @param statement SELECT Statement
     * @param isBatching 実行計画によってはBatch処理ができないため、このオプションで設定
     * @return Read用のPTransform
     */
    Read read(Statement statement, boolean isBatching) {
        return null;
    }

    /**
     * SELECT Statementを実行するBeamの{@link org.apache.beam.sdk.transforms.PTransform}をトランザクション付きで生成します。
     *
     * @param statement SELECT Statement
     * @param tx トランザクション
     * @param isBatching 実行計画によってはBatch処理ができないため、このオプションで設定
     * @return Read用のPTransform
     */
    Read read(Statement statement, PCollectionView<Transaction> tx, boolean isBatching) {
        return null;
    }

    /**
     * {@link ReadOperation}をインプットとしてSQLを実行する{@link PTramsform}を作成する。
     *
     * @param isBatching 実行計画によってはBatch処理ができないため、このオプションで設定
     * @return ReadAll
     */
    ReadAll readAll(boolean isBatching) {
        return null;
    }

    /**
     * Mutationに設定された書き込み処理を実施します。
     *
     * @param mutations 書き込み設定や値を保持したMutation
     * @param dbClient Connectionを使いまわすためのDatabaseClient
     */
    void write(Iterable<Mutation> mutations, DatabaseClient dbClient) {
    }

    /**
     * INSERT or UPDATE Statementを実行します。
     *
     * @param dbClient DatabaseClient
     * @param consumer トランザクション内の処理
     */
    void write(DatabaseClient dbClient, Consumer<TransactionContext> consumer) {
    }

    /**
     * 失敗時の再実行無しで引数のMutationを実行します。
     *
     * @param mutations 実行対象のMutationの繰り返し
     * @param dbClient DatabaseClient
     */
    void writeAtLeastOnce(Iterable<Mutation> mutations, DatabaseClient dbClient) {
    }
}
