package com.accenture.mainri.test.utils.grpc;

import io.grpc.ManagedChannel;

import com.accenture.mainri.core.io.GrpcConnector;

/**
 * 
 * <p>
 * Junitテスト用GrpcConnector
 * </p>
 *
 */
public class FakeGrpcConnector extends GrpcConnector {

    private final String serverName;
    private transient ManagedChannel channel;

    /**
     * FakeGrpcConnectorを作成する。
     * 
     * @param options Pipline Option
     * @param serverName Grpcサーバー名
     * @param channel Grpc Channel
     */
    protected FakeGrpcConnector(String serverName, ManagedChannel channel) {
        super("dummy", 50051, false);
        this.serverName = serverName;
        this.channel = channel;
        FakeGrpcChannelPool.registerChannel(serverName, channel);
    }

    private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException {
        inputStream.defaultReadObject();
        channel = FakeGrpcChannelPool.getChannel(serverName);
    }

    public ManagedChannel createManagedChannel() {
        return channel;
    }
}
