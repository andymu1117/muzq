package com.neobank.fcore.demanddeposit.transform


import java.nio.charset.StandardCharsets

import org.apache.beam.sdk.Pipeline.PipelineExecutionException
import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollectionTuple
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.exception.SystemFailureException
import com.neobank.fcore.demanddeposit.utils.Conversion

@Title("SettlementCollationByteColumnSeparatorFnテスト")
public class SettlementCollationByteColumnSeparatorFnSpec extends Specification implements Serializable {

    TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationByteColumnSeparatorFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        targetDate = StaticValueProvider.of(targetDateStr)
        function = new SettlementCollationByteColumnSeparatorFn(smallTodayDataTag, smallFutureDataTag, nextWorkDay, targetDate)
    }

    def "Transformが正常完了"() {
        given:
        List<String> list = new ArrayList()

        PCollectionTuple output = p
                .apply(Create.of(SettlementCollationData.getInput().getBytes()))
                .apply(ParDo.of(function)
                .withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag))
                .withSideInputs(nextWorkDay))

        List<SettlementCollationBase> resultsToday = new ArrayList<>();
        List<SettlementCollationBase> resultsFuture = new ArrayList<>();
        int index = 0;
        for(List<String> line : Conversion.separateBytesBySemicolonAndBreakLine(SettlementCollationData.getInput().getBytes(StandardCharsets.UTF_8))) {
            if(line.size() != 7) continue;
            switch(index) {
                case 0:
                case 3:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsToday.add(resultKv)
                    break;
                case 1:
                case 2:
                case 4:
                case 5:
                case 6:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsFuture.add(resultKv)
                    break;
            }
            index++;
        }

        def outputTodayData = output.get(smallTodayDataTag);
        def outputFutureData = output.get(smallFutureDataTag);

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。
        PAssert.that(outputTodayData)
                .containsInAnyOrder(resultsToday);
        PAssert.that(outputFutureData)
                .containsInAnyOrder(resultsFuture);

        expect:
        // Pipelineを実行する。
        p.run();
    }

    def "Transformが正常完了.ヘッダのみ"() {
        given:
        List<String> list = new ArrayList()

        PCollectionTuple output = p
                .apply(Create.of(SettlementCollationData.getNonDataRecord().getBytes()))
                .apply(ParDo.of(function)
                .withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag))
                .withSideInputs(nextWorkDay))

        expect:
        // Pipelineを実行する。
        p.run()
    }

    def "Transformが異常完了.列数異常"() {
        given:
        List<String> list = new ArrayList()

        PCollectionTuple output = p
                .apply(Create.of("".getBytes()))
                .apply(ParDo.of(function)
                .withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag))
                .withSideInputs(nextWorkDay))

        when:
        // Pipelineを実行する。
        p.run();

        then:
        PipelineExecutionException e = thrown(PipelineExecutionException)
        e.getCause() instanceof SystemFailureException
    }
}
