package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Combine
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.DoFn
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.DoFn.Element
import org.apache.beam.sdk.transforms.DoFn.OutputReceiver
import org.apache.beam.sdk.transforms.DoFn.ProcessElement
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

@Title("SettlementCollationFileOutputEmptyCheckFnテスト")
public class SettlementCollationFileOutputEmptyCheckFnSpec extends Specification implements Serializable {

    public static final String OUTPUT_TYPE_SUMMARY = "1";
    public static final String OUTPUT_TYPE_DETAIL = "2";
    public static final String OUTPUT_TYPE_RECONCILE = "3";

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationFileOutputEmptyCheckFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
    }

    @Unroll
    def "Transformが正常完了.#caseName"() {
        given:
        function = new SettlementCollationFileOutputEmptyCheckFn(outputType)

        List<String> list = new ArrayList()

        PCollection<String> inputPc
        if(indata.isEmpty()){
            // 完全にPcollectionが空の場合も空のファイルフォーマットが設定されることを確認する
            inputPc = p.apply(Create.of(""))
                    .apply("空データ生成",ParDo.of(new DoFn<String, String>() {
                        @ProcessElement
                        public void processElement(@Element String input, OutputReceiver<String> out) {
                        }
                    }))
        }else {
            inputPc = p.apply(Create.of(indata))
        }

        PCollection<String> output = inputPc.apply("set empty",Combine.globally(function));

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。
        PAssert.that(output)
                .containsInAnyOrder(resdata);

        expect:
        // Pipelineを実行する。
        p.run();

        where:
        caseName | indata | resdata | outputType
        "detail" | inDataDetail() |  resDataDetail() | OUTPUT_TYPE_DETAIL
        "detail.null" | inDataDetailNull() |  resDataDetailNull() | OUTPUT_TYPE_DETAIL
        "summary" | inDataSummary() |  resDataSummary() | OUTPUT_TYPE_SUMMARY
        "summary.null" | inDataSummaryNull() |  resDataSummaryNull() | OUTPUT_TYPE_SUMMARY
        "reconcile" | inDataSummary() |  resDataSummary() | OUTPUT_TYPE_RECONCILE
        "reconcile.null" | inDataReconcileNull() |  resDataReconcileNull() | OUTPUT_TYPE_RECONCILE
    }

    //    入力データ
    private List<String> inDataDetail(){
        String data = "{\"1\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"2\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"3\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"4\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}]}"
        List<String> datas = new ArrayList<>()
        datas.add(data)
        return datas
    }
    private List<String> inDataDetailNull(){
        List<String> datas = new ArrayList<>()
        return datas
    }
    private List<String> inDataSummary(){
        String data = "{\"1\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"2\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"3\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"4\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"5\":{\"amount\":500},\"6\":{\"amount\":500},\"7\":{\"amount\":500},\"8\":{\"amount\":500}}"
        List<String> datas = new ArrayList<>()
        datas.add(data)
        return datas
    }
    private List<String> inDataSummaryNull(){
        List<String> datas = new ArrayList<>()
        return datas
    }
    private List<String> inDataReconcileNull(){
        List<String> datas = new ArrayList<>()
        return datas
    }

    //    出力データ
    private String resDataDetail(){
        String res = "{\"1\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"2\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"3\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"4\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}]}"
        return res
    }
    private String resDataDetailNull(){
        String res = "{\"1\":[],\"2\":[],\"3\":[],\"4\":[]}"
        return res
    }
    private String resDataSummary(){
        String res = "{\"1\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"2\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"3\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"4\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"5\":{\"amount\":500},\"6\":{\"amount\":500},\"7\":{\"amount\":500},\"8\":{\"amount\":500}}"
        return res
    }
    private String resDataSummaryNull(){
        String res = "{\"1\":null,\"2\":null,\"3\":null,\"4\":null,\"5\":null,\"6\":null,\"7\":null,\"8\":null}"
        return res
    }
    private String resDataReconcileNull(){
        String res = "[]"
        return res
    }
}
