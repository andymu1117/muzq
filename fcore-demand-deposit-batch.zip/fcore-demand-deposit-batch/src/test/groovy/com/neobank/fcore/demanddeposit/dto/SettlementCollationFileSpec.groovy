package com.neobank.fcore.demanddeposit.dto

import java.text.SimpleDateFormat

import com.google.cloud.spanner.Struct
import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile

@Title("SettlementCollationFileテスト")
class SettlementCollationFileSpec extends Specification{

    def setupSpec() {
    }

    @Unroll
    def "SettlementCollationFile.Struct.#caseName"(){
        setup:
        Struct struct = Struct.newBuilder()
                .set("ZenginProcessCode").to(ZenginProcessCodeValue)
                .set("ManagementNumber").to(ManagementNumber)
                .set("CommunicationTypeCode").to(CommunicationTypeCode)
                .set("TransferDate").to(com.google.cloud.Date.fromJavaUtilDate(TransferDate))
                .set("TransactionAmount").to(TransactionAmount)
                .set("CoreMoreTimeType").to(CoreMoreTimeType)
                .set("LargeValueTransactionFlag").to(LargeValueTransactionFlagValue)
                .build();

        when:
        SettlementCollationFile entity = new SettlementCollationFile(struct);

        then:
        entity.getZenginProcessCode() == ZenginProcessCodeValue
        entity.getManagementNumber() == ManagementNumber
        entity.getCommunicationTypeCode() == CommunicationTypeCode
        entity.getTransferScheduledDate() == new SimpleDateFormat("yyyyMMdd").format(TransferDate)
        entity.getAmount() == TransactionAmount
        entity.getCoreMoreTimeType() == CoreMoreTimeType
        entity.getLargeValueTransactionFlag() == LargeValueTransactionFlagValue

        where:
        caseName | ZenginProcessCodeValue | ManagementNumber | CommunicationTypeCode | TransferDate | TransactionAmount | CoreMoreTimeType | LargeValueTransactionFlagValue
        "通常" | "1" | "2" | "3" | new Date() | 5 | "6" | "7"
    }

    @Unroll
    def "SettlementCollationFile.List.#caseName"(){
        given:
        List<String> line = new ArrayList<>();
        line.add(ZenginProcessCodeValue);
        line.add(ManagementNumber);
        line.add(CommunicationTypeCode);
        line.add(TransferDate);
        line.add(TransactionAmount);
        line.add(CoreMoreTimeType);
        line.add(LargeValueTransactionFlagValue);

        when:
        SettlementCollationFile entity = new SettlementCollationFile(line);

        then:
        entity.getZenginProcessCode() == ZenginProcessCodeValue
        entity.getManagementNumber() == ManagementNumber
        entity.getCommunicationTypeCode() == CommunicationTypeCode
        entity.getTransferScheduledDate() == TransferDate
        entity.getAmount() == Long.parseLong(TransactionAmount)
        entity.getCoreMoreTimeType() == CoreMoreTimeType
        entity.getLargeValueTransactionFlag() == LargeValueTransactionFlagValue

        where:
        caseName | ZenginProcessCodeValue | ManagementNumber | CommunicationTypeCode | TransferDate | TransactionAmount | CoreMoreTimeType | LargeValueTransactionFlagValue
        "通常" | "1" | "2" | "3" | "20190101" | "5" | "6" | "7"
    }
}
