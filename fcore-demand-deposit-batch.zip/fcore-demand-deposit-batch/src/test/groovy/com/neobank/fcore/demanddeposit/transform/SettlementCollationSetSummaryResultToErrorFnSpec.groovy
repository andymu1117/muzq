package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.coders.KvCoder
import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerSummaryFile

@Title("SettlementCollationSetSummaryResultToErrorFnテスト")
public class SettlementCollationSetSummaryResultToErrorFnSpec extends Specification implements Serializable {


    public static final String OUTPUT_TYPE_SUMMARY = "1";
    public static final String OUTPUT_TYPE_DETAIL = "2";
    public static final String OUTPUT_TYPE_SettlementCollation = "3";

    // ファイル読み込み用
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

    // ファイルデータ振り分け用
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<Integer> summaryErrorNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileOutboundNotTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundNotTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};



    // 判定結果の出力を分ける為のタグ
    TupleTag<Integer> errorNumTag = new TupleTag<Integer>() {};

    TupleTag<SettlementCollationBase> fileTag = new TupleTag<SettlementCollationBase>() {
    };
    TupleTag<SettlementCollationBase> dbTag = new TupleTag<SettlementCollationBase>() {
    };
    TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>> settlementCollationOfficerDetailFileTag =
    new TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>>() {
    };

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay

    private String getInput() {
        return  "1;2;1022;20190101;5;6;0\n"+
                "1;2;1022;20190102;5;6;0\n"+
                "1;2;1022;20190103;5;6;0\n"+
                "1;2;1275;20190102;5;6;0\n"+
                "1;2;1275;20190103;5;6;0\n"+
                "1;2;1275;20190104;5;6;0\n"+
                "1;2;1275;20190104;5;6;0\n"+
                "1;2;1275;20190105;5;6;1\n"
    }

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationSetSummaryResultToErrorFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)
    }

    @Unroll
    def "Transformが正常終了.#caseName"() {
        given: "Pipeline実行&Ouput確認"


        PCollectionView<Integer> errorNum = p
                .apply("2",Create.of(errNum))
                .apply("3",View.asSingleton())

        function = new SettlementCollationSetSummaryResultToErrorFn(errorNum)

        PCollection<KV<List<String>, SettlementCollationBase>> output =
                p.apply("4",Create.of(indata).withCoder(KvCoder.of(SerializableCoder.of(List.class), SerializableCoder.of(SettlementCollationBase.class))))
                .apply(ParDo.of(function).withSideInputs(errorNum))

        expect:
        // Pipelineを実行する。
        p.run();

        where:
        caseName    | indata   | errNum | resdata
        "エラー数0"    | inData() | 0      | inData()
        "エラー数1"    | inData() | 1      | resData()
    }

    private KV<List<String>, SettlementCollationBase> inData() {
        SettlementCollationOfficerSummaryFile data = new SettlementCollationOfficerSummaryFile()
        List<String> keys = new ArrayList<>()
        return KV.of(keys, data)
    }
    private KV<List<String>, SettlementCollationBase> resData() {
        SettlementCollationOfficerSummaryFile data = inData().getValue()
        data.setErrorFlag("1")
        List<String> keys = inData().getKey()
        return KV.of(keys, data)
    }
}
