package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.coders.KvCoder
import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionView
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile

@Title("SettlementCollationFileToBaseConvertFnテスト")
public class SettlementCollationFileToBaseConvertFnSpec extends Specification implements Serializable {

    List<String> beforeSettlementList =  SettlementCollationData.getBeforeSettlementList();

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationFileToBaseConvertFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        function = new SettlementCollationFileToBaseConvertFn()
    }

    def "Transformが正常完了"() {
        given:

        SettlementCollationFile inputData1 = new SettlementCollationFile()
        inputData1.zenginProcessCode = "1"
        inputData1.managementNumber = "2"
        inputData1.communicationTypeCode = "1275"
        inputData1.transferScheduledDate = "20190102"
        inputData1.amount = 5
        inputData1.coreMoreTimeType = "6"
        inputData1.largeValueTransactionFlag = "0"
        List<String> keys1 = new ArrayList<>();
        keys1.add(inputData1.managementNumber);
        KV<List<String>, SettlementCollationFile> input1 = KV.of(keys1,inputData1);
        KV<List<String>, SettlementCollationBase> expect1 = KV.of(keys1,inputData1);

        // ↓こちらは前営業日レコードではないのでフィルタされる
        SettlementCollationFile inputData2 = new SettlementCollationFile()
        inputData2.zenginProcessCode = "1"
        inputData2.managementNumber = "2"
        inputData2.communicationTypeCode = "1022"
        inputData2.transferScheduledDate = "20190102"
        inputData2.amount = 5
        inputData2.coreMoreTimeType = "6"
        inputData2.largeValueTransactionFlag = "0"
        List<String> keys2 = new ArrayList<>();
        keys2.add(inputData2.managementNumber);
        KV<List<String>, SettlementCollationFile> input2 = KV.of(keys1,inputData1);
        KV<List<String>, SettlementCollationBase> expect2 = KV.of(keys1,inputData1);

        PCollection<KV<List<String>, SettlementCollationFile>> output = p
                .apply(Create.of([input1, input2]))
                .setCoder(KvCoder.of(SerializableCoder.of(List.class), SerializableCoder.of(SettlementCollationFile.class)))
                .apply(ParDo.of(function));

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。

        PAssert.that(output)
                .containsInAnyOrder([expect1, expect2]);

        expect:
        // Pipelineを実行する。
        p.run();
    }
}
