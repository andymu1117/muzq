package com.neobank.fcore.demanddeposit.transform

import java.time.LocalDate;

import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity

class InterestAccountFilterFnData {

    static final def inputInterestAccountFilterWithLocalDateOfInterestDateEntity =
    [
        // 0.処理対象である「口座.オファリングIDなし、基本商品BS情報.利息有無フラグは有」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:null,
        interestFlag:"1",
        salesStartDate:LocalDate.of(2019, 11, 11),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"1",
        offeringsInterestFlag:"1",
        offeringsOfferingId:"d1a62527-9308-4a93-bee4-660faaf55d94",
        interestDate:"20191104",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 4)
        ),
        // 1.処理対象でない「口座.オファリングIDなし、基本商品BS情報.利息有無フラグは無」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:null,
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 01, 01),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"d1a62527-9308-4a93-bee4-660faaf55d94",
        interestDate:"20191004",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 10, 4)
        ),
        // 2.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDなし」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 01, 01),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"0",
        offeringsOfferingId:null,
        interestDate:"20191004",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 10, 4)
        ),
        // 3.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、利息基準日 < 販売開始日」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191004",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 10, 4)
        ),
        // 4.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、利息基準日 > 販売終了日」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191112",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 12)
        ),
        // 5.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは有」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"1",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191006",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 10, 6)
        ),
        // 6.処理対象でない「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは無」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191110",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 10)
        ),
        // 7.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照する、基本商品BS情報.利息有無フラグは有」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"1",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"1",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191110",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 10)
        ),
        // 8.処理対象でない「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 = 販売終了日、オファリング.基本商品参照フラグ参照する、基本商品BS情報.利息有無フラグは無」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"0",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"1",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191111",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 11)
        ),
        // 9.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 = 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは有」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"1",
        salesStartDate:LocalDate.of(2019, 10, 05),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"1",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191005",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 10, 5)
        ),
        // 10.処理対象でない「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 = 利息基準日 = 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは無」
        new InterestAccountFilterWithLocalDateOfInterestDateEntity(
        accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
        offeringId:"c5ef88ef-8554-4fe9-94f5-cbf6dc26d111",
        interestFlag:"1",
        salesStartDate:LocalDate.of(2019, 11, 11),
        salesEndDate:LocalDate.of(2019, 11, 11),
        itemReferenceFlag:"0",
        offeringsInterestFlag:"0",
        offeringsOfferingId:"fee6a3b0-e88d-4cb5-a0e5-61f172be6bfc",
        interestDate:"20191111",
        interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 11)
        )
    ]
}
