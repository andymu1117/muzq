package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.coders.KvCoder
import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.accenture.mainri.core.entity.DataClassBase

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerSummaryFile

@Title("SettlementCollationStringifyForOfficerFnテスト")
public class SettlementCollationStringifyForOfficerFnSpec extends Specification implements Serializable {

    public static final String OUTPUT_TYPE_SUMMARY = "1";
    public static final String OUTPUT_TYPE_DETAIL = "2";
    public static final String OUTPUT_TYPE_SettlementCollation = "3";

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationStringifyForOfficerFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
    }

    @Unroll
    def "Transformが正常終了.#caseName"() {
        given: "Pipeline実行&Ouput確認"
        function = new SettlementCollationStringifyForOfficerFn(outputType)
        PCollection<KV<List<String>, Map<String, List<DataClassBase>>>> input =
                p.apply(Create.of(indata).withCoder(KvCoder.of(SerializableCoder.of(List.class), SerializableCoder.of(Iterable.class))))
        PCollection<String> output = input.apply(ParDo.of(function))

        PAssert.that(output)
                .containsInAnyOrder(resdata);

        expect:
        p.run()

        where:
        caseName | indata | resdata | outputType
        "detail" | inDataDetail() |  resDataDetail() | OUTPUT_TYPE_DETAIL
        "detail.null" | inDataDetailNull() |  resDataDetailNull() | OUTPUT_TYPE_DETAIL
        "summary" | inDataSummary() |  resDataSummary() | OUTPUT_TYPE_SUMMARY
        "summary.null" | inDataSummaryNull() |  resDataSummaryNull() | OUTPUT_TYPE_SUMMARY
    }

    //    入力データ
    private List<KV<List<String>, Map<String, List<DataClassBase>>>> inDataDetail(){
        def data = new SettlementCollationOfficerDetailFile();
        data.zenginAmount=null;
        data.zenginManageNo=null;
        data.accountAmount=5;
        data.accountManageNo=null;
        data.differentAmount=-5;
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()
        resDatalist.add(data)

        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode(), resDatalist);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<Map<String, List<DataClassBase>>> resultMapList = new ArrayList<>()
        resultMapList.add(resultMap)

        List<KV<List<String>, Map<String, List<DataClassBase>>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable)resultMapList))
        return reslist
    }
    private List<KV<List<String>, Map<String, List<DataClassBase>>>> inDataDetailNull(){
        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode(), null);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<Map<String, List<DataClassBase>>> resultMapList = new ArrayList<>()
        resultMapList.add(resultMap)

        List<KV<List<String>, Map<String, List<DataClassBase>>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable)resultMapList))
        return reslist
    }
    private List<KV<List<String>, Map<String, List<DataClassBase>>>> inDataSummary(){
        def data = new SettlementCollationOfficerSummaryFile();
        data.number = 1;
        data.amount = 500;
        data.errorFlag = "1";
        List<SettlementCollationOfficerSummaryFile> resDatalist = new ArrayList<>()
        resDatalist.add(data)

        def basedata = new SettlementCollationBase();
        basedata.amount = 500;
        List<SettlementCollationBase> resBasedatalist = new ArrayList<>()
        resBasedatalist.add(basedata)

        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode(), resDatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND.getCode(), resBasedatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode(), resBasedatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_IN.getCode(), resBasedatalist);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_OUT.getCode(), resBasedatalist);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<Map<String, List<DataClassBase>>> resultMapList = new ArrayList<>()
        resultMapList.add(resultMap)

        List<KV<List<String>, Map<String, List<DataClassBase>>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable)resultMapList))
        return reslist
    }
    private List<KV<List<String>, Map<String, List<DataClassBase>>>> inDataSummaryNull(){
        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_NOT_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND_NOT_TRANSFER.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_IN.getCode(), null);
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_LARGE_OUT.getCode(), null);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<Map<String, List<DataClassBase>>> resultMapList = new ArrayList<>()
        resultMapList.add(resultMap)

        List<KV<List<String>, Map<String, List<DataClassBase>>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable)resultMapList))
        return reslist
    }
    //    出力データ
    private String resDataDetail(){
        String res = "{\"1\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"2\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"3\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}],\"4\":[{\"zenginAmount\":null,\"zenginManageNo\":null,\"accountAmount\":5,\"accountManageNo\":null,\"differentAmount\":-5}]}"
        return res
    }
    private String resDataDetailNull(){
        String res = "{\"1\":[],\"2\":[],\"3\":[],\"4\":[]}"
        return res
    }
    //    出力データ
    private String resDataSummary(){
        String res = "{\"1\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"2\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"3\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"4\":{\"number\":1,\"errorFlag\":\"1\",\"amount\":500},\"5\":{\"amount\":500},\"6\":{\"amount\":500},\"7\":{\"amount\":500},\"8\":{\"amount\":500}}"
        return res
    }
    //    出力データ
    private String resDataSummaryNull(){
        String res = "{\"1\":null,\"2\":null,\"3\":null,\"4\":null,\"5\":null,\"6\":null,\"7\":null,\"8\":null}"
        return res
    }
}
