package com.neobank.fcore.demanddeposit.dto

import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

@Title("SettlementCollationOfficerDetailFileテスト")
class SettlementCollationOfficerDetailFileSpec extends Specification{

    def setupSpec() {
    }

    @Unroll
    def "SettlementCollationOfficerDetailFile.Struct.#caseName"(){
        setup:
        SettlementCollationFile file = new SettlementCollationFile()
        SettlementCollationDb db = new SettlementCollationDb()

        file.amount      =   amountFile
        file.zenginProcessCode       =   zenginProcessCodeFile
        file.managementNumber        =   managementNumberFile
        file.communicationTypeCode       =   communicationTypeCodeFile
        file.settlementDate      =   settlementDateFile
        file.transferScheduledDate       =   transferScheduledDateFile
        file.coreMoreTimeType        =   coreMoreTimeTypeFile
        file.largeValueTransactionFlag       =   largeValueTransactionFlagFile

        db.amount      =   amountDb
        db.transactionSlipId       =   transactionSlipIdDb
        db.managementNumber        =   managementNumberDb

        when:
        SettlementCollationOfficerDetailFile entity = new SettlementCollationOfficerDetailFile(file,db);

        then:
        entity.zenginAmount == file.getAmount();
        entity.zenginManageNo == file.getManagementNumber();
        entity.accountAmount == db.getAmount();
        entity.accountManageNo == db.getManagementNumber();
        entity.differentAmount == (Objects.isNull(amountFile) ? 0 : amountFile) - (Objects.isNull(amountDb) ? 0 : amountDb);

        where:
        caseName    |   amountFile  |   zenginProcessCodeFile   |   managementNumberFile    |   communicationTypeCodeFile   |   settlementDateFile  |   transferScheduledDateFile   |   coreMoreTimeTypeFile    |   largeValueTransactionFlagFile   |   amountDb    |   transactionSlipIdDb |   managementNumberDb
        "通常"  |   1   |   "2" |   "3" |   "4" |   "5" |   "6" |   "7" |   "8" |   9   |   "10"    |  "12"
        "DBレコードなし"  |   1   |   "2" |   "3" |   "4" |   "5" |   "6" |   "7" |   "8" |   null   |   null    |   null
        "ファイルレコードなし"  |   null   |   null |   null |   null |   null |   null |   null |   null |   9   |   "10"    |   "12"
    }
}
