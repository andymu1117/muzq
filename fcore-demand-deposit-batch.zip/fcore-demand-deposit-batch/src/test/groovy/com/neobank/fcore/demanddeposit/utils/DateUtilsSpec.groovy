package com.neobank.fcore.demanddeposit.utils

import static org.junit.Assert.assertEquals

import java.time.LocalDate
import java.time.format.DateTimeParseException

import spock.lang.Specification
import spock.lang.Unroll

class DateUtilsSpec extends Specification{

    def "parseIso8601ToLocalDate: 正常に実行する"() {

        when: "DateUtils実行"
        def realResult = DateUtils.parseIso8601ToLocalDate(input)

        then: "実行成功確認"
        assertEquals(result, realResult)

        where:

        input                        | result
        "2019-10-20"          | new LocalDate(2019, 10, 20)
    }

    def "parseIso8601ToLocalDate: 異常なパラメータを入力"() {

        when: "DateUtils実行"
        DateUtils.parseIso8601ToLocalDate(input)

        then: "実行異常確認"
        thrown(error)


        where:

        input                      |  error
        "2019-10-20123"   |  DateTimeParseException
        null                       |  NullPointerException
    }

    def "parseIso8601WithoutHyphenToLocalDate : 正常に実行する"() {

        when: "DateUtils実行"
        def realResult =  DateUtils.parseIso8601WithoutHyphenToLocalDate(input)

        then: "実行成功確認"
        realResult == result

        where:

        input              | result
        "20191020"         | new LocalDate(2019, 10, 20)
    }

    def "parseIso8601WithoutHyphenToLocalDate: 異常なパラメータを入力"() {

        when: "DateUtils実行"
        DateUtils.parseIso8601WithoutHyphenToLocalDate(input)

        then: "実行異常確認"
        thrown(error)

        where:

        input               |  error
        null                |  NullPointerException
    }

    def "formatLocalDateToIso8601WithoutHyphen : 正常に実行する"() {

        when: "DateUtils実行"
        def realResult =  DateUtils.formatLocalDateToIso8601WithoutHyphen(input)

        then: "実行成功確認"
        assertEquals(result, realResult)

        where:

        input                                           | result
        new LocalDate(2019, 10, 20)         | "20191020"
    }

    def "formatLocalDateToIso8601WithoutHyphen: 異常なパラメータを入力"() {

        when: "DateUtils実行"
        DateUtils.formatLocalDateToIso8601WithoutHyphen(input)

        then: "実行異常確認"
        thrown(error)

        where:

        input                      |  error
        null                       |  NullPointerException
    }

    def "formatLocalDateToIso8601 正常に実行する"() {

        when: "DateUtils実行"
        def realResult = DateUtils.formatLocalDateToIso8601(input)

        then: "実行成功確認"
        assertEquals(result, realResult)

        where:

        input                                           | result
        new LocalDate(2019, 10, 20)         | "2019-10-20"
    }

    def "formatLocalDateToIso8601 : 異常なパラメータを入力"() {

        when: "DateUtils実行"
        DateUtils.formatLocalDateToIso8601(input)

        then: "実行異常確認"
        thrown(error)

        where:

        input                      |  error
        null                       |  NullPointerException
    }

    def "formatLocalDateToTodayMinTime : 正常に実行する"() {

        when: "DateUtils実行"
        def realResult = DateUtils.formatLocalDateToTodayMinTime(input)

        then: "実行成功確認"
        realResult == result

        where:

        input                        |  result
        new LocalDate(2019, 10, 20)  |  "2019-10-20T00:00:00+09:00"
    }

    def "formatLocalDateToTodayMinTime : 異常なパラメータを入力"() {

        when: "DateUtils実行"
        DateUtils.formatLocalDateToTodayMinTime(input)

        then: "実行異常確認"
        thrown(error)

        where:

        input                      |  error
        null                       |  NullPointerException
    }

    def "formatLocalDateToTodayMaxTime : 正常に実行する"() {

        when: "DateUtils実行"
        def realResult = DateUtils.formatLocalDateToTodayMaxTime(input)

        then: "実行成功確認"
        realResult == result

        where:

        input                        |  result
        new LocalDate(2019, 10, 20)  |  "2019-10-20T23:59:59.999999999+09:00"
    }

    def "formatLocalDateToTodayMaxTime : 異常なパラメータを入力"() {

        when: "DateUtils実行"
        DateUtils.formatLocalDateToTodayMaxTime(input)

        then: "実行異常確認"
        thrown(error)

        where:

        input                      |  error
        null                       |  NullPointerException
    }

    @Unroll
    def "特定書式(yyyy-MM-dd)の日付文字列であるかをバリテーションする(#caseName)"() {

        when: "バリテーション実行"
        def checkResult = DateUtils.checkDateFormat(inputDate)

        then: "実行成功確認"
        checkResult == expectResult

        where:"テストデーター準備"

        caseName                                             | inputDate    | expectResult
        "チェックNG：対象日付がNULLの場合"                   | null         | false
        "チェックNG：対象日付のフォーマットが不正である場合" | "2019-11aa"  | false
        "チェックOK：対象日付のフォーマットが正しい場合"     | "2019-11-23" | true
    }

    @Unroll
    def "処理対象日付が未来日ではないかをバリテーションする(#caseName)"() {

        when: "バリテーション実行"
        def checkResult = DateUtils.checkDateIsNotFutureDay(inputDate)

        then: "実行成功確認"
        checkResult == expectResult

        where:"テストデーター準備"

        caseName                                             | inputDate    | expectResult
        "チェックOK：対象日付がNULLの場合"                   | null         | false
        "チェックOK：対象日付のフォーマットが不正である場合" | "2019-11aa"  | false
        "チェックOK：対象日付が未来日でない場合"             | "2019-11-21" | true
        "チェックNG：対象日付が未来日である場合"             | "2099-11-23" | false
    }

    def "DateUtils対象新規異常"() {

        when: "DateUtils対象新規"
        DateUtils util = new DateUtils()

        then: "実行異常確認"
        thrown(IllegalStateException)
    }
}
