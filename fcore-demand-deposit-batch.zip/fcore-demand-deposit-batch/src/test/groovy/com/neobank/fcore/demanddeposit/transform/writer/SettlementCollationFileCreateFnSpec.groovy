package com.neobank.fcore.demanddeposit.transform.writer

import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationFileCreateFnテスト")
class SettlementCollationFileCreateFnSpec  extends Specification implements Serializable {
    // ファイル操作を行うため、パイプラインを実行させて確認する。
}


