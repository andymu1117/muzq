package com.neobank.fcore.demanddeposit.dto

import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationTransferScheduledDateテスト")
class SettlementCollationTransferScheduledDateSpec extends Specification{
    //必要なテスト無し
}
