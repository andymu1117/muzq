package com.neobank.fcore.demanddeposit.dto

import com.google.cloud.spanner.Struct
import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

@Title("SettlementCollationDbテスト")
class SettlementCollationDbSpec extends Specification{

    def setupSpec() {
    }

    @Unroll
    def "SettlementCollationDb.#caseName"(){
        setup:
        Struct struct = Struct.newBuilder()
                .set("TransactionSlipId").to(TransactionSlipId)
                .set("TransactionAmount").to(TransactionAmount)
                .set("ManagementNo").to(ManagementNumber)
                .build();

        when:
        SettlementCollationDb entity = new SettlementCollationDb(struct);

        then:
        entity.getTransactionSlipId() == TransactionSlipId
        entity.getAmount() == TransactionAmount
        entity.getManagementNumber() == ManagementNumber

        where:
        caseName | TransactionSlipId | TransactionAmount | ZenginProcessCodeValue | ManagementNumber
        "通常" | "1" | 2L | "3" | "4"
        "空文字" | "" | 0L | "" | ""
    }
}
