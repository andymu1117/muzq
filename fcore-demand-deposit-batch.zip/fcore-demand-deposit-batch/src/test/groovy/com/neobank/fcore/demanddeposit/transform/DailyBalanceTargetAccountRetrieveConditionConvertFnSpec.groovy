package com.neobank.fcore.demanddeposit.transform

import org.apache.beam.sdk.Pipeline.PipelineExecutionException
import org.apache.beam.sdk.coders.StringUtf8Coder
import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.dto.DailyBalanceTargetAccountRetrieveConditionDto

@Title('日次残高確定対象口座抽出条件転換Fnのテストケース ')
class DailyBalanceTargetAccountRetrieveConditionConvertFnSpec extends Specification implements Serializable {

    @Shared
    ValueProvider<String> notIso8601DateFormatDay = StaticValueProvider.of("2020-1-11")
    @Shared
    ValueProvider<String> futureDay = StaticValueProvider.of("2099-11-11")
    @Shared
    ValueProvider<String> iso8601DateFormatDay = StaticValueProvider.of("2020-02-11")
    @Shared
    def outputEntity = new DailyBalanceTargetAccountRetrieveConditionDto("20200210","2020-02-10T23:59:59.999999999+09:00")

    @Rule transient TestPipeline p = TestPipeline.create()

    @Unroll
    def "日付転換処理が異常が発生する場合(#caseName)"() {

        when: "Pipeline実行"
        PCollection<DailyBalanceTargetAccountRetrieveConditionDto> output = p.apply("Read parameters", Create.ofProvider(targetDate, StringUtf8Coder.of()))
                .apply("Convert options", ParDo.of(new DailyBalanceTargetAccountRetrieveConditionConvertFn()));
        // Pipelineを実行する。
        p.run();

        then: "IllegalArgumentExceptionが発生"
        def expectedException = thrown(PipelineExecutionException)
        expectedException.getMessage() == "java.lang.IllegalArgumentException: element processDate is illegal argument!"

        where:"テストデータ準備"

        caseName                                                          | targetDate
        "1.入力されたデータのフォーマットはISO8601でないので、異常が発生" | notIso8601DateFormatDay
        "2.入力されたデータは未来日なので、異常が発生"                    | futureDay
    }

    def "日付転換処理が正常に完了する場合"() {

        expect: "Pipeline実行"
        PCollection<DailyBalanceTargetAccountRetrieveConditionDto> output = p.apply("Read parameters", Create.ofProvider(iso8601DateFormatDay, StringUtf8Coder.of()))
                .apply("Convert options", ParDo.of(new DailyBalanceTargetAccountRetrieveConditionConvertFn()));
        // Outputが予想であるかチェックする。
        PAssert.that(output).containsInAnyOrder(outputEntity);
        // Pipelineを実行する。
        p.run();
    }
}
