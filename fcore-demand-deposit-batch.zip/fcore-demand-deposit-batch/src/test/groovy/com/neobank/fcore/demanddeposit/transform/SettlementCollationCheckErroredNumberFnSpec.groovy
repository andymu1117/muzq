package com.neobank.fcore.demanddeposit.transform


import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationCheckErroredNumberFnテスト")
public class SettlementCollationCheckErroredNumberFnSpec extends Specification implements Serializable {
    //ログ出力のみの機能であるため、実行の中で動作を確認する
}
