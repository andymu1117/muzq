package com.neobank.fcore.demanddeposit.transform

import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationSelectPendingFnテスト")
public class SettlementCollationSelectSettlementSummaryFnSpec extends Specification implements Serializable {
    //    DB系はモック化困難なので、Spockではテスト実施しない
}
