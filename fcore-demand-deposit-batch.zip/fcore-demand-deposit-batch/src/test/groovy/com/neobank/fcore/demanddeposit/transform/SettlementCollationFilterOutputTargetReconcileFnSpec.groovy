package com.neobank.fcore.demanddeposit.transform


import java.nio.charset.StandardCharsets

import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationTransferScheduledDate
import com.neobank.fcore.demanddeposit.utils.Conversion

@Title("SettlementCollationFilterOutputTargetReconcileFnテスト")
public class SettlementCollationFilterOutputTargetReconcileFnSpec extends Specification implements Serializable {

    TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationFilterOutputTargetReconcileFn function = new SettlementCollationFilterOutputTargetReconcileFn()

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        targetDate = StaticValueProvider.of(targetDateStr)
    }

    def "Transformが正常完了"() {
        given:

        PCollection<KV<List<String>, SettlementCollationBase>> inputs = p
                .apply(Create.of(SettlementCollationData.getAllCommunicationInput().getBytes()))
                .apply(ParDo.of(new SettlementCollationByteColumnSeparatorFn(smallTodayDataTag, smallFutureDataTag, nextWorkDay, targetDate)).withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag)).withSideInputs(nextWorkDay))
                .get(smallTodayDataTag)
        // 上述のパイプラインはテスト済みとして実行
        ;

        List<SettlementCollationBase> resultsToday = new ArrayList<>();
        List<SettlementCollationBase> resultsFuture = new ArrayList<>();

        int index = 0;
        for(List<String> line : Conversion.separateBytesBySemicolonAndBreakLine(SettlementCollationData.getAllCommunicationInput().getBytes(StandardCharsets.UTF_8))) {
            if(line.size() != 7) continue;

            def result = new SettlementCollationFile();
            result.zenginProcessCode = line.get(0);
            result.managementNumber = line.get(1);
            result.communicationTypeCode = line.get(2);
            result.transferScheduledDate = line.get(3);
            result.amount = Long.valueOf(line.get(4));
            result.coreMoreTimeType = line.get(5);
            result.largeValueTransactionFlag = line.get(6);

            SettlementCollationTransferScheduledDate output = new SettlementCollationTransferScheduledDate();
            output.setZenginProcessCode(result.getZenginProcessCode());
            output.setManagementNumber(result.getManagementNumber());
            output.setAmount(result.getAmount());

            def key = new ArrayList<>()
            key.add("output")
            def resultKv = KV.of(key, (SettlementCollationBase)output)
            if(CommunicationTypeCode.isBeforeSettlementTarget(line.get(2))) resultsToday.add(resultKv)
            index++;
        }

        def output = inputs
                .apply(ParDo.of(function));

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。
        PAssert.that(output)
                .containsInAnyOrder(resultsToday);

        expect:
        // Pipelineを実行する。
        p.run();
    }
}
