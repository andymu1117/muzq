package com.neobank.fcore.demanddeposit.utils

import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.exception.BusinessFailureException


@Title("ValidationUtilsテスト")
class ValidationUtilsSpec extends Specification {

    @Unroll
    def "checkParamDateメソッド.異常.#caseName"() {
        when:
        ValidationUtils.checkParamDate(targetDate);

        then:
        thrown(exception)

        where:
        caseName | targetDate | exception
        "異常(null)" | null | BusinessFailureException
        "異常(空文字)" | "" | BusinessFailureException
        "異常(半角スペース)" | " " | BusinessFailureException
        "異常(あり得ない日付)" | "20190229" | BusinessFailureException
        "異常(桁数多い)" | "202002299" | BusinessFailureException
        "異常(桁数少ない)" | "2020021" | BusinessFailureException
    }
}
