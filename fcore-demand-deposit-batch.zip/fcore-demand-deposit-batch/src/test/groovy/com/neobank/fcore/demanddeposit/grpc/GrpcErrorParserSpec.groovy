package com.neobank.fcore.demanddeposit.grpc

import com.google.protobuf.Any
import io.grpc.Metadata
import io.grpc.Status
import io.grpc.StatusRuntimeException
import io.grpc.protobuf.StatusProto
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class GrpcErrorParserSpec extends Specification{


    @Shared
    def StatusRuntimeException mockUnavailableSystemError = mockUnavailableSystemError()
    @Shared
    def StatusRuntimeException mockValidationError = mockValidationError()
    @Shared
    def StatusRuntimeException mockDetailIsNullSystemError = mockDetailIsNullSystemError()
    @Shared
    def StatusRuntimeException mockResponseIsNullSystemError = mockResponseIsNullSystemError()
    @Shared
    def StatusRuntimeException mockOtherSystemError = mockOtherSystemError()
    @Shared
    def StatusRuntimeException mockIllegalArgumentError = mockIllegalArgumentError()



    def "GrpcErrorParser対象新規異常"() {

        when: "GrpcErrorParser対象新規"
        GrpcErrorParser util = new GrpcErrorParser()

        then: "実行異常確認"
        thrown(IllegalStateException)
    }

    @Unroll
    def "caseName:(#caseName)"() {

        when: "GrpcErrorParser実行"
        def realResult = GrpcErrorParser.parseErrorResponse(input)

        then: "異常確認"
        thrown(error)

        where:

        caseName                                                    | input                                         | error
        "gRPCからのエラーがバリデーションエラー場合"      | mockValidationError                    | GrpcValidationException
        "grpcサービスは接続できない場合"                    | mockUnavailableSystemError        | GrpcSystemException
        "gRPCからのエラー詳細が空の場合'"                 | mockDetailIsNullSystemError        | GrpcSystemException
        "エラーレスポンスではない場合"                         | mockResponseIsNullSystemError  | GrpcSystemException
        "バリデーションエラー以外のエラー場合"               | mockOtherSystemError               | GrpcSystemException
        "入力エラーがNULL場合"                                | null                                           | NullPointerException
        "違法引数エラーがある場合"                            | mockIllegalArgumentError             | GrpcSystemException
    }

    def StatusRuntimeException mockValidationError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.INVALID_ARGUMENT.getCode().value())
                .addDetails(new Any().DEFAULT_INSTANCE.toBuilder().setTypeUrl("xxx.ErrorResponse").build())
                .setMessage("INVALID_ARGUMENT")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.INVALID_ARGUMENT, trailers)
    }

    def StatusRuntimeException mockDetailIsNullSystemError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.INVALID_ARGUMENT.getCode().value())
                .setMessage("INVALID_ARGUMENT")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.INVALID_ARGUMENT, trailers)
    }

    def StatusRuntimeException mockResponseIsNullSystemError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.INVALID_ARGUMENT.getCode().value())
                .addDetails(new Any().DEFAULT_INSTANCE.toBuilder().build())
                .setMessage("INVALID_ARGUMENT")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.INVALID_ARGUMENT, trailers)
    }

    def StatusRuntimeException mockOtherSystemError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.PERMISSION_DENIED.getCode().value())
                .addDetails(new Any().DEFAULT_INSTANCE.toBuilder().setTypeUrl("xxx.ErrorResponse").build())
                .setMessage("PERMISSION_DENIED")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.PERMISSION_DENIED, trailers)
    }

    def StatusRuntimeException mockIllegalArgumentError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.PERMISSION_DENIED.getCode().value())
                .addDetails(new Any().DEFAULT_INSTANCE.toBuilder().setTypeUrl("xxx.ErrorResponse").build())
                .setMessage("PERMISSION_DENIED")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.UNAUTHENTICATED, trailers)
    }

    def StatusRuntimeException mockUnavailableSystemError() {
        return new StatusRuntimeException(Status.UNAVAILABLE)
    }
}
