package com.neobank.fcore.demanddeposit.entity

import java.time.OffsetDateTime

import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.accenture.mainri.core.date.DateTimeUtils

import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.utils.DateUtils

@Title("SettlementCollationPendingテスト")
class SettlementCollationPendingSpec extends Specification{

    def setupSpec() {
    }

    @Unroll
    def "SettlementCollationFile.Struct.#caseName"(){
        setup:
        String databaseUserName = "username"
        SettlementCollationFile file = new SettlementCollationFile()
        DateTimeUtils dateTimeUtils = Mock(DateTimeUtils);
        OffsetDateTime now = OffsetDateTime.now()
        dateTimeUtils.now() >> now

        file.amount      =   amountFile
        file.zenginProcessCode       =   zenginProcessCodeFile
        file.managementNumber        =   managementNumberFile
        file.communicationTypeCode       =   communicationTypeCodeFile
        file.settlementDate      =   settlementDateFile
        file.transferScheduledDate       =   transferScheduledDateFile
        file.coreMoreTimeType        =   coreMoreTimeTypeFile
        file.largeValueTransactionFlag       =   largeValueTransactionFlagFile

        when:
        SettlementCollationPending entity = new SettlementCollationPending(databaseUserName, file,
                dateTimeUtils);

        then:
        entity.getZenginProcessCode() == zenginProcessCodeFile
        entity.getManagementNumber() == managementNumberFile
        entity.getCommunicationTypeCode() == communicationTypeCodeFile
        entity.getTransferDate() == DateUtils.parseIso8601WithoutHyphenToLocalDate(transferScheduledDateFile);
        entity.getTransactionAmount() == amountFile
        entity.getCoreMoreTimeType() == coreMoreTimeTypeFile
        entity.getLargeValueTransactionFlag() == largeValueTransactionFlagFile
        entity.getPublishedDate() == now

        where:
        caseName    |   amountFile  |   zenginProcessCodeFile   |   managementNumberFile    |   communicationTypeCodeFile   |   settlementDateFile  |   transferScheduledDateFile   |   coreMoreTimeTypeFile    |   largeValueTransactionFlagFile
        "通常"  |   1   |   "2" |   "3" |   "4" |   "5" |   "20190101" |   "7" |   "8"
    }
}
