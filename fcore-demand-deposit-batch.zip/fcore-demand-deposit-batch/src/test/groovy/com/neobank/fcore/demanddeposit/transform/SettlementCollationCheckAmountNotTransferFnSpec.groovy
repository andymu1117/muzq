package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.DoFn
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.Sum
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.transforms.DoFn.Element
import org.apache.beam.sdk.transforms.DoFn.OutputReceiver
import org.apache.beam.sdk.transforms.DoFn.ProcessElement
import org.apache.beam.sdk.transforms.join.CoGroupByKey
import org.apache.beam.sdk.transforms.join.KeyedPCollectionTuple
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionTuple
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationDb
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile

@Title("SettlementCollationCheckAmountNotTransferFnテスト")
public class SettlementCollationCheckAmountNotTransferFnSpec extends Specification implements Serializable {


    public static final String OUTPUT_TYPE_SUMMARY = "1";
    public static final String OUTPUT_TYPE_DETAIL = "2";
    public static final String OUTPUT_TYPE_SettlementCollation = "3";

    // ファイル読み込み用
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

    // ファイルデータ振り分け用
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<Integer> fileOutboundTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileOutboundNotTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundNotTransferBeforeSettlementNumTag = new TupleTag<Integer>() {};



    // 判定結果の出力を分ける為のタグ
    TupleTag<Integer> errorNumTag = new TupleTag<Integer>() {};

    TupleTag<SettlementCollationBase> fileTag = new TupleTag<SettlementCollationBase>() {
    };
    TupleTag<SettlementCollationBase> dbTag = new TupleTag<SettlementCollationBase>() {
    };
    TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>> settlementCollationOfficerDetailFileTag =
    new TupleTag<KV<List<String>, SettlementCollationOfficerDetailFile>>() {
    };

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay

    private String getInput() {
        return  "1;2;1022;20190101;5;6;0\n"+
                "1;2;1022;20190102;5;6;0\n"+
                "1;2;1022;20190103;5;6;0\n"+
                "1;2;1275;20190102;5;6;0\n"+
                "1;2;1275;20190103;5;6;0\n"+
                "1;2;1275;20190104;5;6;0\n"+
                "1;2;1275;20190104;5;6;0\n"+
                "1;2;1275;20190105;5;6;1\n"
    }

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationCheckAmountNotTransferFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)
    }

    @Unroll
    def "Transformが正常終了.#caseName"() {
        given: "Pipeline実行&Ouput確認"
        List<KV<List<String>, SettlementCollationBase>> inputlist = fileKVList
        // Transformにリクエストを適用
        PCollection<KV<List<String>, SettlementCollationFile>> inputfile = p
                .apply("ファイルデータ作成",Create.of(""))
                .apply("ファイルデータ生成",ParDo.of(new DoFn<String, KV<List<String>, SettlementCollationBase>>() {
                    @ProcessElement
                    public void processElement(@Element String input, OutputReceiver<KV<List<String>, SettlementCollationBase>> out) {
                        for(KV<List<String>, SettlementCollationBase> item : inputlist) {
                            out.output(item)
                        }
                    }
                }))
        PCollection<KV<List<String>, SettlementCollationBase>> inputdb = p
                .apply("DBデータ作成",Create.of(""))
                .apply("DBデータ生成",ParDo.of(new DoFn<String, KV<List<String>, SettlementCollationBase>>() {
                    @ProcessElement
                    public void processElement(@Element String input, OutputReceiver<KV<List<String>, SettlementCollationBase>> out) {
                        List<String> keys = new ArrayList<>()
                        keys.add("")
                        SettlementCollationDb val = new SettlementCollationDb()
                        val.amount = 5
                        out.output(KV.of(keys, val))
                    }
                }))

        TupleTag<SettlementCollationBase> fileTag = new TupleTag<SettlementCollationBase>() {};
        TupleTag<SettlementCollationBase> dbTag = new TupleTag<SettlementCollationBase>() {};

        function = new SettlementCollationCheckAmountNotTransferFn(fileTag, dbTag, errorNumTag,
                settlementCollationOfficerDetailFileTag,
                SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER)

        def inputGroup =
                KeyedPCollectionTuple.of(fileTag, inputfile)
                .and(dbTag, inputdb)
                .apply(CoGroupByKey.create());

        // Output PCollectionを取得する。
        PCollectionTuple output = inputGroup.apply(ParDo.of(function)
                .withOutputTags(errorNumTag, TupleTagList.of(settlementCollationOfficerDetailFileTag)))
        PCollection<Integer> outputNum = output
                .get(errorNumTag)
                .apply(Sum.integersGlobally());

        def resultData = resData
        PCollection<KV<List<String>, SettlementCollationOfficerDetailFile>> outputData = output
                .get(settlementCollationOfficerDetailFileTag);

        PAssert.that(outputNum)
                .containsInAnyOrder(resErrorNum);
        if(resData.isEmpty()) {
            PAssert.that(outputData).empty()
        } else {
            PAssert.that(outputData)
                    .containsInAnyOrder(resultData);
        }

        expect:
        // Pipelineを実行する。
        p.run();

        where:
        caseName         | fileKVList          | resErrorNum | resData
        "一致"            | getOKRecord()       | 0           | resDataOK()
        "不一致(ファイル>DB)" | getLackRecord()    | 1            | resDataLack()
        "不一致(ファイル<DB)" | getSurplusRecord() | 1            | resDataSurplus()
        "不一致(金額値)"    | getDiffRecord()    | 1            | resDataDiff()
    }

    //    入力データ
    private List<KV<List<String>, SettlementCollationBase>> getOKRecord() {
        List<String> keys = new ArrayList<>()
        keys.add("")
        SettlementCollationFile val = new SettlementCollationFile()
        val.amount = 5
        List<KV<List<String>, SettlementCollationBase>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, val))
        return reslist
    }

    private List<KV<List<String>, SettlementCollationBase>> getLackRecord() {
        List<KV<List<String>, SettlementCollationBase>> reslist = new ArrayList<>()
        return reslist
    }

    private List<KV<List<String>, SettlementCollationBase>> getSurplusRecord() {
        List<String> keys = new ArrayList<>()
        keys.add("")
        SettlementCollationFile val = new SettlementCollationFile()
        val.amount = 5
        List<KV<List<String>, SettlementCollationBase>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, val))
        reslist.add(KV.of(keys, val))
        return reslist
    }

    private List<KV<List<String>, SettlementCollationBase>> getDiffRecord() {
        List<String> keys = new ArrayList<>()
        keys.add("")
        SettlementCollationFile val = new SettlementCollationFile()
        val.amount = 2
        List<KV<List<String>, SettlementCollationBase>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, val))
        return reslist
    }

    //    結果データ
    private List<KV<List<String>, SettlementCollationOfficerDetailFile>> resDataOK(){
        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        return reslist

    }
    private List<KV<List<String>, SettlementCollationOfficerDetailFile>> resDataLack(){
        def resultData = new SettlementCollationOfficerDetailFile();
        resultData.zenginAmount=null;
        resultData.zenginManageNo=null;
        resultData.accountAmount=5;
        resultData.accountManageNo=null;
        resultData.differentAmount=-5;
        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultData))
        return reslist
    }
    private List<KV<List<String>, SettlementCollationOfficerDetailFile>> resDataSurplus(){
        def resultData = new SettlementCollationOfficerDetailFile();
        resultData.zenginAmount=5;
        resultData.zenginManageNo=null;
        resultData.accountAmount=null;
        resultData.accountManageNo=null;
        resultData.differentAmount=5;
        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultData))
        return reslist
    }
    private List<KV<List<String>, SettlementCollationOfficerDetailFile>> resDataDiff(){
        def resultData = new SettlementCollationOfficerDetailFile();
        resultData.zenginAmount=2;
        resultData.zenginManageNo=null;
        resultData.accountAmount=5;
        resultData.accountManageNo=null;
        resultData.differentAmount=-3;
        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultData))
        return reslist
    }
}
