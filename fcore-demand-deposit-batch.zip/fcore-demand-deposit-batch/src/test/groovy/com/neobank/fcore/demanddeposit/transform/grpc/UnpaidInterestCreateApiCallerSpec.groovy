package com.neobank.fcore.demanddeposit.transform.grpc

import java.time.LocalDate

import com.google.protobuf.Any
import io.grpc.Metadata
import io.grpc.Status
import io.grpc.StatusRuntimeException
import io.grpc.protobuf.StatusProto
import io.grpc.stub.StreamObserver
import org.apache.beam.sdk.options.PipelineOptions
import org.apache.beam.sdk.options.PipelineOptionsFactory
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionTuple
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.accenture.mainri.test.utils.grpc.GrpcTestRule

import com.neobank.fcore.demanddeposit.dto.ErrorLogEntryDto
import com.neobank.fcore.demanddeposit.dto.UnpaidInterestCreateResponseDto
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity
import com.neobank.fcore.demanddeposit.pb.command.AccountInterestCommandGrpc.AccountInterestCommandImplBase
import com.neobank.fcore.demanddeposit.pb.command.message.AccountInterestCreateRequest
import com.neobank.fcore.demanddeposit.pb.command.message.AccountInterestCreateResponse
import com.neobank.fcore.demanddeposit.pipeline.options.UnpaidInterestCreateOptions
@Title('Unpaid Interest Create API Caller Transform テストケース ')
class UnpaidInterestCreateApiCallerSpec extends Specification implements Serializable {
    // Grpc関連テストルール
    @Rule
    def final transient GrpcTestRule grpcRule = new GrpcTestRule();
    // テスト用Pipeline options
    @Shared
    def PipelineOptions options = {
        def op = PipelineOptionsFactory.as(UnpaidInterestCreateOptions.class)
        op.setProcessDate(new StaticValueProvider<String>("2019-10-21"))
        return op
    }()
    // テスト用Pipeline
    @Rule
    def transient TestPipeline p = TestPipeline.fromOptions(options);
    def TupleTag<UnpaidInterestCreateResponseDto> successTag = new TupleTag<UnpaidInterestCreateResponseDto>() {};
    def TupleTag<ErrorLogEntryDto> errorTag = new TupleTag<ErrorLogEntryDto>() {};
    def TupleTag<ErrorLogEntryDto> warnTag = new TupleTag<ErrorLogEntryDto>() {};
    @Subject
    def UnpaidInterestCreateApiCaller apiCaller = new UnpaidInterestCreateApiCaller(grpcRule.newFakeGrpcConnector(), successTag, errorTag, warnTag);

    static final def accountDeterminationEntity = new InterestAccountFilterWithLocalDateOfInterestDateEntity(
    accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
    offeringId:"4864939d-e9b9-468f-b64f-9c5366c323bb",
    interestFlag:"1",
    salesStartDate:LocalDate.now(),
    salesEndDate:LocalDate.now(),
    itemReferenceFlag:"1",
    offeringsInterestFlag:"1",
    offeringsOfferingId:"d1a62527-9308-4a93-bee4-660faaf55d94",
    interestDate:"20191104"
    )

    static final def RuntimeException mockValidationError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.INVALID_ARGUMENT.getCode().value())
                .addDetails(new Any().DEFAULT_INSTANCE.toBuilder().setTypeUrl("xxx.ErrorResponse").build())
                .setMessage("INVALID_ARGUMENT")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.INVALID_ARGUMENT, trailers)
    }

    static final def mockSystemError = new RuntimeException("error response from gRPC is empty.");
    static final def newSystemErrorLogEntryDto = new ErrorLogEntryDto(accountDeterminationEntity,mockSystemError)
    static final def newValidationErrorLogEntryDto = new ErrorLogEntryDto(accountDeterminationEntity,mockValidationError())

    def "預金API（利息計算）を呼び出すTransformが正常完了"() {
        given: "Grpc サービス準備"
        grpcRule.addService(new AccountInterestCommandImplBase() {
                    @Override
                    public void createAccountInterest(AccountInterestCreateRequest request, StreamObserver<AccountInterestCreateResponse> responseObserver) {
                        responseObserver.onNext(AccountInterestCreateResponse.getDefaultInstance());
                        responseObserver.onCompleted();
                    }
                });
        expect: "Pipeline実行&Ouput確認"
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> input = p.apply(Create.of(account));
        // Output PCollectionを取得する。
        PCollectionTuple output = input.apply(ParDo.of(apiCaller)
                .withOutputTags(successTag, TupleTagList.of(errorTag).and(warnTag)));
        // Outputが予想であるかチェックする。
        PAssert.that(output.get(successTag))
                .containsInAnyOrder(result);
        // Pipelineを実行する。
        p.run();
        where:  "テストデーター準備"
        account = accountDeterminationEntity;
        result = new UnpaidInterestCreateResponseDto(AccountInterestCreateResponse.getDefaultInstance());


    }

    def "預金API（利息計算）を呼び出すTransformが業務異常発生"() {
        given: "Grpc サービス準備"
        grpcRule.addService(new AccountInterestCommandImplBase() {
                    @Override
                    public void createAccountInterest(AccountInterestCreateRequest request, StreamObserver<AccountInterestCreateResponse> responseObserver) {
                        responseObserver.onNext(AccountInterestCreateResponse.getDefaultInstance());
                        responseObserver.onError(mockValidationError());
                    }
                });
        expect: "Pipeline実行&Ouput確認"
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> input = p.apply(Create.of(account));
        // Output PCollectionを取得する。
        PCollectionTuple output = input.apply(ParDo.of(apiCaller)
                .withOutputTags(successTag, TupleTagList.of(errorTag).and(warnTag)));
        // Outputが予想であるかチェックする。
        PAssert.that(output.get(warnTag))
                .containsInAnyOrder(errorLogEntry);
        // Pipelineを実行する。
        p.run();
        where:  "テストデーター準備"
        account = accountDeterminationEntity;
        errorLogEntry << newValidationErrorLogEntryDto
    }

    def "預金API（利息計算）を呼び出すTransformがシステム異常発生"() {
        given: "Grpc サービス準備"
        grpcRule.addService(new AccountInterestCommandImplBase() {
                    @Override
                    public void createAccountInterest(AccountInterestCreateRequest request, StreamObserver<AccountInterestCreateResponse> responseObserver) {
                        responseObserver.onNext(AccountInterestCreateResponse.getDefaultInstance());
                        responseObserver.onError(mockSystemError);
                    }
                });
        expect: "Pipeline実行&Ouput確認"
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> input = p.apply(Create.of(account));
        // Output PCollectionを取得する。
        PCollectionTuple output = input.apply(ParDo.of(apiCaller)
                .withOutputTags(successTag, TupleTagList.of(errorTag).and(warnTag)));
        // Outputが予想であるかチェックする。
        PAssert.that(output.get(errorTag))
                .containsInAnyOrder(errorLogEntry);
        // Pipelineを実行する。
        p.run();
        where:  "テストデーター準備"
        account << accountDeterminationEntity;
        errorLogEntry << newSystemErrorLogEntryDto;
    }

}
