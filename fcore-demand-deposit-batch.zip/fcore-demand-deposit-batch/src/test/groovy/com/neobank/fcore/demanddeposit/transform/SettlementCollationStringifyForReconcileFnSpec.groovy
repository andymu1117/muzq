package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.coders.KvCoder
import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationTransferScheduledDate

@Title("SettlementCollationStringifyForReconcileFnテスト")
public class SettlementCollationStringifyForReconcileFnSpec extends Specification implements Serializable {

    public static final String OUTPUT_TYPE_SUMMARY = "1";
    public static final String OUTPUT_TYPE_DETAIL = "2";
    public static final String OUTPUT_TYPE_SettlementCollation = "3";

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationStringifyForReconcileFn function = new SettlementCollationStringifyForReconcileFn()

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
    }

    @Unroll
    def "Transformが正常終了.#caseName"() {
        given: "Pipeline実行&Ouput確認"
        PCollection<KV<List<String>, Iterable<SettlementCollationBase>>> input =
                p.apply(Create.of(inData()).withCoder(KvCoder.of(SerializableCoder.of(List.class), SerializableCoder.of(Iterable.class))))
        PCollection<String> output = input.apply(ParDo.of(function))

        PAssert.that(output)
                .containsInAnyOrder(resData());

        expect:
        p.run()
    }

    //    入力データ
    private List<KV<List<String>, Iterable<SettlementCollationBase>>> inData(){
        def data = new SettlementCollationTransferScheduledDate();
        data.amount = 0;
        data.managementNumber = null;
        data.zenginProcessCode = null;
        List<SettlementCollationTransferScheduledDate> resDatalist = new ArrayList<>()
        resDatalist.add(data)

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<KV<List<String>, Iterable<SettlementCollationBase>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable)resDatalist))
        return reslist
    }
    //    出力データ
    private String resData(){
        String res = "[{\"zenginProcessCode\":null,\"managementNumber\":null,\"amount\":0}]"
        return res
    }
}
