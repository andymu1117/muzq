package com.neobank.fcore.demanddeposit.dto

import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.accenture.mainri.core.entity.BaseEntity

import com.neobank.fcore.demanddeposit.entity.SettlementCollationPending

@Title("SettlementCollationBaseテスト")
class SettlementCollationBaseSpec extends Specification{

    def setupSpec() {
    }

    @Unroll
    def "equalsメソッド:#caseName"(){
        expect:
        target.equals(compare) == result

        where:
        caseName | target | compare | result
        "一致.SettlementCollationBase" | new SettlementCollationBase() | new SettlementCollationBase() | true
        "一致.SettlementCollationDb" | new SettlementCollationDb() | new SettlementCollationDb() | true
        "一致.SettlementCollationFile" | new SettlementCollationFile() | new SettlementCollationFile() | true
        "一致.SettlementCollationOfficerDetailFile" | new SettlementCollationOfficerDetailFile() | new SettlementCollationOfficerDetailFile() | true
        "一致.SettlementCollationOfficerSummaryFile" | new SettlementCollationOfficerSummaryFile() | new SettlementCollationOfficerSummaryFile() | true
        "一致.SettlementCollationPending" | new SettlementCollationPending() | new SettlementCollationPending() | true
        "一致.SettlementCollationTransferScheduledDate" | new SettlementCollationTransferScheduledDate() | new SettlementCollationTransferScheduledDate() | true
        "不一致.型不正.空" | new SettlementCollationBase() | new BaseEntity() | false
        "不一致.型違い.空" | new SettlementCollationDb() | new SettlementCollationFile() | false
        "不一致.親子型.空" | new SettlementCollationBase() | new SettlementCollationFile() | false
    }
}
