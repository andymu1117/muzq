package com.neobank.fcore.demanddeposit.transform


import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.accenture.mainri.core.entity.DataClassBase

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationDb
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile
import com.neobank.fcore.demanddeposit.transform.SettlementCollationMergeForOfficerDetailFnSpec.SettlementCollationImportLog

@Title("SettlementCollationCheckAmountTransferFnテスト")
public class SettlementCollationMergeForOfficerDetailFnSpec extends Specification implements Serializable {

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationMergeForOfficerDetailFn function = new SettlementCollationMergeForOfficerDetailFn()

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
    }

    def "Transformが正常終了.#caseName"() {
        given: "Pipeline実行&Ouput確認"
        PCollection<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> input = p.apply(Create.of(inData()))
        PCollection<KV<List<String>, Map<String, List<DataClassBase>>>> output = input.apply(ParDo.of(function))

        PAssert.that(output)
                .containsInAnyOrder(resData());

        expect:
        p.run()
    }

    private List<KV<List<String>, Map<String, List<DataClassBase>>>> resData(){
        def data = new SettlementCollationOfficerDetailFile();
        data.zenginAmount=null;
        data.zenginManageNo=1;
        data.accountAmount=5;
        data.accountManageNo=1;
        data.differentAmount=-5;
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()
        resDatalist.add(data)

        def data1 = new SettlementCollationOfficerDetailFile();
        data1.zenginAmount=null;
        data1.zenginManageNo=2;
        data1.accountAmount=5;
        data1.accountManageNo=1;
        data1.differentAmount=-5;
        resDatalist.add(data1)

        def data5 = new SettlementCollationOfficerDetailFile();
        data5.zenginAmount=null;
        data5.zenginManageNo=3;
        data5.accountAmount=5;
        data5.accountManageNo=1;
        data5.differentAmount=-5;
        resDatalist.add(data5)

        def data3 = new SettlementCollationOfficerDetailFile();
        data3.zenginAmount=null;
        data3.zenginManageNo=1;
        data3.accountAmount=5;
        data3.accountManageNo=2;
        data3.differentAmount=-5;
        resDatalist.add(data3)

        def data2 = new SettlementCollationOfficerDetailFile();
        data2.zenginAmount=null;
        data2.zenginManageNo=2;
        data2.accountAmount=5;
        data2.accountManageNo=2;
        data2.differentAmount=-5;
        resDatalist.add(data2)

        def data4 = new SettlementCollationOfficerDetailFile();
        data4.zenginAmount=null;
        data4.zenginManageNo=3;
        data4.accountAmount=5;
        data4.accountManageNo=3;
        data4.differentAmount=-5;
        resDatalist.add(data4)

        def data0 = new SettlementCollationOfficerDetailFile();
        data0.zenginAmount=null;
        data0.zenginManageNo=null;
        data0.accountAmount=null;
        data0.accountManageNo=null;
        data0.differentAmount=null;
        resDatalist.add(data0)

        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), resDatalist);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultMap))
        return reslist
    }

    private List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> inData(){
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()

        def data0 = new SettlementCollationOfficerDetailFile();
        data0.zenginAmount=null;
        data0.zenginManageNo=null;
        data0.accountAmount=null;
        data0.accountManageNo=null;
        data0.differentAmount=null;
        resDatalist.add(data0)

        def data = new SettlementCollationOfficerDetailFile();
        data.zenginAmount=null;
        data.zenginManageNo=1;
        data.accountAmount=5;
        data.accountManageNo=1;
        data.differentAmount=-5;
        resDatalist.add(data)

        def data1 = new SettlementCollationOfficerDetailFile();
        data1.zenginAmount=null;
        data1.zenginManageNo=2;
        data1.accountAmount=5;
        data1.accountManageNo=1;
        data1.differentAmount=-5;
        resDatalist.add(data1)

        def data2 = new SettlementCollationOfficerDetailFile();
        data2.zenginAmount=null;
        data2.zenginManageNo=2;
        data2.accountAmount=5;
        data2.accountManageNo=2;
        data2.differentAmount=-5;
        resDatalist.add(data2)

        def data3 = new SettlementCollationOfficerDetailFile();
        data3.zenginAmount=null;
        data3.zenginManageNo=1;
        data3.accountAmount=5;
        data3.accountManageNo=2;
        data3.differentAmount=-5;
        resDatalist.add(data3)

        def data4 = new SettlementCollationOfficerDetailFile();
        data4.zenginAmount=null;
        data4.zenginManageNo=3;
        data4.accountAmount=5;
        data4.accountManageNo=3;
        data4.differentAmount=-5;
        resDatalist.add(data4)

        def data5 = new SettlementCollationOfficerDetailFile();
        data5.zenginAmount=null;
        data5.zenginManageNo=3;
        data5.accountAmount=5;
        data5.accountManageNo=1;
        data5.differentAmount=-5;
        resDatalist.add(data5)

        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable<SettlementCollationOfficerDetailFile>)resDatalist))
        return reslist
    }

    @Unroll
    def "Transformが正常終了.32件以上#caseName"() {
        given: "Pipeline実行&Ouput確認"
        List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> inputData = inData
        Collections.shuffle(inputData)
        PCollection<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> input = p.apply(Create.of(inputData))
        PCollection<KV<List<String>, Map<String, List<DataClassBase>>>> output = input.apply(ParDo.of(function))

        PAssert.that(output)
                .containsInAnyOrder(resData);

        expect:
        p.run()

        where:
        caseName | inData | resData
        "large shuffle1" | inDataLarge() |  resDataLarge()
        "large shuffle2" | inDataLarge() |  resDataLarge()
        "largeDuplecate shuffle1" | inDataLargeDuplecate() |  resDataLargeDuplecate()
        "largeDuplecate shuffle2" | inDataLargeDuplecate() |  resDataLargeDuplecate()
    }

    private List<KV<List<String>, Map<String, List<DataClassBase>>>> resDataLarge(){
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()

        def data1 = new SettlementCollationOfficerDetailFile();
        data1.zenginAmount=null;
        data1.zenginManageNo="01";
        data1.accountAmount=5;
        data1.accountManageNo="01";
        data1.differentAmount=-5;
        resDatalist.add(data1)

        def data2 = new SettlementCollationOfficerDetailFile();
        data2.zenginAmount=null;
        data2.zenginManageNo="02";
        data2.accountAmount=5;
        data2.accountManageNo="01";
        data2.differentAmount=-5;
        resDatalist.add(data2)

        def data3 = new SettlementCollationOfficerDetailFile();
        data3.zenginAmount=null;
        data3.zenginManageNo="03";
        data3.accountAmount=5;
        data3.accountManageNo="01";
        data3.differentAmount=-5;
        resDatalist.add(data3)

        def data4 = new SettlementCollationOfficerDetailFile();
        data4.zenginAmount=null;
        data4.zenginManageNo="04";
        data4.accountAmount=5;
        data4.accountManageNo="01";
        data4.differentAmount=-5;
        resDatalist.add(data4)

        def data5 = new SettlementCollationOfficerDetailFile();
        data5.zenginAmount=null;
        data5.zenginManageNo="05";
        data5.accountAmount=5;
        data5.accountManageNo="01";
        data5.differentAmount=-5;
        resDatalist.add(data5)

        def data6 = new SettlementCollationOfficerDetailFile();
        data6.zenginAmount=null;
        data6.zenginManageNo="06";
        data6.accountAmount=5;
        data6.accountManageNo="01";
        data6.differentAmount=-5;
        resDatalist.add(data6)

        def data7 = new SettlementCollationOfficerDetailFile();
        data7.zenginAmount=null;
        data7.zenginManageNo="07";
        data7.accountAmount=5;
        data7.accountManageNo="01";
        data7.differentAmount=-5;
        resDatalist.add(data7)

        def data8 = new SettlementCollationOfficerDetailFile();
        data8.zenginAmount=null;
        data8.zenginManageNo="08";
        data8.accountAmount=5;
        data8.accountManageNo="01";
        data8.differentAmount=-5;
        resDatalist.add(data8)

        def data9 = new SettlementCollationOfficerDetailFile();
        data9.zenginAmount=null;
        data9.zenginManageNo="09";
        data9.accountAmount=5;
        data9.accountManageNo="01";
        data9.differentAmount=-5;
        resDatalist.add(data9)

        def data10 = new SettlementCollationOfficerDetailFile();
        data10.zenginAmount=null;
        data10.zenginManageNo="10";
        data10.accountAmount=5;
        data10.accountManageNo="01";
        data10.differentAmount=-5;
        resDatalist.add(data10)

        def data11 = new SettlementCollationOfficerDetailFile();
        data11.zenginAmount=null;
        data11.zenginManageNo="11";
        data11.accountAmount=5;
        data11.accountManageNo="01";
        data11.differentAmount=-5;
        resDatalist.add(data11)

        def data12 = new SettlementCollationOfficerDetailFile();
        data12.zenginAmount=null;
        data12.zenginManageNo="12";
        data12.accountAmount=5;
        data12.accountManageNo="01";
        data12.differentAmount=-5;
        resDatalist.add(data12)

        def data13 = new SettlementCollationOfficerDetailFile();
        data13.zenginAmount=null;
        data13.zenginManageNo="13";
        data13.accountAmount=5;
        data13.accountManageNo="01";
        data13.differentAmount=-5;
        resDatalist.add(data13)

        def data14 = new SettlementCollationOfficerDetailFile();
        data14.zenginAmount=null;
        data14.zenginManageNo="14";
        data14.accountAmount=5;
        data14.accountManageNo="01";
        data14.differentAmount=-5;
        resDatalist.add(data14)

        def data15 = new SettlementCollationOfficerDetailFile();
        data15.zenginAmount=null;
        data15.zenginManageNo="14";
        data15.accountAmount=5;
        data15.accountManageNo="01";
        data15.differentAmount=-5;
        resDatalist.add(data15)

        def data16 = new SettlementCollationOfficerDetailFile();
        data16.zenginAmount=null;
        data16.zenginManageNo=null;
        data16.accountAmount=5;
        data16.accountManageNo="01";
        data16.differentAmount=-5;
        resDatalist.add(data16)



        def data17 = new SettlementCollationOfficerDetailFile();
        data17.zenginAmount=null;
        data17.zenginManageNo="01";
        data17.accountAmount=5;
        data17.accountManageNo="02";
        data17.differentAmount=-5;
        resDatalist.add(data17)

        def data18 = new SettlementCollationOfficerDetailFile();
        data18.zenginAmount=null;
        data18.zenginManageNo="02";
        data18.accountAmount=5;
        data18.accountManageNo="02";
        data18.differentAmount=-5;
        resDatalist.add(data18)

        def data19 = new SettlementCollationOfficerDetailFile();
        data19.zenginAmount=null;
        data19.zenginManageNo="03";
        data19.accountAmount=5;
        data19.accountManageNo="02";
        data19.differentAmount=-5;
        resDatalist.add(data19)

        def data20 = new SettlementCollationOfficerDetailFile();
        data20.zenginAmount=null;
        data20.zenginManageNo="04";
        data20.accountAmount=5;
        data20.accountManageNo="02";
        data20.differentAmount=-5;
        resDatalist.add(data20)

        def data21 = new SettlementCollationOfficerDetailFile();
        data21.zenginAmount=null;
        data21.zenginManageNo="05";
        data21.accountAmount=5;
        data21.accountManageNo="02";
        data21.differentAmount=-5;
        resDatalist.add(data21)

        def data22 = new SettlementCollationOfficerDetailFile();
        data22.zenginAmount=null;
        data22.zenginManageNo="06";
        data22.accountAmount=5;
        data22.accountManageNo="02";
        data22.differentAmount=-5;
        resDatalist.add(data22)

        def data23 = new SettlementCollationOfficerDetailFile();
        data23.zenginAmount=null;
        data23.zenginManageNo="07";
        data23.accountAmount=5;
        data23.accountManageNo="02";
        data23.differentAmount=-5;
        resDatalist.add(data23)

        def data24 = new SettlementCollationOfficerDetailFile();
        data24.zenginAmount=null;
        data24.zenginManageNo="08";
        data24.accountAmount=5;
        data24.accountManageNo="02";
        data24.differentAmount=-5;
        resDatalist.add(data24)

        def data25 = new SettlementCollationOfficerDetailFile();
        data25.zenginAmount=null;
        data25.zenginManageNo="09";
        data25.accountAmount=5;
        data25.accountManageNo="02";
        data25.differentAmount=-5;
        resDatalist.add(data25)

        def data26 = new SettlementCollationOfficerDetailFile();
        data26.zenginAmount=null;
        data26.zenginManageNo="10";
        data26.accountAmount=5;
        data26.accountManageNo="02";
        data26.differentAmount=-5;
        resDatalist.add(data26)

        def data27 = new SettlementCollationOfficerDetailFile();
        data27.zenginAmount=null;
        data27.zenginManageNo="11";
        data27.accountAmount=5;
        data27.accountManageNo="02";
        data27.differentAmount=-5;
        resDatalist.add(data27)

        def data28 = new SettlementCollationOfficerDetailFile();
        data28.zenginAmount=null;
        data28.zenginManageNo="12";
        data28.accountAmount=5;
        data28.accountManageNo="02";
        data28.differentAmount=-5;
        resDatalist.add(data28)

        def data29 = new SettlementCollationOfficerDetailFile();
        data29.zenginAmount=null;
        data29.zenginManageNo="13";
        data29.accountAmount=5;
        data29.accountManageNo="02";
        data29.differentAmount=-5;
        resDatalist.add(data29)

        def data30 = new SettlementCollationOfficerDetailFile();
        data30.zenginAmount=null;
        data30.zenginManageNo="14";
        data30.accountAmount=5;
        data30.accountManageNo="02";
        data30.differentAmount=-5;
        resDatalist.add(data30)

        def data31 = new SettlementCollationOfficerDetailFile();
        data31.zenginAmount=null;
        data31.zenginManageNo="14";
        data31.accountAmount=5;
        data31.accountManageNo="02";
        data31.differentAmount=-5;
        resDatalist.add(data31)

        def data32 = new SettlementCollationOfficerDetailFile();
        data32.zenginAmount=null;
        data32.zenginManageNo=null;
        data32.accountAmount=5;
        data32.accountManageNo="02";
        data32.differentAmount=-5;
        resDatalist.add(data32)

        def data33 = new SettlementCollationOfficerDetailFile();
        data33.zenginAmount=null;
        data33.zenginManageNo=null;
        data33.accountAmount=null;
        data33.accountManageNo=null;
        data33.differentAmount=null;
        resDatalist.add(data33)


        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), resDatalist);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultMap))
        return reslist
    }

    private List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> inDataLarge(){
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()

        def data5 = new SettlementCollationOfficerDetailFile();
        data5.zenginAmount=null;
        data5.zenginManageNo="05";
        data5.accountAmount=5;
        data5.accountManageNo="01";
        data5.differentAmount=-5;
        resDatalist.add(data5)

        def data6 = new SettlementCollationOfficerDetailFile();
        data6.zenginAmount=null;
        data6.zenginManageNo="06";
        data6.accountAmount=5;
        data6.accountManageNo="01";
        data6.differentAmount=-5;
        resDatalist.add(data6)

        def data7 = new SettlementCollationOfficerDetailFile();
        data7.zenginAmount=null;
        data7.zenginManageNo="07";
        data7.accountAmount=5;
        data7.accountManageNo="01";
        data7.differentAmount=-5;
        resDatalist.add(data7)

        def data8 = new SettlementCollationOfficerDetailFile();
        data8.zenginAmount=null;
        data8.zenginManageNo="08";
        data8.accountAmount=5;
        data8.accountManageNo="01";
        data8.differentAmount=-5;
        resDatalist.add(data8)

        def data9 = new SettlementCollationOfficerDetailFile();
        data9.zenginAmount=null;
        data9.zenginManageNo="09";
        data9.accountAmount=5;
        data9.accountManageNo="01";
        data9.differentAmount=-5;
        resDatalist.add(data9)

        def data10 = new SettlementCollationOfficerDetailFile();
        data10.zenginAmount=null;
        data10.zenginManageNo="10";
        data10.accountAmount=5;
        data10.accountManageNo="01";
        data10.differentAmount=-5;
        resDatalist.add(data10)

        def data22 = new SettlementCollationOfficerDetailFile();
        data22.zenginAmount=null;
        data22.zenginManageNo="06";
        data22.accountAmount=5;
        data22.accountManageNo="02";
        data22.differentAmount=-5;
        resDatalist.add(data22)

        def data23 = new SettlementCollationOfficerDetailFile();
        data23.zenginAmount=null;
        data23.zenginManageNo="07";
        data23.accountAmount=5;
        data23.accountManageNo="02";
        data23.differentAmount=-5;
        resDatalist.add(data23)

        def data24 = new SettlementCollationOfficerDetailFile();
        data24.zenginAmount=null;
        data24.zenginManageNo="08";
        data24.accountAmount=5;
        data24.accountManageNo="02";
        data24.differentAmount=-5;
        resDatalist.add(data24)

        def data1 = new SettlementCollationOfficerDetailFile();
        data1.zenginAmount=null;
        data1.zenginManageNo="01";
        data1.accountAmount=5;
        data1.accountManageNo="01";
        data1.differentAmount=-5;
        resDatalist.add(data1)

        def data2 = new SettlementCollationOfficerDetailFile();
        data2.zenginAmount=null;
        data2.zenginManageNo="02";
        data2.accountAmount=5;
        data2.accountManageNo="01";
        data2.differentAmount=-5;
        resDatalist.add(data2)

        def data3 = new SettlementCollationOfficerDetailFile();
        data3.zenginAmount=null;
        data3.zenginManageNo="03";
        data3.accountAmount=5;
        data3.accountManageNo="01";
        data3.differentAmount=-5;
        resDatalist.add(data3)

        def data11 = new SettlementCollationOfficerDetailFile();
        data11.zenginAmount=null;
        data11.zenginManageNo="11";
        data11.accountAmount=5;
        data11.accountManageNo="01";
        data11.differentAmount=-5;
        resDatalist.add(data11)

        def data12 = new SettlementCollationOfficerDetailFile();
        data12.zenginAmount=null;
        data12.zenginManageNo="12";
        data12.accountAmount=5;
        data12.accountManageNo="01";
        data12.differentAmount=-5;
        resDatalist.add(data12)

        def data13 = new SettlementCollationOfficerDetailFile();
        data13.zenginAmount=null;
        data13.zenginManageNo="13";
        data13.accountAmount=5;
        data13.accountManageNo="01";
        data13.differentAmount=-5;
        resDatalist.add(data13)

        def data14 = new SettlementCollationOfficerDetailFile();
        data14.zenginAmount=null;
        data14.zenginManageNo="14";
        data14.accountAmount=5;
        data14.accountManageNo="01";
        data14.differentAmount=-5;
        resDatalist.add(data14)

        def data15 = new SettlementCollationOfficerDetailFile();
        data15.zenginAmount=null;
        data15.zenginManageNo="14";
        data15.accountAmount=5;
        data15.accountManageNo="01";
        data15.differentAmount=-5;
        resDatalist.add(data15)

        def data16 = new SettlementCollationOfficerDetailFile();
        data16.zenginAmount=null;
        data16.zenginManageNo=null;
        data16.accountAmount=5;
        data16.accountManageNo="01";
        data16.differentAmount=-5;
        resDatalist.add(data16)

        def data17 = new SettlementCollationOfficerDetailFile();
        data17.zenginAmount=null;
        data17.zenginManageNo="01";
        data17.accountAmount=5;
        data17.accountManageNo="02";
        data17.differentAmount=-5;
        resDatalist.add(data17)

        def data18 = new SettlementCollationOfficerDetailFile();
        data18.zenginAmount=null;
        data18.zenginManageNo="02";
        data18.accountAmount=5;
        data18.accountManageNo="02";
        data18.differentAmount=-5;
        resDatalist.add(data18)

        def data19 = new SettlementCollationOfficerDetailFile();
        data19.zenginAmount=null;
        data19.zenginManageNo="03";
        data19.accountAmount=5;
        data19.accountManageNo="02";
        data19.differentAmount=-5;
        resDatalist.add(data19)

        def data20 = new SettlementCollationOfficerDetailFile();
        data20.zenginAmount=null;
        data20.zenginManageNo="04";
        data20.accountAmount=5;
        data20.accountManageNo="02";
        data20.differentAmount=-5;
        resDatalist.add(data20)

        def data21 = new SettlementCollationOfficerDetailFile();
        data21.zenginAmount=null;
        data21.zenginManageNo="05";
        data21.accountAmount=5;
        data21.accountManageNo="02";
        data21.differentAmount=-5;
        resDatalist.add(data21)

        def data27 = new SettlementCollationOfficerDetailFile();
        data27.zenginAmount=null;
        data27.zenginManageNo="11";
        data27.accountAmount=5;
        data27.accountManageNo="02";
        data27.differentAmount=-5;
        resDatalist.add(data27)

        def data28 = new SettlementCollationOfficerDetailFile();
        data28.zenginAmount=null;
        data28.zenginManageNo="12";
        data28.accountAmount=5;
        data28.accountManageNo="02";
        data28.differentAmount=-5;
        resDatalist.add(data28)

        def data29 = new SettlementCollationOfficerDetailFile();
        data29.zenginAmount=null;
        data29.zenginManageNo="13";
        data29.accountAmount=5;
        data29.accountManageNo="02";
        data29.differentAmount=-5;
        resDatalist.add(data29)

        def data30 = new SettlementCollationOfficerDetailFile();
        data30.zenginAmount=null;
        data30.zenginManageNo="14";
        data30.accountAmount=5;
        data30.accountManageNo="02";
        data30.differentAmount=-5;
        resDatalist.add(data30)

        def data31 = new SettlementCollationOfficerDetailFile();
        data31.zenginAmount=null;
        data31.zenginManageNo="14";
        data31.accountAmount=5;
        data31.accountManageNo="02";
        data31.differentAmount=-5;
        resDatalist.add(data31)

        def data25 = new SettlementCollationOfficerDetailFile();
        data25.zenginAmount=null;
        data25.zenginManageNo="09";
        data25.accountAmount=5;
        data25.accountManageNo="02";
        data25.differentAmount=-5;
        resDatalist.add(data25)

        def data26 = new SettlementCollationOfficerDetailFile();
        data26.zenginAmount=null;
        data26.zenginManageNo="10";
        data26.accountAmount=5;
        data26.accountManageNo="02";
        data26.differentAmount=-5;
        resDatalist.add(data26)

        def data32 = new SettlementCollationOfficerDetailFile();
        data32.zenginAmount=null;
        data32.zenginManageNo=null;
        data32.accountAmount=5;
        data32.accountManageNo="02";
        data32.differentAmount=-5;
        resDatalist.add(data32)

        def data33 = new SettlementCollationOfficerDetailFile();
        data33.zenginAmount=null;
        data33.zenginManageNo=null;
        data33.accountAmount=null;
        data33.accountManageNo=null;
        data33.differentAmount=null;
        resDatalist.add(data33)

        def data4 = new SettlementCollationOfficerDetailFile();
        data4.zenginAmount=null;
        data4.zenginManageNo="04";
        data4.accountAmount=5;
        data4.accountManageNo="01";
        data4.differentAmount=-5;
        resDatalist.add(data4)

        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable<SettlementCollationOfficerDetailFile>)resDatalist))
        return reslist
    }


    private List<KV<List<String>, Map<String, List<DataClassBase>>>> resDataLargeDuplecate(){
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()

        def data1 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub1 = new SettlementCollationOfficerDetailFile();
        data1.zenginAmount=null;                        ;           data_sub1.zenginAmount=null;
        data1.zenginManageNo="01";                      ;           data_sub1.zenginManageNo="01";
        data1.accountAmount=5;                      ;           data_sub1.accountAmount=5;
        data1.accountManageNo="01";                     ;           data_sub1.accountManageNo="01";
        data1.differentAmount=-5;                       ;           data_sub1.differentAmount=-5;
        resDatalist.add(data1)                      ;           resDatalist.add(data_sub1)
        ;
        def data2 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub2 = new SettlementCollationOfficerDetailFile();
        data2.zenginAmount=null;                        ;           data_sub2.zenginAmount=null;
        data2.zenginManageNo="02";                      ;           data_sub2.zenginManageNo="02";
        data2.accountAmount=5;                      ;           data_sub2.accountAmount=5;
        data2.accountManageNo="01";                     ;           data_sub2.accountManageNo="01";
        data2.differentAmount=-5;                       ;           data_sub2.differentAmount=-5;
        resDatalist.add(data2)                      ;           resDatalist.add(data_sub2)
        ;
        def data3 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub3 = new SettlementCollationOfficerDetailFile();
        data3.zenginAmount=null;                        ;           data_sub3.zenginAmount=null;
        data3.zenginManageNo="03";                      ;           data_sub3.zenginManageNo="03";
        data3.accountAmount=5;                      ;           data_sub3.accountAmount=5;
        data3.accountManageNo="01";                     ;           data_sub3.accountManageNo="01";
        data3.differentAmount=-5;                       ;           data_sub3.differentAmount=-5;
        resDatalist.add(data3)                      ;           resDatalist.add(data_sub3)
        ;
        def data4 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub4 = new SettlementCollationOfficerDetailFile();
        data4.zenginAmount=null;                        ;           data_sub4.zenginAmount=null;
        data4.zenginManageNo="04";                      ;           data_sub4.zenginManageNo="04";
        data4.accountAmount=5;                      ;           data_sub4.accountAmount=5;
        data4.accountManageNo="01";                     ;           data_sub4.accountManageNo="01";
        data4.differentAmount=-5;                       ;           data_sub4.differentAmount=-5;
        resDatalist.add(data4)                      ;           resDatalist.add(data_sub4)
        ;
        def data5 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub5 = new SettlementCollationOfficerDetailFile();
        data5.zenginAmount=null;                        ;           data_sub5.zenginAmount=null;
        data5.zenginManageNo="05";                      ;           data_sub5.zenginManageNo="05";
        data5.accountAmount=5;                      ;           data_sub5.accountAmount=5;
        data5.accountManageNo="01";                     ;           data_sub5.accountManageNo="01";
        data5.differentAmount=-5;                       ;           data_sub5.differentAmount=-5;
        resDatalist.add(data5)                      ;           resDatalist.add(data_sub5)
        ;
        def data6 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub6 = new SettlementCollationOfficerDetailFile();
        data6.zenginAmount=null;                        ;           data_sub6.zenginAmount=null;
        data6.zenginManageNo="06";                      ;           data_sub6.zenginManageNo="06";
        data6.accountAmount=5;                      ;           data_sub6.accountAmount=5;
        data6.accountManageNo="01";                     ;           data_sub6.accountManageNo="01";
        data6.differentAmount=-5;                       ;           data_sub6.differentAmount=-5;
        resDatalist.add(data6)                      ;           resDatalist.add(data_sub6)
        ;
        def data7 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub7 = new SettlementCollationOfficerDetailFile();
        data7.zenginAmount=null;                        ;           data_sub7.zenginAmount=null;
        data7.zenginManageNo="07";                      ;           data_sub7.zenginManageNo="07";
        data7.accountAmount=5;                      ;           data_sub7.accountAmount=5;
        data7.accountManageNo="01";                     ;           data_sub7.accountManageNo="01";
        data7.differentAmount=-5;                       ;           data_sub7.differentAmount=-5;
        resDatalist.add(data7)                      ;           resDatalist.add(data_sub7)
        ;
        def data8 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub8 = new SettlementCollationOfficerDetailFile();
        data8.zenginAmount=null;                        ;           data_sub8.zenginAmount=null;
        data8.zenginManageNo="08";                      ;           data_sub8.zenginManageNo="08";
        data8.accountAmount=5;                      ;           data_sub8.accountAmount=5;
        data8.accountManageNo="01";                     ;           data_sub8.accountManageNo="01";
        data8.differentAmount=-5;                       ;           data_sub8.differentAmount=-5;
        resDatalist.add(data8)                      ;           resDatalist.add(data_sub8)
        ;
        def data9 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub9 = new SettlementCollationOfficerDetailFile();
        data9.zenginAmount=null;                        ;           data_sub9.zenginAmount=null;
        data9.zenginManageNo="09";                      ;           data_sub9.zenginManageNo="09";
        data9.accountAmount=5;                      ;           data_sub9.accountAmount=5;
        data9.accountManageNo="01";                     ;           data_sub9.accountManageNo="01";
        data9.differentAmount=-5;                       ;           data_sub9.differentAmount=-5;
        resDatalist.add(data9)                      ;           resDatalist.add(data_sub9)
        ;
        def data10 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub10 = new SettlementCollationOfficerDetailFile();
        data10.zenginAmount=null;                       ;           data_sub10.zenginAmount=null;
        data10.zenginManageNo="10";                     ;           data_sub10.zenginManageNo="10";
        data10.accountAmount=5;                     ;           data_sub10.accountAmount=5;
        data10.accountManageNo="01";                        ;           data_sub10.accountManageNo="01";
        data10.differentAmount=-5;                      ;           data_sub10.differentAmount=-5;
        resDatalist.add(data10)                     ;           resDatalist.add(data_sub10)
        ;
        def data11 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub11 = new SettlementCollationOfficerDetailFile();
        data11.zenginAmount=null;                       ;           data_sub11.zenginAmount=null;
        data11.zenginManageNo="11";                     ;           data_sub11.zenginManageNo="11";
        data11.accountAmount=5;                     ;           data_sub11.accountAmount=5;
        data11.accountManageNo="01";                        ;           data_sub11.accountManageNo="01";
        data11.differentAmount=-5;                      ;           data_sub11.differentAmount=-5;
        resDatalist.add(data11)                     ;           resDatalist.add(data_sub11)
        ;
        def data12 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub12 = new SettlementCollationOfficerDetailFile();
        data12.zenginAmount=null;                       ;           data_sub12.zenginAmount=null;
        data12.zenginManageNo="12";                     ;           data_sub12.zenginManageNo="12";
        data12.accountAmount=5;                     ;           data_sub12.accountAmount=5;
        data12.accountManageNo="01";                        ;           data_sub12.accountManageNo="01";
        data12.differentAmount=-5;                      ;           data_sub12.differentAmount=-5;
        resDatalist.add(data12)                     ;           resDatalist.add(data_sub12)
        ;
        def data13 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub13 = new SettlementCollationOfficerDetailFile();
        data13.zenginAmount=null;                       ;           data_sub13.zenginAmount=null;
        data13.zenginManageNo="13";                     ;           data_sub13.zenginManageNo="13";
        data13.accountAmount=5;                     ;           data_sub13.accountAmount=5;
        data13.accountManageNo="01";                        ;           data_sub13.accountManageNo="01";
        data13.differentAmount=-5;                      ;           data_sub13.differentAmount=-5;
        resDatalist.add(data13)                     ;           resDatalist.add(data_sub13)
        ;
        def data14 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub14 = new SettlementCollationOfficerDetailFile();
        data14.zenginAmount=null;                       ;           data_sub14.zenginAmount=null;
        data14.zenginManageNo="14";                     ;           data_sub14.zenginManageNo="14";
        data14.accountAmount=5;                     ;           data_sub14.accountAmount=5;
        data14.accountManageNo="01";                        ;           data_sub14.accountManageNo="01";
        data14.differentAmount=-5;                      ;           data_sub14.differentAmount=-5;
        resDatalist.add(data14)                     ;           resDatalist.add(data_sub14)
        ;
        def data15 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub15 = new SettlementCollationOfficerDetailFile();
        data15.zenginAmount=null;                       ;           data_sub15.zenginAmount=null;
        data15.zenginManageNo="14";                     ;           data_sub15.zenginManageNo="14";
        data15.accountAmount=5;                     ;           data_sub15.accountAmount=5;
        data15.accountManageNo="01";                        ;           data_sub15.accountManageNo="01";
        data15.differentAmount=-5;                      ;           data_sub15.differentAmount=-5;
        resDatalist.add(data15)                     ;           resDatalist.add(data_sub15)
        ;
        def data16 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub16 = new SettlementCollationOfficerDetailFile();
        data16.zenginAmount=null;                       ;           data_sub16.zenginAmount=null;
        data16.zenginManageNo=null;                     ;           data_sub16.zenginManageNo=null;
        data16.accountAmount=5;                     ;           data_sub16.accountAmount=5;
        data16.accountManageNo="01";                        ;           data_sub16.accountManageNo="01";
        data16.differentAmount=-5;                      ;           data_sub16.differentAmount=-5;
        resDatalist.add(data16)                     ;           resDatalist.add(data_sub16)
        ;
        ;
        ;
        def data17 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub17 = new SettlementCollationOfficerDetailFile();
        data17.zenginAmount=null;                       ;           data_sub17.zenginAmount=null;
        data17.zenginManageNo="01";                     ;           data_sub17.zenginManageNo="01";
        data17.accountAmount=5;                     ;           data_sub17.accountAmount=5;
        data17.accountManageNo="02";                        ;           data_sub17.accountManageNo="02";
        data17.differentAmount=-5;                      ;           data_sub17.differentAmount=-5;
        resDatalist.add(data17)                     ;           resDatalist.add(data_sub17)
        ;
        def data18 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub18 = new SettlementCollationOfficerDetailFile();
        data18.zenginAmount=null;                       ;           data_sub18.zenginAmount=null;
        data18.zenginManageNo="02";                     ;           data_sub18.zenginManageNo="02";
        data18.accountAmount=5;                     ;           data_sub18.accountAmount=5;
        data18.accountManageNo="02";                        ;           data_sub18.accountManageNo="02";
        data18.differentAmount=-5;                      ;           data_sub18.differentAmount=-5;
        resDatalist.add(data18)                     ;           resDatalist.add(data_sub18)
        ;
        def data19 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub19 = new SettlementCollationOfficerDetailFile();
        data19.zenginAmount=null;                       ;           data_sub19.zenginAmount=null;
        data19.zenginManageNo="03";                     ;           data_sub19.zenginManageNo="03";
        data19.accountAmount=5;                     ;           data_sub19.accountAmount=5;
        data19.accountManageNo="02";                        ;           data_sub19.accountManageNo="02";
        data19.differentAmount=-5;                      ;           data_sub19.differentAmount=-5;
        resDatalist.add(data19)                     ;           resDatalist.add(data_sub19)
        ;
        def data20 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub20 = new SettlementCollationOfficerDetailFile();
        data20.zenginAmount=null;                       ;           data_sub20.zenginAmount=null;
        data20.zenginManageNo="04";                     ;           data_sub20.zenginManageNo="04";
        data20.accountAmount=5;                     ;           data_sub20.accountAmount=5;
        data20.accountManageNo="02";                        ;           data_sub20.accountManageNo="02";
        data20.differentAmount=-5;                      ;           data_sub20.differentAmount=-5;
        resDatalist.add(data20)                     ;           resDatalist.add(data_sub20)
        ;
        def data21 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub21 = new SettlementCollationOfficerDetailFile();
        data21.zenginAmount=null;                       ;           data_sub21.zenginAmount=null;
        data21.zenginManageNo="05";                     ;           data_sub21.zenginManageNo="05";
        data21.accountAmount=5;                     ;           data_sub21.accountAmount=5;
        data21.accountManageNo="02";                        ;           data_sub21.accountManageNo="02";
        data21.differentAmount=-5;                      ;           data_sub21.differentAmount=-5;
        resDatalist.add(data21)                     ;           resDatalist.add(data_sub21)
        ;
        def data22 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub22 = new SettlementCollationOfficerDetailFile();
        data22.zenginAmount=null;                       ;           data_sub22.zenginAmount=null;
        data22.zenginManageNo="06";                     ;           data_sub22.zenginManageNo="06";
        data22.accountAmount=5;                     ;           data_sub22.accountAmount=5;
        data22.accountManageNo="02";                        ;           data_sub22.accountManageNo="02";
        data22.differentAmount=-5;                      ;           data_sub22.differentAmount=-5;
        resDatalist.add(data22)                     ;           resDatalist.add(data_sub22)
        ;
        def data23 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub23 = new SettlementCollationOfficerDetailFile();
        data23.zenginAmount=null;                       ;           data_sub23.zenginAmount=null;
        data23.zenginManageNo="07";                     ;           data_sub23.zenginManageNo="07";
        data23.accountAmount=5;                     ;           data_sub23.accountAmount=5;
        data23.accountManageNo="02";                        ;           data_sub23.accountManageNo="02";
        data23.differentAmount=-5;                      ;           data_sub23.differentAmount=-5;
        resDatalist.add(data23)                     ;           resDatalist.add(data_sub23)
        ;
        def data24 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub24 = new SettlementCollationOfficerDetailFile();
        data24.zenginAmount=null;                       ;           data_sub24.zenginAmount=null;
        data24.zenginManageNo="08";                     ;           data_sub24.zenginManageNo="08";
        data24.accountAmount=5;                     ;           data_sub24.accountAmount=5;
        data24.accountManageNo="02";                        ;           data_sub24.accountManageNo="02";
        data24.differentAmount=-5;                      ;           data_sub24.differentAmount=-5;
        resDatalist.add(data24)                     ;           resDatalist.add(data_sub24)
        ;
        def data25 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub25 = new SettlementCollationOfficerDetailFile();
        data25.zenginAmount=null;                       ;           data_sub25.zenginAmount=null;
        data25.zenginManageNo="09";                     ;           data_sub25.zenginManageNo="09";
        data25.accountAmount=5;                     ;           data_sub25.accountAmount=5;
        data25.accountManageNo="02";                        ;           data_sub25.accountManageNo="02";
        data25.differentAmount=-5;                      ;           data_sub25.differentAmount=-5;
        resDatalist.add(data25)                     ;           resDatalist.add(data_sub25)
        ;
        def data26 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub26 = new SettlementCollationOfficerDetailFile();
        data26.zenginAmount=null;                       ;           data_sub26.zenginAmount=null;
        data26.zenginManageNo="10";                     ;           data_sub26.zenginManageNo="10";
        data26.accountAmount=5;                     ;           data_sub26.accountAmount=5;
        data26.accountManageNo="02";                        ;           data_sub26.accountManageNo="02";
        data26.differentAmount=-5;                      ;           data_sub26.differentAmount=-5;
        resDatalist.add(data26)                     ;           resDatalist.add(data_sub26)
        ;
        def data27 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub27 = new SettlementCollationOfficerDetailFile();
        data27.zenginAmount=null;                       ;           data_sub27.zenginAmount=null;
        data27.zenginManageNo="11";                     ;           data_sub27.zenginManageNo="11";
        data27.accountAmount=5;                     ;           data_sub27.accountAmount=5;
        data27.accountManageNo="02";                        ;           data_sub27.accountManageNo="02";
        data27.differentAmount=-5;                      ;           data_sub27.differentAmount=-5;
        resDatalist.add(data27)                     ;           resDatalist.add(data_sub27)
        ;
        def data28 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub28 = new SettlementCollationOfficerDetailFile();
        data28.zenginAmount=null;                       ;           data_sub28.zenginAmount=null;
        data28.zenginManageNo="12";                     ;           data_sub28.zenginManageNo="12";
        data28.accountAmount=5;                     ;           data_sub28.accountAmount=5;
        data28.accountManageNo="02";                        ;           data_sub28.accountManageNo="02";
        data28.differentAmount=-5;                      ;           data_sub28.differentAmount=-5;
        resDatalist.add(data28)                     ;           resDatalist.add(data_sub28)
        ;
        def data29 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub29 = new SettlementCollationOfficerDetailFile();
        data29.zenginAmount=null;                       ;           data_sub29.zenginAmount=null;
        data29.zenginManageNo="13";                     ;           data_sub29.zenginManageNo="13";
        data29.accountAmount=5;                     ;           data_sub29.accountAmount=5;
        data29.accountManageNo="02";                        ;           data_sub29.accountManageNo="02";
        data29.differentAmount=-5;                      ;           data_sub29.differentAmount=-5;
        resDatalist.add(data29)                     ;           resDatalist.add(data_sub29)
        ;
        def data30 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub30 = new SettlementCollationOfficerDetailFile();
        data30.zenginAmount=null;                       ;           data_sub30.zenginAmount=null;
        data30.zenginManageNo="14";                     ;           data_sub30.zenginManageNo="14";
        data30.accountAmount=5;                     ;           data_sub30.accountAmount=5;
        data30.accountManageNo="02";                        ;           data_sub30.accountManageNo="02";
        data30.differentAmount=-5;                      ;           data_sub30.differentAmount=-5;
        resDatalist.add(data30)                     ;           resDatalist.add(data_sub30)
        ;
        def data31 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub31 = new SettlementCollationOfficerDetailFile();
        data31.zenginAmount=null;                       ;           data_sub31.zenginAmount=null;
        data31.zenginManageNo="14";                     ;           data_sub31.zenginManageNo="14";
        data31.accountAmount=5;                     ;           data_sub31.accountAmount=5;
        data31.accountManageNo="02";                        ;           data_sub31.accountManageNo="02";
        data31.differentAmount=-5;                      ;           data_sub31.differentAmount=-5;
        resDatalist.add(data31)                     ;           resDatalist.add(data_sub31)
        ;
        def data32 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub32 = new SettlementCollationOfficerDetailFile();
        data32.zenginAmount=null;                       ;           data_sub32.zenginAmount=null;
        data32.zenginManageNo=null;                     ;           data_sub32.zenginManageNo=null;
        data32.accountAmount=5;                     ;           data_sub32.accountAmount=5;
        data32.accountManageNo="02";                        ;           data_sub32.accountManageNo="02";
        data32.differentAmount=-5;                      ;           data_sub32.differentAmount=-5;
        resDatalist.add(data32)                     ;           resDatalist.add(data_sub32)
        ;
        def data33 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub33 = new SettlementCollationOfficerDetailFile();
        data33.zenginAmount=null;                       ;           data_sub33.zenginAmount=null;
        data33.zenginManageNo=null;                     ;           data_sub33.zenginManageNo=null;
        data33.accountAmount=null;                      ;           data_sub33.accountAmount=null;
        data33.accountManageNo=null;                        ;           data_sub33.accountManageNo=null;
        data33.differentAmount=null;                        ;           data_sub33.differentAmount=null;
        resDatalist.add(data33)                     ;           resDatalist.add(data_sub33)



        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), resDatalist);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultMap))
        return reslist
    }

    private List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> inDataLargeDuplecate(){
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()

        def data1 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub1 = new SettlementCollationOfficerDetailFile();
        data1.zenginAmount=null;                        ;           data_sub1.zenginAmount=null;
        data1.zenginManageNo="01";                      ;           data_sub1.zenginManageNo="01";
        data1.accountAmount=5;                      ;           data_sub1.accountAmount=5;
        data1.accountManageNo="01";                     ;           data_sub1.accountManageNo="01";
        data1.differentAmount=-5;                       ;           data_sub1.differentAmount=-5;
        resDatalist.add(data1)                      ;           resDatalist.add(data_sub1)
        ;
        def data2 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub2 = new SettlementCollationOfficerDetailFile();
        data2.zenginAmount=null;                        ;           data_sub2.zenginAmount=null;
        data2.zenginManageNo="02";                      ;           data_sub2.zenginManageNo="02";
        data2.accountAmount=5;                      ;           data_sub2.accountAmount=5;
        data2.accountManageNo="01";                     ;           data_sub2.accountManageNo="01";
        data2.differentAmount=-5;                       ;           data_sub2.differentAmount=-5;
        resDatalist.add(data2)                      ;           resDatalist.add(data_sub2)
        ;
        def data3 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub3 = new SettlementCollationOfficerDetailFile();
        data3.zenginAmount=null;                        ;           data_sub3.zenginAmount=null;
        data3.zenginManageNo="03";                      ;           data_sub3.zenginManageNo="03";
        data3.accountAmount=5;                      ;           data_sub3.accountAmount=5;
        data3.accountManageNo="01";                     ;           data_sub3.accountManageNo="01";
        data3.differentAmount=-5;                       ;           data_sub3.differentAmount=-5;
        resDatalist.add(data3)                      ;           resDatalist.add(data_sub3)
        ;
        def data4 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub4 = new SettlementCollationOfficerDetailFile();
        data4.zenginAmount=null;                        ;           data_sub4.zenginAmount=null;
        data4.zenginManageNo="04";                      ;           data_sub4.zenginManageNo="04";
        data4.accountAmount=5;                      ;           data_sub4.accountAmount=5;
        data4.accountManageNo="01";                     ;           data_sub4.accountManageNo="01";
        data4.differentAmount=-5;                       ;           data_sub4.differentAmount=-5;
        resDatalist.add(data4)                      ;           resDatalist.add(data_sub4)
        ;
        def data5 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub5 = new SettlementCollationOfficerDetailFile();
        data5.zenginAmount=null;                        ;           data_sub5.zenginAmount=null;
        data5.zenginManageNo="05";                      ;           data_sub5.zenginManageNo="05";
        data5.accountAmount=5;                      ;           data_sub5.accountAmount=5;
        data5.accountManageNo="01";                     ;           data_sub5.accountManageNo="01";
        data5.differentAmount=-5;                       ;           data_sub5.differentAmount=-5;
        resDatalist.add(data5)                      ;           resDatalist.add(data_sub5)
        ;
        def data6 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub6 = new SettlementCollationOfficerDetailFile();
        data6.zenginAmount=null;                        ;           data_sub6.zenginAmount=null;
        data6.zenginManageNo="06";                      ;           data_sub6.zenginManageNo="06";
        data6.accountAmount=5;                      ;           data_sub6.accountAmount=5;
        data6.accountManageNo="01";                     ;           data_sub6.accountManageNo="01";
        data6.differentAmount=-5;                       ;           data_sub6.differentAmount=-5;
        resDatalist.add(data6)                      ;           resDatalist.add(data_sub6)
        ;
        def data7 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub7 = new SettlementCollationOfficerDetailFile();
        data7.zenginAmount=null;                        ;           data_sub7.zenginAmount=null;
        data7.zenginManageNo="07";                      ;           data_sub7.zenginManageNo="07";
        data7.accountAmount=5;                      ;           data_sub7.accountAmount=5;
        data7.accountManageNo="01";                     ;           data_sub7.accountManageNo="01";
        data7.differentAmount=-5;                       ;           data_sub7.differentAmount=-5;
        resDatalist.add(data7)                      ;           resDatalist.add(data_sub7)
        ;
        def data8 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub8 = new SettlementCollationOfficerDetailFile();
        data8.zenginAmount=null;                        ;           data_sub8.zenginAmount=null;
        data8.zenginManageNo="08";                      ;           data_sub8.zenginManageNo="08";
        data8.accountAmount=5;                      ;           data_sub8.accountAmount=5;
        data8.accountManageNo="01";                     ;           data_sub8.accountManageNo="01";
        data8.differentAmount=-5;                       ;           data_sub8.differentAmount=-5;
        resDatalist.add(data8)                      ;           resDatalist.add(data_sub8)
        ;
        def data9 = new SettlementCollationOfficerDetailFile();                     ;           def data_sub9 = new SettlementCollationOfficerDetailFile();
        data9.zenginAmount=null;                        ;           data_sub9.zenginAmount=null;
        data9.zenginManageNo="09";                      ;           data_sub9.zenginManageNo="09";
        data9.accountAmount=5;                      ;           data_sub9.accountAmount=5;
        data9.accountManageNo="01";                     ;           data_sub9.accountManageNo="01";
        data9.differentAmount=-5;                       ;           data_sub9.differentAmount=-5;
        resDatalist.add(data9)                      ;           resDatalist.add(data_sub9)
        ;
        def data10 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub10 = new SettlementCollationOfficerDetailFile();
        data10.zenginAmount=null;                       ;           data_sub10.zenginAmount=null;
        data10.zenginManageNo="10";                     ;           data_sub10.zenginManageNo="10";
        data10.accountAmount=5;                     ;           data_sub10.accountAmount=5;
        data10.accountManageNo="01";                        ;           data_sub10.accountManageNo="01";
        data10.differentAmount=-5;                      ;           data_sub10.differentAmount=-5;
        resDatalist.add(data10)                     ;           resDatalist.add(data_sub10)
        ;
        def data11 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub11 = new SettlementCollationOfficerDetailFile();
        data11.zenginAmount=null;                       ;           data_sub11.zenginAmount=null;
        data11.zenginManageNo="11";                     ;           data_sub11.zenginManageNo="11";
        data11.accountAmount=5;                     ;           data_sub11.accountAmount=5;
        data11.accountManageNo="01";                        ;           data_sub11.accountManageNo="01";
        data11.differentAmount=-5;                      ;           data_sub11.differentAmount=-5;
        resDatalist.add(data11)                     ;           resDatalist.add(data_sub11)
        ;
        def data12 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub12 = new SettlementCollationOfficerDetailFile();
        data12.zenginAmount=null;                       ;           data_sub12.zenginAmount=null;
        data12.zenginManageNo="12";                     ;           data_sub12.zenginManageNo="12";
        data12.accountAmount=5;                     ;           data_sub12.accountAmount=5;
        data12.accountManageNo="01";                        ;           data_sub12.accountManageNo="01";
        data12.differentAmount=-5;                      ;           data_sub12.differentAmount=-5;
        resDatalist.add(data12)                     ;           resDatalist.add(data_sub12)
        ;
        def data13 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub13 = new SettlementCollationOfficerDetailFile();
        data13.zenginAmount=null;                       ;           data_sub13.zenginAmount=null;
        data13.zenginManageNo="13";                     ;           data_sub13.zenginManageNo="13";
        data13.accountAmount=5;                     ;           data_sub13.accountAmount=5;
        data13.accountManageNo="01";                        ;           data_sub13.accountManageNo="01";
        data13.differentAmount=-5;                      ;           data_sub13.differentAmount=-5;
        resDatalist.add(data13)                     ;           resDatalist.add(data_sub13)
        ;
        def data14 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub14 = new SettlementCollationOfficerDetailFile();
        data14.zenginAmount=null;                       ;           data_sub14.zenginAmount=null;
        data14.zenginManageNo="14";                     ;           data_sub14.zenginManageNo="14";
        data14.accountAmount=5;                     ;           data_sub14.accountAmount=5;
        data14.accountManageNo="01";                        ;           data_sub14.accountManageNo="01";
        data14.differentAmount=-5;                      ;           data_sub14.differentAmount=-5;
        resDatalist.add(data14)                     ;           resDatalist.add(data_sub14)
        ;
        def data15 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub15 = new SettlementCollationOfficerDetailFile();
        data15.zenginAmount=null;                       ;           data_sub15.zenginAmount=null;
        data15.zenginManageNo="14";                     ;           data_sub15.zenginManageNo="14";
        data15.accountAmount=5;                     ;           data_sub15.accountAmount=5;
        data15.accountManageNo="01";                        ;           data_sub15.accountManageNo="01";
        data15.differentAmount=-5;                      ;           data_sub15.differentAmount=-5;
        resDatalist.add(data15)                     ;           resDatalist.add(data_sub15)
        ;
        def data16 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub16 = new SettlementCollationOfficerDetailFile();
        data16.zenginAmount=null;                       ;           data_sub16.zenginAmount=null;
        data16.zenginManageNo=null;                     ;           data_sub16.zenginManageNo=null;
        data16.accountAmount=5;                     ;           data_sub16.accountAmount=5;
        data16.accountManageNo="01";                        ;           data_sub16.accountManageNo="01";
        data16.differentAmount=-5;                      ;           data_sub16.differentAmount=-5;
        resDatalist.add(data16)                     ;           resDatalist.add(data_sub16)
        ;
        ;
        ;
        def data17 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub17 = new SettlementCollationOfficerDetailFile();
        data17.zenginAmount=null;                       ;           data_sub17.zenginAmount=null;
        data17.zenginManageNo="01";                     ;           data_sub17.zenginManageNo="01";
        data17.accountAmount=5;                     ;           data_sub17.accountAmount=5;
        data17.accountManageNo="02";                        ;           data_sub17.accountManageNo="02";
        data17.differentAmount=-5;                      ;           data_sub17.differentAmount=-5;
        resDatalist.add(data17)                     ;           resDatalist.add(data_sub17)
        ;
        def data18 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub18 = new SettlementCollationOfficerDetailFile();
        data18.zenginAmount=null;                       ;           data_sub18.zenginAmount=null;
        data18.zenginManageNo="02";                     ;           data_sub18.zenginManageNo="02";
        data18.accountAmount=5;                     ;           data_sub18.accountAmount=5;
        data18.accountManageNo="02";                        ;           data_sub18.accountManageNo="02";
        data18.differentAmount=-5;                      ;           data_sub18.differentAmount=-5;
        resDatalist.add(data18)                     ;           resDatalist.add(data_sub18)
        ;
        def data19 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub19 = new SettlementCollationOfficerDetailFile();
        data19.zenginAmount=null;                       ;           data_sub19.zenginAmount=null;
        data19.zenginManageNo="03";                     ;           data_sub19.zenginManageNo="03";
        data19.accountAmount=5;                     ;           data_sub19.accountAmount=5;
        data19.accountManageNo="02";                        ;           data_sub19.accountManageNo="02";
        data19.differentAmount=-5;                      ;           data_sub19.differentAmount=-5;
        resDatalist.add(data19)                     ;           resDatalist.add(data_sub19)
        ;
        def data20 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub20 = new SettlementCollationOfficerDetailFile();
        data20.zenginAmount=null;                       ;           data_sub20.zenginAmount=null;
        data20.zenginManageNo="04";                     ;           data_sub20.zenginManageNo="04";
        data20.accountAmount=5;                     ;           data_sub20.accountAmount=5;
        data20.accountManageNo="02";                        ;           data_sub20.accountManageNo="02";
        data20.differentAmount=-5;                      ;           data_sub20.differentAmount=-5;
        resDatalist.add(data20)                     ;           resDatalist.add(data_sub20)
        ;
        def data21 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub21 = new SettlementCollationOfficerDetailFile();
        data21.zenginAmount=null;                       ;           data_sub21.zenginAmount=null;
        data21.zenginManageNo="05";                     ;           data_sub21.zenginManageNo="05";
        data21.accountAmount=5;                     ;           data_sub21.accountAmount=5;
        data21.accountManageNo="02";                        ;           data_sub21.accountManageNo="02";
        data21.differentAmount=-5;                      ;           data_sub21.differentAmount=-5;
        resDatalist.add(data21)                     ;           resDatalist.add(data_sub21)
        ;
        def data22 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub22 = new SettlementCollationOfficerDetailFile();
        data22.zenginAmount=null;                       ;           data_sub22.zenginAmount=null;
        data22.zenginManageNo="06";                     ;           data_sub22.zenginManageNo="06";
        data22.accountAmount=5;                     ;           data_sub22.accountAmount=5;
        data22.accountManageNo="02";                        ;           data_sub22.accountManageNo="02";
        data22.differentAmount=-5;                      ;           data_sub22.differentAmount=-5;
        resDatalist.add(data22)                     ;           resDatalist.add(data_sub22)
        ;
        def data23 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub23 = new SettlementCollationOfficerDetailFile();
        data23.zenginAmount=null;                       ;           data_sub23.zenginAmount=null;
        data23.zenginManageNo="07";                     ;           data_sub23.zenginManageNo="07";
        data23.accountAmount=5;                     ;           data_sub23.accountAmount=5;
        data23.accountManageNo="02";                        ;           data_sub23.accountManageNo="02";
        data23.differentAmount=-5;                      ;           data_sub23.differentAmount=-5;
        resDatalist.add(data23)                     ;           resDatalist.add(data_sub23)
        ;
        def data24 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub24 = new SettlementCollationOfficerDetailFile();
        data24.zenginAmount=null;                       ;           data_sub24.zenginAmount=null;
        data24.zenginManageNo="08";                     ;           data_sub24.zenginManageNo="08";
        data24.accountAmount=5;                     ;           data_sub24.accountAmount=5;
        data24.accountManageNo="02";                        ;           data_sub24.accountManageNo="02";
        data24.differentAmount=-5;                      ;           data_sub24.differentAmount=-5;
        resDatalist.add(data24)                     ;           resDatalist.add(data_sub24)
        ;
        def data25 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub25 = new SettlementCollationOfficerDetailFile();
        data25.zenginAmount=null;                       ;           data_sub25.zenginAmount=null;
        data25.zenginManageNo="09";                     ;           data_sub25.zenginManageNo="09";
        data25.accountAmount=5;                     ;           data_sub25.accountAmount=5;
        data25.accountManageNo="02";                        ;           data_sub25.accountManageNo="02";
        data25.differentAmount=-5;                      ;           data_sub25.differentAmount=-5;
        resDatalist.add(data25)                     ;           resDatalist.add(data_sub25)
        ;
        def data26 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub26 = new SettlementCollationOfficerDetailFile();
        data26.zenginAmount=null;                       ;           data_sub26.zenginAmount=null;
        data26.zenginManageNo="10";                     ;           data_sub26.zenginManageNo="10";
        data26.accountAmount=5;                     ;           data_sub26.accountAmount=5;
        data26.accountManageNo="02";                        ;           data_sub26.accountManageNo="02";
        data26.differentAmount=-5;                      ;           data_sub26.differentAmount=-5;
        resDatalist.add(data26)                     ;           resDatalist.add(data_sub26)
        ;
        def data27 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub27 = new SettlementCollationOfficerDetailFile();
        data27.zenginAmount=null;                       ;           data_sub27.zenginAmount=null;
        data27.zenginManageNo="11";                     ;           data_sub27.zenginManageNo="11";
        data27.accountAmount=5;                     ;           data_sub27.accountAmount=5;
        data27.accountManageNo="02";                        ;           data_sub27.accountManageNo="02";
        data27.differentAmount=-5;                      ;           data_sub27.differentAmount=-5;
        resDatalist.add(data27)                     ;           resDatalist.add(data_sub27)
        ;
        def data28 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub28 = new SettlementCollationOfficerDetailFile();
        data28.zenginAmount=null;                       ;           data_sub28.zenginAmount=null;
        data28.zenginManageNo="12";                     ;           data_sub28.zenginManageNo="12";
        data28.accountAmount=5;                     ;           data_sub28.accountAmount=5;
        data28.accountManageNo="02";                        ;           data_sub28.accountManageNo="02";
        data28.differentAmount=-5;                      ;           data_sub28.differentAmount=-5;
        resDatalist.add(data28)                     ;           resDatalist.add(data_sub28)
        ;
        def data29 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub29 = new SettlementCollationOfficerDetailFile();
        data29.zenginAmount=null;                       ;           data_sub29.zenginAmount=null;
        data29.zenginManageNo="13";                     ;           data_sub29.zenginManageNo="13";
        data29.accountAmount=5;                     ;           data_sub29.accountAmount=5;
        data29.accountManageNo="02";                        ;           data_sub29.accountManageNo="02";
        data29.differentAmount=-5;                      ;           data_sub29.differentAmount=-5;
        resDatalist.add(data29)                     ;           resDatalist.add(data_sub29)
        ;
        def data30 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub30 = new SettlementCollationOfficerDetailFile();
        data30.zenginAmount=null;                       ;           data_sub30.zenginAmount=null;
        data30.zenginManageNo="14";                     ;           data_sub30.zenginManageNo="14";
        data30.accountAmount=5;                     ;           data_sub30.accountAmount=5;
        data30.accountManageNo="02";                        ;           data_sub30.accountManageNo="02";
        data30.differentAmount=-5;                      ;           data_sub30.differentAmount=-5;
        resDatalist.add(data30)                     ;           resDatalist.add(data_sub30)
        ;
        def data31 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub31 = new SettlementCollationOfficerDetailFile();
        data31.zenginAmount=null;                       ;           data_sub31.zenginAmount=null;
        data31.zenginManageNo="14";                     ;           data_sub31.zenginManageNo="14";
        data31.accountAmount=5;                     ;           data_sub31.accountAmount=5;
        data31.accountManageNo="02";                        ;           data_sub31.accountManageNo="02";
        data31.differentAmount=-5;                      ;           data_sub31.differentAmount=-5;
        resDatalist.add(data31)                     ;           resDatalist.add(data_sub31)
        ;
        def data32 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub32 = new SettlementCollationOfficerDetailFile();
        data32.zenginAmount=null;                       ;           data_sub32.zenginAmount=null;
        data32.zenginManageNo=null;                     ;           data_sub32.zenginManageNo=null;
        data32.accountAmount=5;                     ;           data_sub32.accountAmount=5;
        data32.accountManageNo="02";                        ;           data_sub32.accountManageNo="02";
        data32.differentAmount=-5;                      ;           data_sub32.differentAmount=-5;
        resDatalist.add(data32)                     ;           resDatalist.add(data_sub32)
        ;
        def data33 = new SettlementCollationOfficerDetailFile();                        ;           def data_sub33 = new SettlementCollationOfficerDetailFile();
        data33.zenginAmount=null;                       ;           data_sub33.zenginAmount=null;
        data33.zenginManageNo=null;                     ;           data_sub33.zenginManageNo=null;
        data33.accountAmount=null;                      ;           data_sub33.accountAmount=null;
        data33.accountManageNo=null;                        ;           data_sub33.accountManageNo=null;
        data33.differentAmount=null;                        ;           data_sub33.differentAmount=null;
        resDatalist.add(data33)                     ;           resDatalist.add(data_sub33)


        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable<SettlementCollationOfficerDetailFile>)resDatalist))
        return reslist
    }




    public static class SettlementCollationImportLog{
        Collection<SettlementCollationFile> file;
        Collection<SettlementCollationDb> db;
    }


    String erroredData = "[\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024701\",\"communicationTypeCode\":\"4701\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24701}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024910\",\"communicationTypeCode\":\"4910\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24910}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00012154\",\"communicationTypeCode\":\"2154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":12154}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014201\",\"communicationTypeCode\":\"4201\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14201}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00012174\",\"communicationTypeCode\":\"2174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":12174}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014402\",\"communicationTypeCode\":\"4402\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14402}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014401\",\"communicationTypeCode\":\"4401\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14401}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00013101\",\"communicationTypeCode\":\"3101\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":13101}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024201\",\"communicationTypeCode\":\"4201\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24201}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024102\",\"communicationTypeCode\":\"4102\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24102}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024401\",\"communicationTypeCode\":\"4401\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24401}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014701\",\"communicationTypeCode\":\"4701\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14701}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024301\",\"communicationTypeCode\":\"4301\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24301}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00022174\",\"communicationTypeCode\":\"2174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":22174}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"eb247f0d-e6a0-4c57-a188-9e57a008af01\",\"managementNumber\":\"TEST1120300000000000000012\",\"amount\":8037}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024302\",\"communicationTypeCode\":\"4302\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24302}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00023101\",\"communicationTypeCode\":\"3101\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":23101}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024101\",\"communicationTypeCode\":\"4101\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24101}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024202\",\"communicationTypeCode\":\"4202\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24202}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"2ec319c1-84a2-47d6-bb50-6c40603322aa\",\"managementNumber\":\"zengin-o2020-0127012801808\",\"amount\":99999999}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014101\",\"communicationTypeCode\":\"4101\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14101}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024501\",\"communicationTypeCode\":\"4501\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24501}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014102\",\"communicationTypeCode\":\"4102\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14102}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024671\",\"communicationTypeCode\":\"4671\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24671}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014301\",\"communicationTypeCode\":\"4301\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14301}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014202\",\"communicationTypeCode\":\"4202\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14202}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024702\",\"communicationTypeCode\":\"4702\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24702}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014302\",\"communicationTypeCode\":\"4302\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14302}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014671\",\"communicationTypeCode\":\"4671\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14671}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00022154\",\"communicationTypeCode\":\"2154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":22154}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014910\",\"communicationTypeCode\":\"4910\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14910}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014702\",\"communicationTypeCode\":\"4702\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14702}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00014501\",\"communicationTypeCode\":\"4501\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":14501}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00024402\",\"communicationTypeCode\":\"4402\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":24402}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021082\",\"communicationTypeCode\":\"1082\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21082}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021041\",\"communicationTypeCode\":\"1041\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21041}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021154\",\"communicationTypeCode\":\"1154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21154},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021154\",\"communicationTypeCode\":\"1154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21154},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021154\",\"communicationTypeCode\":\"1154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21154}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021141\",\"communicationTypeCode\":\"1141\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21141},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021141\",\"communicationTypeCode\":\"1141\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21141}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021144\",\"communicationTypeCode\":\"1144\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21144},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021144\",\"communicationTypeCode\":\"1144\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21144}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021022\",\"communicationTypeCode\":\"1022\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21022}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021143\",\"communicationTypeCode\":\"1143\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21143},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021143\",\"communicationTypeCode\":\"1143\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21143}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021043\",\"communicationTypeCode\":\"1043\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21043}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021212\",\"communicationTypeCode\":\"1212\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21212},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021212\",\"communicationTypeCode\":\"1212\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21212}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021182\",\"communicationTypeCode\":\"1182\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21182}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021042\",\"communicationTypeCode\":\"1042\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21042}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021122\",\"communicationTypeCode\":\"1122\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21122},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021122\",\"communicationTypeCode\":\"1122\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21122},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021122\",\"communicationTypeCode\":\"1122\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21122}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021142\",\"communicationTypeCode\":\"1142\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21142},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021142\",\"communicationTypeCode\":\"1142\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21142}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021054\",\"communicationTypeCode\":\"1054\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21054}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021145\",\"communicationTypeCode\":\"1145\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21145},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021145\",\"communicationTypeCode\":\"1145\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21145}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021074\",\"communicationTypeCode\":\"1074\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21074}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021174\",\"communicationTypeCode\":\"1174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21174},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021174\",\"communicationTypeCode\":\"1174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21174},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021174\",\"communicationTypeCode\":\"1174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21174}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021272\",\"communicationTypeCode\":\"1272\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21272},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021272\",\"communicationTypeCode\":\"1272\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21272}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021146\",\"communicationTypeCode\":\"1146\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21146},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021146\",\"communicationTypeCode\":\"1146\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21146}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021046\",\"communicationTypeCode\":\"1046\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21046}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021045\",\"communicationTypeCode\":\"1045\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21045}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021271\",\"communicationTypeCode\":\"1271\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21271},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021271\",\"communicationTypeCode\":\"1271\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21271}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021044\",\"communicationTypeCode\":\"1044\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21044}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021211\",\"communicationTypeCode\":\"1211\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21211},{\"zenginProcessCode\":\"2\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00021211\",\"communicationTypeCode\":\"1211\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":21211}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"83bd6be7-e5ce-46d7-b6cc-d26cebddfb2e\",\"managementNumber\":\"XU6M11MRC6KP2FTB971SD1ZGK9\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"7dc88d61-d3a2-4e5c-846e-7d61da084f45\",\"managementNumber\":\"F33Z86OWOTD1IEGCYINNQPWJNF\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"a8665f3f-d6ea-4971-9aa3-de0e88f9f788\",\"managementNumber\":\"75C6BETCDZAKKCFC69CT6CEB9X\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011141\",\"communicationTypeCode\":\"1141\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11141},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011141\",\"communicationTypeCode\":\"1141\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11141}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"6fc25663-eac1-4645-988d-3c28c809689b\",\"managementNumber\":\"7CABOEAN41Z1LZBGS0FKC97092\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"5fad2106-8983-459c-a99a-39e6c0dc2b70\",\"managementNumber\":\"XTC2QNPIJ666V61725BPONZCXU\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"b466a4e1-6a6d-4c9a-8904-6b065d969c6c\",\"managementNumber\":\"U8YR5T4V9HQJ3U0JLPTDUL1K87\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011045\",\"communicationTypeCode\":\"1045\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11045}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"8fb2fbba-4fd5-42fe-96d8-36dc47d379a7\",\"managementNumber\":\"XQYB9J1B4LHYEQKWMODNUA1B9Y\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"4c3b6f40-e166-4adb-a876-77229c985ef8\",\"managementNumber\":\"DJBO14CDJR52S2MS55BA1DWPFZ\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011174\",\"communicationTypeCode\":\"1174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11174},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011174\",\"communicationTypeCode\":\"1174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11174},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011174\",\"communicationTypeCode\":\"1174\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11174}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"086adaec-ce7f-4ea7-8949-3df912e9d351\",\"managementNumber\":\"82RQW0TEJKBG2XT5ZLATSZ2HF2\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011046\",\"communicationTypeCode\":\"1046\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11046}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"08afe884-807b-447d-b965-5fc57771e3a9\",\"managementNumber\":\"FR6CTF8355NO7JFP7U03R4N0YP\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"3fcec323-df0f-450a-b77e-572cca38867b\",\"managementNumber\":\"SP7M7DQGD2FCHQLVHSHW4RNV4L\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"ce04b77c-b034-45e8-8b6a-1c85598fe6b7\",\"managementNumber\":\"MZOQGQFOTBMTWIZVVON0Q5NYGF\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011041\",\"communicationTypeCode\":\"1041\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11041}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011043\",\"communicationTypeCode\":\"1043\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11043}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011271\",\"communicationTypeCode\":\"1271\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11271},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011271\",\"communicationTypeCode\":\"1271\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11271}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"55fc3947-afaa-4ab8-a768-f9101f3d1c22\",\"managementNumber\":\"2KI9IUWSSSU1V4XLAPT2G46TFX\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"a0e0d61b-1cad-4b34-8885-d597d7acd8b4\",\"managementNumber\":\"GVGGCY4JJYS0JBV0IMMHG7W2CW\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"0ca2116f-10d2-4556-8ce2-c8a0897328e3\",\"managementNumber\":\"UIKBBIYFN3ZIF1KNR00PN20KCY\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"12ee2b89-11b7-447c-824f-0a884ada8465\",\"managementNumber\":\"N1YY8QZ8705B4I9A6STRIIM7N9\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011154\",\"communicationTypeCode\":\"1154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11154},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011154\",\"communicationTypeCode\":\"1154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11154},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011154\",\"communicationTypeCode\":\"1154\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11154}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"adfc1e08-cb55-4c3e-b83d-bd548bad955c\",\"managementNumber\":\"1580107447607586487OVXKURW\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011054\",\"communicationTypeCode\":\"1054\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11054}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011022\",\"communicationTypeCode\":\"1022\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11022}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"c349c289-7b1d-4f64-b1f2-fdc29c8e09e0\",\"managementNumber\":\"6N0L50Y5G29DT4MRN0AFX62GVE\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"023455f7-5727-4ffb-a509-43f68db51de1\",\"managementNumber\":\"IT7PR88RXX0IFJNID39WGFGNXQ\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"53095d40-f8f6-4b86-829a-591b0dee6758\",\"managementNumber\":\"1LX5YFDY9KYE0Q2SLGSIUFC5R6\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011143\",\"communicationTypeCode\":\"1143\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11143},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011143\",\"communicationTypeCode\":\"1143\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11143}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011211\",\"communicationTypeCode\":\"1211\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11211},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011211\",\"communicationTypeCode\":\"1211\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11211}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"9d7846ce-e9e8-474a-87bb-912322ed9206\",\"managementNumber\":\"AIKR0F3XKPO1R7AVQNVNG5EEUL\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"8b2af33b-717b-4846-8246-f6525bcb7d47\",\"managementNumber\":\"KMZUUHPKMO3B8DRD6CYCRT1WOR\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"c1d16059-110e-4342-bca7-a0b7628c6e59\",\"managementNumber\":\"TI06K06ZP87DA0C9YKAGRDVK8C\",\"amount\":99999999}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"7ad5f0ef-76cf-49c1-bee6-308756077525\",\"managementNumber\":\"D8MT7H2DEC1YOXTTEFCE82X2Z9\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"8551b2a8-331e-4888-b64f-9d27236feab3\",\"managementNumber\":\"PWDVPYDTXQRF4CTIKBDU7TH20P\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"4a7ca03e-4815-459a-b396-8ba654afd421\",\"managementNumber\":\"N6XEEJ8GRKQVIO13B1K5D4OJ0R\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"12cecfb0-e9d1-48a1-bbdc-359cfbf47267\",\"managementNumber\":\"XYVYQLV3WNWA1PDMKNW9MWT8MH\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"f9e47aaf-9450-4240-b6e0-985cdb0298b7\",\"managementNumber\":\"1BF9J7PFX4LV1GRL8PPL3QTHPD\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011182\",\"communicationTypeCode\":\"1182\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11182}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011122\",\"communicationTypeCode\":\"1122\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11122},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011122\",\"communicationTypeCode\":\"1122\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11122},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011122\",\"communicationTypeCode\":\"1122\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11122}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011146\",\"communicationTypeCode\":\"1146\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11146},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011146\",\"communicationTypeCode\":\"1146\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11146}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011044\",\"communicationTypeCode\":\"1044\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11044}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"c8212518-9367-40f5-b174-c1bebf9f3e37\",\"managementNumber\":\"KZKHOB48CX1QBH3USGNYZVH9UX\",\"amount\":5577}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011042\",\"communicationTypeCode\":\"1042\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11042}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011145\",\"communicationTypeCode\":\"1145\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11145},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011145\",\"communicationTypeCode\":\"1145\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11145}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"b28be69b-b4fa-4d5d-a3cc-572a908c7b73\",\"managementNumber\":\"DKVQL3MKTKZ3QO4B8Q1PG8YWZ3\",\"amount\":1000160}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"5a98eef8-5bdf-4a93-a2b2-c3183e272cd2\",\"managementNumber\":\"9G8SELPAWX0KPSY1CWAFHZPQFC\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"835d5131-f728-42f6-90ee-e039cddc757f\",\"managementNumber\":\"JUIOGM425C66OCRCMQP26U3UFI\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"55d14a3c-9df0-4c2d-bcf4-ce760c8e659f\",\"managementNumber\":\"TTS7V2MR11DOM9S4I3RPBWQW1G\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011212\",\"communicationTypeCode\":\"1212\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11212},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011212\",\"communicationTypeCode\":\"1212\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11212}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011272\",\"communicationTypeCode\":\"1272\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11272},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011272\",\"communicationTypeCode\":\"1272\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11272}], \"db\":[] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011144\",\"communicationTypeCode\":\"1144\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11144},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011144\",\"communicationTypeCode\":\"1144\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11144}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"08f0395e-e39c-4550-83cd-85f6efb08c70\",\"managementNumber\":\"LJH0H85WOZTM03KYR7LWRSYJOJ\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"83f0c148-2bd0-437e-9f87-253055b0f78a\",\"managementNumber\":\"0NUMFTJ0I6YZUFN5EAHRNBWUQ3\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"08d967c9-4612-473c-934e-211332c034b0\",\"managementNumber\":\"YOE5V7LIXFC48YI8V6DLW2H46I\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011082\",\"communicationTypeCode\":\"1082\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11082}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"fed713f3-f8b8-4b82-94cc-de61d4a010f5\",\"managementNumber\":\"UL6LHQH5V0LB5PWFES91Q5WZIV\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011142\",\"communicationTypeCode\":\"1142\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11142},{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011142\",\"communicationTypeCode\":\"1142\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11142}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"100258cc-abff-4c2f-8bcc-87412c357b9a\",\"managementNumber\":\"721BMJ3L6ZXA6BO8UAOOM3KYV9\",\"amount\":1000}] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"d60dfb17-473b-4ec7-9890-08a8a5a3b371\",\"managementNumber\":\"T2VIXJ0SFH3E1FZP29X1P1FQMD\",\"amount\":1000}] },\n"+
    "{\"file\":[{\"zenginProcessCode\":\"1\",\"managementNumber\":\"TAIGAI0ITA0DBT007O00011074\",\"communicationTypeCode\":\"1074\",\"transferScheduledDate\":\"20200128\",\"coreMoreTimeType\":\"1\",\"largeValueTransactionFlag\":\"0\",\"amount\":11074}], \"db\":[] },\n"+
    "{\"file\":[], \"db\":[{\"transactionSlipId\":\"2ba330b6-a56c-434c-ab36-ea827393641b\",\"managementNumber\":\"4C38CN68BFVZ3X9906CVJ7OV2V\",\"amount\":1000}] },\n"+
    "]\n"




    @Unroll
    def "Transformが正常終了.ITaでエラーが見つかったデータセット"() {
        given: "Pipeline実行&Ouput確認"

        java.lang.reflect.Type collectionType = new TypeToken<Collection<SettlementCollationImportLog>>() {}.getType();
        List<SettlementCollationImportLog> inputs = new Gson().fromJson(erroredData, collectionType);
        List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> inputData = new ArrayList<>();

        List<SettlementCollationOfficerDetailFile> list = new ArrayList<>()
        for(SettlementCollationImportLog input : inputs) {
            if(input == null) continue;
            if(input.file.isEmpty()) {
                list.add(new SettlementCollationOfficerDetailFile(null,input.db.getAt(0)))
            }else if(input.db.isEmpty()) {
                list.add(new SettlementCollationOfficerDetailFile(input.file.getAt(0),null))
            }else {
                list.add(new SettlementCollationOfficerDetailFile(input.file.getAt(0),input.db.getAt(0)))
            }
        }
        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        inputData.add(KV.of(keys, (Iterable<SettlementCollationOfficerDetailFile>)list))

        //        Collections.shuffle(inputData)
        PCollection<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> input = p.apply(Create.of(inputData))
        PCollection<KV<List<String>, Map<String, List<DataClassBase>>>> output = input.apply(ParDo.of(function))

        //        PAssert.that(output)
        //                .containsInAnyOrder(resData);

        expect:
        p.run()
    }

}
