package com.neobank.fcore.demanddeposit.transform.grpc


import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationResisterPendingFnテスト")
public class SettlementCollationResisterPendingFnSpec extends Specification implements Serializable {

    //    grpcはモック化が困難な為、実行で確認する
    //    日付検証は上述と合わせてパイプラインの出力検証が困難な為、実行で確認する
}
