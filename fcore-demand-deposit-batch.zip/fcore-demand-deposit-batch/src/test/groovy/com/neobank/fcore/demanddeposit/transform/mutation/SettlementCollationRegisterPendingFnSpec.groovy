package com.neobank.fcore.demanddeposit.transform.mutation


import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationResisterPendingFnテスト")
public class SettlementCollationResisterPendingFnSpec extends Specification implements Serializable {

    //    grpcはモック化が困難な為、実行で確認する
    //    日付検証は上述と合わせてパイプラインの出力検証が困難な為、実行で確認する

    //    private SettlementCollationFile createSettlementCollationFile() {
    //        SettlementCollationFile entity = new SettlementCollationFile();
    //        entity.zenginProcessCode = ""
    //        entity.managementNumber = ""
    //        entity.communicationTypeCode = "1275"
    //        entity.transferScheduledDate = "20190101"
    //        entity.amount = 0L
    //        entity.coreMoreTimeType = ""
    //        entity.largeValueTransactionFlag = ""
    //        return entity;
    //    }
    //
    //    //Mocks
    //    def String processDate = ""
    //    def String databaseUserId = ""
    //
    //    // テスト用Pipline
    //    @Rule public transient TestPipeline p = TestPipeline.create()
    //
    //    @Shared
    //    def SettlementCollationOptions options = {
    //        def op = PipelineOptionsFactory.as(SettlementCollationOptions.class)
    //        def ctx = new HashMap<String, Object>()
    //        ctx.put("pipeline.operationUserId","hogehoge")
    //        op.setPipelineContext(ctx)
    //        return op
    //    }()
    //    // Mocking
    //    def SpannerDriver spannerDriver = Mockito.mock(SpannerDriver, Mockito.withSettings().serializable());
    //    def Map<String, Object> ctx = options.getPipelineContext();
    //    def SettlementCollationStatementBuilder settlementCollationStatementBuilder = Mockito.mock(SettlementCollationStatementBuilder, Mockito.withSettings().serializable());
    //    def DatabaseClient dbClient= Mockito.mock(DatabaseClient, Mockito.withSettings().serializable())
    //    def ReadContext readContext = Mockito.mock(ReadContext, Mockito.withSettings().serializable())
    //    def ReadOnlyTransaction readTx = Mockito.mock(ReadOnlyTransaction, Mockito.withSettings().serializable())
    //    def ResultSet resultSet = Mockito.mock(ResultSet , Mockito.withSettings().serializable())
    //    def ResultSet resBeforeProcessedBank = Mockito.mock(ResultSet , Mockito.withSettings().serializable())
    //    def ResultSet resBeforeProcessedBranch = Mockito.mock(ResultSet , Mockito.withSettings().serializable())
    //    def Spanner spanner = Mockito.mock(Spanner , Mockito.withSettings().serializable())
    //    def ProcessContext processContext = Mockito.mock(ProcessContext , Mockito.withSettings().serializable())
    //    def GrpcConnector grpcConnector = Mockito.mock(GrpcConnector , Mockito.withSettings().serializable())
    //
    //    def dateTimeUtils;
    //
    //    @Subject
    //    def SettlementCollationResisterPendingFn function
    //
    //
    //    def setupSpec() {
    //        //テストクラス内で一度きりの初期化
    //    }
    //
    //    def setup() {
    //        //テストケースごとの初期化
    //        def localOptions = Stub(DefaultOptions)
    //        Map<String, Object> localCtx = new HashMap()
    //        localCtx.put("dataflow.timezone.zoneid", "Asia/Tokyo")
    //        localOptions.getPipelineContext() >> localCtx
    //        dateTimeUtils = new DateTimeUtils(localOptions)
    //        Mockito.when(spannerDriver.createDatabaseClient(Mockito.any())).thenReturn(dbClient);
    //        Mockito.when(dbClient.executePartitionedUpdate(Mockito.any())).thenReturn(0L);
    //        Mockito.when(dbClient.readOnlyTransaction()).thenReturn(readTx);
    //        Mockito.when(readTx.executeQuery(Mockito.any())).thenReturn(resultSet);
    //        Mockito.when(spannerDriver.createService()).thenReturn(spanner);
    //        Mockito.doNothing().when(spannerDriver).write(Mockito.eq(dbClient) as DatabaseClient, Mockito.any(Consumer));
    //        function = new SettlementCollationResisterPendingFn(spannerDriver, grpcConnector, dateTimeUtils, StaticValueProvider.of("20190102"))
    //
    //        List<String> workDaysUntilNext5 = new ArrayList<>();
    //        workDaysUntilNext5.add("20190101");
    //        workDaysUntilNext5.add("20190102");
    //        workDaysUntilNext5.add("20190103");
    //        workDaysUntilNext5.add("20190104");
    //        workDaysUntilNext5.add("20190105");
    //        workDaysUntilNext5.add("20190106");
    //        function.workDaysUntilNext5 = workDaysUntilNext5
    //    }
    //
    //
    //    def "Transformが正常完了"() {
    //        given: "準備"
    //        SettlementCollationBase inputValue = createSettlementCollationFile()
    //        KV<List<String>, SettlementCollationBase> input = KV.of(new ArrayList<>(), inputValue)
    //        SettlementCollationPending result = new SettlementCollationPending(SettlementCollationPipeline.DATABASE_USER_ID, (SettlementCollationFile) inputValue, dateTimeUtils)
    //
    //        expect:
    //        function.processElement(input, processContext) == null
    //    }


}
