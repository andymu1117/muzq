package com.neobank.fcore.demanddeposit.transform


import java.nio.charset.StandardCharsets

import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.Sum
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollectionTuple
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.utils.Conversion

@Title("SettlementCollationClassifyFileRecordsFnテスト")
public class SettlementCollationClassifyFileRecordsFnSpec extends Specification implements Serializable {

    // ファイル読み込み用
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

    // ファイルデータ振り分け用
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<Integer> fileOutboundTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileOutboundNotTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundNotTransferNumTag = new TupleTag<Integer>() {};

    // 判定結果の出力を分ける為のタグ
    TupleTag<Integer> errorNumTag = new TupleTag<Integer>() {};

    List<String> beforeSettlementList =  SettlementCollationData.getBeforeSettlementList();

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationClassifyFileRecordsFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        function = new SettlementCollationClassifyFileRecordsFn(fileOutboundTransferTag, fileOutboundNotTransferTag, fileInboundTransferTag, fileInboundNotTransferTag, fileOutboundTransferNumTag, fileOutboundNotTransferNumTag, fileInboundTransferNumTag, fileInboundNotTransferNumTag)
    }

    def "Transformが正常完了"() {
        given:
        List<String> list = new ArrayList()

        System.out.println(SettlementCollationData.getAllCommunicationInput());

        PCollectionTuple output = p
                .apply(Create.of(SettlementCollationData.getAllCommunicationInput().getBytes()))
                .apply(ParDo.of(new SettlementCollationByteColumnSeparatorFn(smallTodayDataTag, smallFutureDataTag, nextWorkDay, targetDate)).withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag)).withSideInputs(nextWorkDay))
                .get(smallTodayDataTag)
                // 上述のパイプラインはテスト済みとして実行
                .apply("classify file", ParDo.of(function)
                .withOutputTags(fileOutboundTransferTag, TupleTagList.of(fileOutboundNotTransferTag)
                .and(fileInboundTransferTag)
                .and(fileInboundNotTransferTag)
                .and(fileOutboundTransferNumTag)
                .and(fileOutboundNotTransferNumTag)
                .and(fileInboundTransferNumTag)
                .and(fileInboundNotTransferNumTag)));

        List<SettlementCollationBase> resultsOutboundTransfer = new ArrayList<>();
        List<SettlementCollationBase> resultsOutboundNotTransfer = new ArrayList<>();
        List<SettlementCollationBase> resultsInboundTransfer = new ArrayList<>();
        List<SettlementCollationBase> resultsInboundNotTransfer = new ArrayList<>();
        Integer resultsOutboundTransferNum = 0;
        Integer resultsOutboundNotTransferNum = 0;
        Integer resultsInboundTransferNum = 0;
        Integer resultsInboundNotTransferNum = 0;
        int index = 0;
        for(List<String> line : Conversion.separateBytesBySemicolonAndBreakLine(SettlementCollationData.getAllCommunicationInput().getBytes(StandardCharsets.UTF_8))) {
            if(line.size() != 7) continue;
            switch(index) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsInboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsInboundNotTransferNum++
                    break;

                case 5:
                case 6:
                case 7:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsOutboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsOutboundNotTransferNum++
                    break;

                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsOutboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsOutboundNotTransferNum++
                    break;

                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 58:
                case 59:
                case 60:
                case 61:
                case 62:
                case 63:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsOutboundTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsOutboundTransferNum++
                    break;

                case 64:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsOutboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsOutboundNotTransferNum++
                    break;

                case 65:
                case 66:
                case 67:
                case 68:
                case 69:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsOutboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsOutboundNotTransferNum++
                    break;

                case 70:
                case 71:
                case 72:
                case 73:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsInboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsInboundNotTransferNum++
                    break;

                case 74:
                case 75:
                case 76:
                case 77:
                case 78:
                case 79:
                case 80:
                case 81:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsInboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsInboundNotTransferNum++
                    break;

                case 82:
                case 83:
                case 84:
                case 85:
                case 86:
                case 87:
                case 88:
                case 89:
                case 90:
                case 91:
                case 92:
                case 93:
                case 94:
                case 95:
                case 96:
                case 97:
                case 98:
                case 99:
                case 100:
                case 101:
                case 102:
                case 103:
                case 104:
                case 105:
                case 106:
                case 107:
                case 108:
                case 109:
                case 110:
                case 111:
                case 112:
                case 113:
                case 114:
                case 115:
                case 116:
                case 117:
                case 118:
                case 119:
                case 120:
                case 121:
                case 122:
                case 123:
                case 124:
                case 125:
                case 126:
                case 127:
                case 128:
                case 129:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsInboundTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsInboundTransferNum++
                    break;

                case 130:
                    def result = new SettlementCollationFile();
                    result.zenginProcessCode = line.get(0);
                    result.managementNumber = line.get(1);
                    result.communicationTypeCode = line.get(2);
                    result.transferScheduledDate = line.get(3);
                    result.amount = Long.valueOf(line.get(4));
                    result.coreMoreTimeType = line.get(5);
                    result.largeValueTransactionFlag = line.get(6);
                    def key = new ArrayList<>()
                    key.add(result.managementNumber)
                    def resultKv = KV.of(key, (SettlementCollationBase)result)
                    resultsInboundNotTransfer.add(resultKv)
                    if(beforeSettlementList.contains(line.get(2)))resultsInboundNotTransferNum++
                    break;
            }
            index++;
        }

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。

        PAssert.that(output.get(fileOutboundTransferTag))
                .containsInAnyOrder(resultsOutboundTransfer);
        PAssert.that(output.get(fileOutboundNotTransferTag))
                .containsInAnyOrder(resultsOutboundNotTransfer);
        PAssert.that(output.get(fileInboundTransferTag))
                .containsInAnyOrder(resultsInboundTransfer);
        PAssert.that(output.get(fileInboundNotTransferTag))
                .containsInAnyOrder(resultsInboundNotTransfer);

        PAssert.that(output.get(fileOutboundTransferNumTag)
                .apply("sum fileOutboundTransferNumTag",Sum.integersGlobally()))
                .containsInAnyOrder(resultsOutboundTransferNum);
        PAssert.that(output.get(fileOutboundNotTransferNumTag)
                .apply("sum fileOutboundNotTransferNumTag",Sum.integersGlobally()))
                .containsInAnyOrder(resultsOutboundNotTransferNum);
        PAssert.that(output.get(fileInboundTransferNumTag)
                .apply("sum fileInboundTransferNumTag",Sum.integersGlobally()))
                .containsInAnyOrder(resultsInboundTransferNum);
        PAssert.that(output.get(fileInboundNotTransferNumTag)
                .apply("sum fileInboundNotTransferNumTag",Sum.integersGlobally()))
                .containsInAnyOrder(resultsInboundNotTransferNum);

        expect:
        // Pipelineを実行する。
        p.run();
    }
}
