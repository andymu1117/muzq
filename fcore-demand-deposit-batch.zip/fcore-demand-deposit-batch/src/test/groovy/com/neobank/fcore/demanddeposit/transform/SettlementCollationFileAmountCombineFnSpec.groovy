package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.coders.KvCoder
import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Combine
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile

@Title("SettlementCollationClassifyFileRecordsFnテスト")
public class SettlementCollationFileAmountCombineFnSpec extends Specification implements Serializable {

    // ファイル読み込み用
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

    // ファイルデータ振り分け用
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<Integer> fileOutboundTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileOutboundNotTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundNotTransferNumTag = new TupleTag<Integer>() {};

    // 判定結果の出力を分ける為のタグ
    TupleTag<Integer> errorNumTag = new TupleTag<Integer>() {};

    List<String> beforeSettlementList =  SettlementCollationData.getBeforeSettlementList();

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationFileAmountCombineFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        function = new SettlementCollationFileAmountCombineFn(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode())
    }

    @Unroll
    def "Transformが正常完了.#caseName"() {
        given:
        List<String> list = new ArrayList()

        SettlementCollationFile inputData1 = new SettlementCollationFile()
        inputData1.amount = input1Amount
        List<String> keys1 = new ArrayList<>();
        keys1.add("");
        KV<List<String>, SettlementCollationFile> input1 = KV.of(keys1,inputData1);

        SettlementCollationFile inputData2 = new SettlementCollationFile()
        inputData2.amount = input2Amount
        List<String> keys2 = new ArrayList<>();
        keys2.add("");
        KV<List<String>, SettlementCollationFile> input2 = KV.of(keys2,inputData2);

        SettlementCollationFile inputData3 = new SettlementCollationFile()
        inputData3.amount = input3Amount
        List<String> keys3 = new ArrayList<>();
        keys3.add("");
        KV<List<String>, SettlementCollationFile> input3 = KV.of(keys3,inputData3);

        PCollection<KV<List<String>, SettlementCollationFile>> output = p
                .apply(Create.of([input1, input2, input3]))
                .setCoder(KvCoder.of(SerializableCoder.of(List.class), SerializableCoder.of(SettlementCollationBase.class)))
                .apply("summarize",Combine.globally(function));

        SettlementCollationFile result = new SettlementCollationFile()
        result.setAmount(resultAmount)
        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_INBOUND.getCode());

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。

        PAssert.that(output)
                .containsInAnyOrder(KV.of(keys,result));

        expect:
        // Pipelineを実行する。
        p.run();

        where:
        caseName | input1Amount | input2Amount | input3Amount | resultAmount
        "最大値" | 333333333333333333 | 333333333333333333 | 333333333333333333 | 999999999999999999
        "最大桁" | 333333333333333333 | 333333333333333332 | 333333333333333331 | 999999999999999996
        "0" | 0 | 0 | 0 | 0
    }
}
