package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.coders.KvCoder
import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionView
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile

@Title("SettlementCollationConvertForCallApiFnテスト")
public class SettlementCollationConvertForCallApiFnSpec extends Specification implements Serializable {

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationConvertForCallApiFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        function = new SettlementCollationConvertForCallApiFn()
    }

    def "Transformが正常完了"() {
        given:
        List<String> list = new ArrayList()

        SettlementCollationFile result = new SettlementCollationFile()
        result.zenginProcessCode = "1"
        result.managementNumber = "2"
        result.communicationTypeCode = "1275"
        result.transferScheduledDate = "20190102"
        result.amount = 5
        result.coreMoreTimeType = "6"
        result.largeValueTransactionFlag = "0"
        List<String> keys = new ArrayList<>();
        keys.add(result.managementNumber);
        KV<List<String>, SettlementCollationFile> expect = KV.of(keys,result);

        // ↓こちらは前営業日レコードではないのでフィルタされる
        SettlementCollationFile removeResult = new SettlementCollationFile()
        removeResult.zenginProcessCode = "1"
        removeResult.managementNumber = "2"
        removeResult.communicationTypeCode = "1022"
        removeResult.transferScheduledDate = "20190102"
        removeResult.amount = 5
        removeResult.coreMoreTimeType = "6"
        removeResult.largeValueTransactionFlag = "0"
        List<String> removeKeys = new ArrayList<>();
        removeKeys.add(removeResult.managementNumber);

        PCollection<KV<List<String>, SettlementCollationFile>> output = p
                .apply(Create.of([KV.of(keys, (SettlementCollationBase)result), KV.of(removeKeys, (SettlementCollationBase)removeResult)]))
                .setCoder(KvCoder.of(SerializableCoder.of(List.class), SerializableCoder.of(SettlementCollationBase.class)))
                .apply(ParDo.of(function))
        ;

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。
        PAssert.that(output)
                .containsInAnyOrder(expect);

        expect:
        // Pipelineを実行する。
        p.run();
    }
}
