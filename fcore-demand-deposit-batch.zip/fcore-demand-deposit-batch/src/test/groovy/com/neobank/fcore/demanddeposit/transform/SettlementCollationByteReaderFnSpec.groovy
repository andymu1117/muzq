package com.neobank.fcore.demanddeposit.transform

import spock.lang.Specification
import spock.lang.Title

@Title("SettlementCollationByteReaderFnテスト")
class SettlementCollationByteReaderFnSpec  extends Specification implements Serializable {
    // ファイル操作を行うため、パイプラインを実行させて確認する。
}


