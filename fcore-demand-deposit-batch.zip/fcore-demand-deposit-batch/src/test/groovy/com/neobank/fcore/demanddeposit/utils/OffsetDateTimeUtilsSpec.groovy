package com.neobank.fcore.demanddeposit.utils

import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeParseException

import org.apache.beam.sdk.testing.TestPipeline
import spock.lang.Specification
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.pipeline.options.AccrualRegularCreateOptions

class OffsetDateTimeUtilsSpec extends Specification{

    def offsetDateTimeUtils = new OffsetDateTimeUtils(TestPipeline.testingPipelineOptions().as(AccrualRegularCreateOptions.class))

    def "特定書式(yyyyMMdd)の日付文字列をLocalDateに変換するメソッドは正常に実行する"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.parserIso8601WithoutHyphenToLocalDate(input)

        then: "実行結果が成功であることを確認"
        expectedResult ==  actualResult

        where: "テストデータ準備"

        input      | expectedResult
        "20191020" | new LocalDate(2019, 10, 20)
    }

    @Unroll
    def "特定書式(yyyyMMdd)の日付文字列をLocalDateに変換するメソッドは異常が発生する(#caseName)"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.parserIso8601WithoutHyphenToLocalDate(input)

        then: "実行結果が異常をスローすることを確認"
        thrown(expectedException)

        where: "テストデータ準備"

        caseName                         | input           | expectedException
        "日付文字列のフォーマットが不正" | "2019-10-20123" | DateTimeParseException
        "日付文字列をnullとして入力する" | null            | NullPointerException
    }

    def "OffsetDateTimeを特定書式(yyyyMMdd)の日付に変換するメソッドは正常に実行する"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffetDateTimeToIso8601WithoutHyphen(input)

        then: "実行結果が成功であることを確認"
        expectedResult == actualResult

        where: "テストデータ準備"
        input                                                           | expectedResult
        OffsetDateTime.of(2020, 1, 11, 12, 0, 0, 0, ZoneOffset.of('Z')) | "20200111"
    }

    @Unroll
    def "OffsetDateTimeを特定書式(yyyyMMdd)の日付に変換するメソッドは異常が発生する(#caseName)"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffetDateTimeToIso8601WithoutHyphen(input)

        then: "実行結果が異常をスローすることを確認"
        thrown(expectedException)

        where: "テストデータ準備"

        caseName                                     | input           | expectedException
        "日付（OffsetDateTime）をnullとして入力する" | null            | NullPointerException
    }

    def "OffsetDateTimeを特定書式(yyyy-MM-dd)の日付に変換するメソッドは正常に実行する"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffsetDateTimeToIso8601(input)

        then: "実行結果が成功であることを確認"
        expectedResult == actualResult

        where: "テストデータ準備"
        input                                                           | expectedResult
        OffsetDateTime.of(2020, 1, 11, 12, 0, 0, 0, ZoneOffset.of('Z')) | "2020-01-11"
    }

    @Unroll
    def "OffsetDateTimeを特定書式(yyyy-MM-dd)の日付に変換するメソッドは異常が発生する(#caseName)"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffsetDateTimeToIso8601(input)

        then: "実行結果が異常をスローすることを確認"
        thrown(expectedException)

        where: "テストデータ準備"

        caseName                                     | input           | expectedException
        "日付（OffsetDateTime）をnullとして入力する" | null            | NullPointerException
    }

    def "OffsetDateTimeを今日の最後の時間のStringに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換するメソッドは正常に実行する"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffsetDateTimeAsMaxTimeString(input)

        then: "実行結果が成功であることを確認"
        expectedResult == actualResult

        where: "テストデータ準備"
        input                                                              | expectedResult
        OffsetDateTime.of(2020, 1, 11, 12, 0, 0, 0, ZoneOffset.ofHours(9)) | "2020-01-11T23:59:59.999999999+09:00"
    }

    @Unroll
    def "OffsetDateTimeを今日の最後の時間のStringに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換するメソッドは異常が発生する(#caseName)"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffsetDateTimeAsMaxTimeString(input)

        then: "実行結果が異常をスローすることを確認"
        thrown(expectedException)

        where: "テストデータ準備"

        caseName                                     | input           | expectedException
        "日付（OffsetDateTime）をnullとして入力する" | null            | NullPointerException
    }

    def "dateを今日の最後の時間のOffsetDateTimeに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換するメソッドは正常に実行する"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.parserStringDateAsMaxOffsetTime(input)

        then: "実行結果が成功であることを確認"
        expectedResult == actualResult

        where: "テストデータ準備"
        input        | expectedResult
        "2020-01-11" | OffsetDateTime.of(2020, 1, 11, 23, 59, 59, 999999999, ZoneOffset.ofHours(9))
    }

    @Unroll
    def "dateを今日の最後の時間のOffsetDateTimeに変更する、そして特定書式(yyyy-MM-ddT23:59:59.999999999+Zone)の日付文字列に変換するメソッドは異常が発生する(#caseName)"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.parserStringDateAsMaxOffsetTime(input)

        then: "実行結果が異常をスローすることを確認"
        thrown(expectedException)

        where: "テストデータ準備"

        caseName                             | input           | expectedException
        "日付文字列のフォーマットが不正"     | "2019-10-20123" | DateTimeParseException
        "日付（String）をnullとして入力する" | null            | NullPointerException
    }

    def "OffsetDateTimeを今日の最初の時間のZonedDateTimeに変更する、そして特定書式(yyyy-MM-ddT00:00:00+Zone)の日付文字列に変換するメソッドは正常に実行する"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffsetDateTimeAsMinTimeString(input)

        then: "実行結果が成功であることを確認"
        expectedResult == actualResult

        where: "テストデータ準備"
        input                                                             | expectedResult
        OffsetDateTime.of(2020, 1, 11, 0, 0, 0, 0, ZoneOffset.ofHours(9)) | "2020-01-11T00:00:00+09:00"
    }

    @Unroll
    def "OffsetDateTimeを今日の最初の時間のZonedDateTimeに変更する、そして特定書式(yyyy-MM-ddT00:00:00+Zone)の日付文字列に変換するメソッドは異常が発生する(#caseName)"() {

        when: "変換メソッドを実行"
        def actualResult = offsetDateTimeUtils.formatOffsetDateTimeAsMinTimeString(input)

        then: "実行結果が異常をスローすることを確認"
        thrown(expectedException)

        where: "テストデータ準備"

        caseName                                     | input           | expectedException
        "日付（OffsetDateTime）をnullとして入力する" | null            | NullPointerException
    }

    @Unroll
    def "特定書式(yyyy-MM-dd)の日付文字列であるかをバリテーションするメソッド(#caseName)"() {

        when: "バリテーション実行"
        def actualResult = offsetDateTimeUtils.checkIso8601DateFormat(input)

        then: "実行結果を確認"
        actualResult == expectedResult

        where:"テストデータ準備"

        caseName                                             | input        | expectedResult
        "チェックNG：対象日付がNULLの場合"                   | null         | false
        "チェックNG：対象日付のフォーマットが不正である場合" | "2019-11aa"  | false
        "チェックOK：対象日付のフォーマットが正しい場合"     | "2019-11-23" | true
    }

    @Unroll
    def "処理対象日付が未来日ではないかをバリテーションするメソッド(#caseName)"() {

        when: "バリテーション実行"
        def actualResult = offsetDateTimeUtils.checkDateIsNotFutureDay(input)

        then: "実行結果を確認"
        actualResult == expectedResult

        where:"テストデーター準備"

        caseName                                             | input        | expectedResult
        "チェックOK：対象日付がNULLの場合"                   | null         | false
        "チェックOK：対象日付のフォーマットが不正である場合" | "2019-11aa"  | false
        "チェックOK：対象日付が未来日でない場合"             | "2019-11-21" | true
        "チェックNG：対象日付が未来日である場合"             | "2099-11-23" | false
    }
}
