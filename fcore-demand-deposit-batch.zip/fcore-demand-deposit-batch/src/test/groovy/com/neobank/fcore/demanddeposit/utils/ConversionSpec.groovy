package com.neobank.fcore.demanddeposit.utils

import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat

import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.accenture.mainri.core.date.DateTimeUtils
import com.accenture.mainri.core.pipeline.options.DefaultOptions

import com.neobank.fcore.demanddeposit.exception.SystemFailureException

@Title("Conversionテスト")
class ConversionSpec extends Specification {
    private static final String STR_1000_BYTES = "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "
    private static final String STR_100_BYTES = "                                                                                                    "
    private static final String STR_10_BYTES = "          "
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    DateTimeUtils dateTimeUtils;

    def setup() {
        def options = Stub(DefaultOptions)
        Map<String, Object> ctx = new HashMap()
        ctx.put("dataflow.timezone.zoneid", "Asia/Tokyo")
        options.getPipelineContext() >> ctx
        dateTimeUtils = new DateTimeUtils(options)
    }

    @Unroll
    def "byteToString.#caseName"() {
        given:
        byte[] target = input

        expect:
        expect == Conversion.byteToString(target)

        where:
        caseName | input | expect
        "inputBlank" | "".getBytes(StandardCharsets.UTF_8) | ""
        "input1000byte" | STR_1000_BYTES.getBytes(StandardCharsets.UTF_8) | STR_1000_BYTES
    }
    @Unroll
    def "byteToString.Exception.#caseName"() {
        given:
        byte[] target = input

        when:
        Conversion.byteToString(target)

        then:
        thrown(expect)

        where:
        caseName | input | expect
        "NullPointerException" | null | NullPointerException
        "UTF-16.SystemFailureException" | STR_1000_BYTES.getBytes(StandardCharsets.UTF_16) | SystemFailureException
    }

    @Unroll
    def "trimTrailingLf.失敗レコードあり.#caseName"() {
        given: "準備"
        String target = input

        expect:
        outputValue==Conversion.trimTrailingLf(target)

        where:
        caseName | input | outputValue
        "改行無し" | "1" | "1"
        "改行1つ" | "1\n" | "1"
        "改行複数" | "1\n\n" | "1"
        "全部改行" | "\n\n\n" | ""
        "null" | null | null
    }

    @Unroll
    def "separateBytesBySemicolonメソッド.正常.#caseName"(){
        when:
        def result = Conversion.separateBytesBySemicolon(input)
        then:
        result == expectResult
        where:
        caseName | input | expectResult
        "空文字" | "".getBytes(StandardCharsets.UTF_8) | [""]
        "2こ" | "1;".getBytes(StandardCharsets.UTF_8) | ["1", ""]
        "3こ" | ";2 ;".getBytes(StandardCharsets.UTF_8) | ["", "2 ", ""]
        "4こ" | ";;;333".getBytes(StandardCharsets.UTF_8) | ["", "", "", "333"]
    }

    @Unroll
    def "separateBytesBySemicolonメソッド.エラー.#caseName"(){
        when:
        def result = Conversion.separateBytesBySemicolon(input)
        then:
        thrown(expectResult)
        where:
        caseName | input | expectResult
        "null" | null | NullPointerException
        "エンコード不正" | STR_1000_BYTES.getBytes(StandardCharsets.UTF_16) | SystemFailureException
    }

    @Unroll
    def "separateBytesBySemicolonAndBreakLineメソッド.正常.#caseName"(){
        setup:
        when:
        List<List<String>> result = Conversion.separateBytesBySemicolonAndBreakLine(input)
        then:
        result == expectResult
        where:
        caseName | input | expectResult
        "空文字" | "".getBytes(StandardCharsets.UTF_8) |[[""]]
        "1こ" | "1;2;3".getBytes(StandardCharsets.UTF_8) | [["1", "2", "3"]]
        "2こ" | "1;2;3\n1;2;3".getBytes(StandardCharsets.UTF_8) | [["1", "2", "3"], ["1", "2", "3"]]
        "3こ(最後改行有)" | "1;2;3\n1;2;3\n1;2;3\n".getBytes(StandardCharsets.UTF_8) | [["1", "2", "3"], ["1", "2", "3"], ["1", "2", "3"]]
        "レコード数違い" | "1;2;3\n1;2;3;4\n1;2;3;4;5".getBytes(StandardCharsets.UTF_8) | [["1", "2", "3"], ["1", "2", "3", "4"], ["1", "2", "3", "4", "5"]]
    }

    @Unroll
    def "separateBytesBySemicolonAndBreakLineメソッド.エラー.#caseName"(){
        when:
        def result = Conversion.separateBytesBySemicolonAndBreakLine(input)
        then:
        thrown(expectResult)
        where:
        caseName | input | expectResult
        "null" | null | NullPointerException
        "エンコード不正" | "1;2;3\n1;2;3;4\n1;2;3;4;5".getBytes(StandardCharsets.UTF_16) | SystemFailureException
    }
}
