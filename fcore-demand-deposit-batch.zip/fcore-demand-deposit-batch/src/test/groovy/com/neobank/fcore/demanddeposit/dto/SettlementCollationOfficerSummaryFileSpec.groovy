package com.neobank.fcore.demanddeposit.dto

import com.google.cloud.spanner.Struct
import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

@Title("SettlementCollationOfficerSummaryFileテスト")
class SettlementCollationOfficerSummaryFileSpec extends Specification{

    def setupSpec() {
    }

    @Unroll
    def "SettlementCollationOfficerSummaryFile.Struct.#caseName"(){
        setup:
        Struct struct = Mock(Struct)
        struct.isNull("Amount") >> {return Amount==null}
        struct.isNull("Number") >> {return NumberVal==null}
        struct.getLong("Amount") >> Amount
        struct.getLong("Number") >> NumberVal

        Long resAmount = Amount==null ? 0L : Amount
        Long resNumberVal = NumberVal==null ? 0L : NumberVal

        when:
        SettlementCollationOfficerSummaryFile entity = new SettlementCollationOfficerSummaryFile(struct);

        then:
        entity.getAmount() == resAmount
        entity.getNumber() == resNumberVal

        where:
        caseName | Amount | NumberVal
        "通常" | 1 | 2
        "1.null" | 1 | null
        "null.2" | null | 2
        "null.null" | null | null
    }
}
