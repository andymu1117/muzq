package com.neobank.fcore.demanddeposit.transform


import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title
import spock.lang.Unroll

import com.accenture.mainri.core.entity.DataClassBase

import com.neobank.fcore.demanddeposit.code.SettlementCollationDataTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerDetailFile
import com.neobank.fcore.demanddeposit.dto.SettlementCollationOfficerSummaryFile

@Title("SettlementCollationMergeForOfficerSummaryFnテスト")
public class SettlementCollationMergeForOfficerSummaryFnSpec extends Specification implements Serializable {

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationMergeForOfficerSummaryFn function = new SettlementCollationMergeForOfficerSummaryFn()

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
    }

    @Unroll
    def "Transformが正常終了.#caseName"() {
        given: "Pipeline実行&Ouput確認"
        PCollection<KV<List<String>, Iterable<SettlementCollationBase>>> input = p.apply(Create.of(inData()))
        PCollection<KV<List<String>, Map<String, List<DataClassBase>>>> output = input.apply(ParDo.of(function))

        PAssert.that(output)
                .containsInAnyOrder(resData());

        expect:
        p.run()
    }

    //    入力データ
    private List<KV<List<String>, Map<String, List<DataClassBase>>>> resData(){
        def data = new SettlementCollationOfficerSummaryFile();
        data.number = 10;
        data.amount = 10;
        data.errorFlag = "0";
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()
        resDatalist.add(data)

        Map<String, List<DataClassBase>> resultMap = new HashMap<>();
        resultMap.put(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode(), resDatalist);

        List<String> keys = new ArrayList<>()
        keys.add("output");

        List<KV<List<String>, SettlementCollationOfficerDetailFile>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, resultMap))
        return reslist
    }
    //    出力データ
    private List<KV<List<String>, Iterable<SettlementCollationOfficerSummaryFile>>> inData(){
        def data = new SettlementCollationOfficerSummaryFile();
        data.number = 10;
        data.amount = 10;
        data.errorFlag = "0";
        List<SettlementCollationOfficerDetailFile> resDatalist = new ArrayList<>()
        resDatalist.add(data)

        List<String> keys = new ArrayList<>();
        keys.add(SettlementCollationDataTypeCode.DATA_TYPE_OUTBOUND_TRANSFER.getCode())
        List<KV<List<String>, Iterable<SettlementCollationOfficerDetailFile>>> reslist = new ArrayList<>()
        reslist.add(KV.of(keys, (Iterable<SettlementCollationOfficerDetailFile>)resDatalist))
        return reslist
    }
}
