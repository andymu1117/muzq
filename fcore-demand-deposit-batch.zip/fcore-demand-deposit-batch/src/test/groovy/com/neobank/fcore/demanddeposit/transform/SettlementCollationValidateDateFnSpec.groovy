package com.neobank.fcore.demanddeposit.transform

import org.apache.beam.sdk.transforms.DoFn.OutputReceiver
import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.exception.BusinessFailureException


@Title("SettlementCollationValidateDateFnテスト")
class SettlementCollationValidateDateFnSpec extends Specification {

    @Unroll
    def "checkParamDateメソッド.異常.#caseName"() {
        when:
        new SettlementCollationValidateDateFn().processElement(targetDate, Stub(OutputReceiver));

        then:
        thrown(exception)

        where:
        caseName | targetDate | exception
        "異常(null)" | null | BusinessFailureException
        "異常(空文字)" | "" | BusinessFailureException
        "異常(半角スペース)" | " " | BusinessFailureException
        "異常(あり得ない日付)" | "20190229" | BusinessFailureException
        "異常(桁数多い)" | "202002299" | BusinessFailureException
        "異常(桁数少ない)" | "2020021" | BusinessFailureException
    }
}
