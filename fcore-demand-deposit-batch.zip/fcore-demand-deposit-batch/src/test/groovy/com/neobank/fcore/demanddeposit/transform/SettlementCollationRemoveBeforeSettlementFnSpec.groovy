package com.neobank.fcore.demanddeposit.transform


import java.nio.charset.StandardCharsets

import org.apache.beam.sdk.options.ValueProvider
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.transforms.View
import org.apache.beam.sdk.values.KV
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionView
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.neobank.fcore.demanddeposit.code.CommunicationTypeCode
import com.neobank.fcore.demanddeposit.dto.SettlementCollationBase
import com.neobank.fcore.demanddeposit.dto.SettlementCollationFile
import com.neobank.fcore.demanddeposit.utils.Conversion

@Title("SettlementCollationRemoveBeforeSettlementFnテスト")
public class SettlementCollationRemoveBeforeSettlementFnSpec extends Specification implements Serializable {

    // ファイル読み込み用
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallTodayDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};
    private TupleTag<KV<List<String>, SettlementCollationBase>> smallFutureDataTag =
    new TupleTag<KV<List<String>, SettlementCollationBase>>() {};

    // ファイルデータ振り分け用
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileOutboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<KV<List<String>, SettlementCollationFile>> fileInboundNotTransferTag =
    new TupleTag<KV<List<String>, SettlementCollationFile>>() {};
    TupleTag<Integer> fileOutboundTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileOutboundNotTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundTransferNumTag = new TupleTag<Integer>() {};
    TupleTag<Integer> fileInboundNotTransferNumTag = new TupleTag<Integer>() {};

    // 判定結果の出力を分ける為のタグ
    TupleTag<Integer> errorNumTag = new TupleTag<Integer>() {};

    List<String> beforeSettlementList =  SettlementCollationData.getBeforeSettlementList();

    String nextWorkDayStr = "20190102"
    String targetDateStr = "20190101"
    PCollectionView<String> nextWorkDay
    ValueProvider<String> targetDate = StaticValueProvider.of(targetDateStr)

    // テスト用Pipline
    @Rule public transient TestPipeline p = TestPipeline.create()

    @Subject
    def SettlementCollationRemoveBeforeSettlementFn function

    def setupSpec() {
        //テストクラス内で一度きりの初期化
    }

    def setup() {
        nextWorkDay = p.apply("create nextWorkDayStr",Create.of(nextWorkDayStr)).apply(View.asSingleton())
        function = new SettlementCollationRemoveBeforeSettlementFn()
    }

    def "Transformが正常完了"() {
        given:
        List<String> list = new ArrayList()

        PCollection<KV<List<String>, SettlementCollationFile>> output = p
                .apply(Create.of(SettlementCollationData.getInput().getBytes()))
                .apply(ParDo.of(new SettlementCollationByteColumnSeparatorFn(smallTodayDataTag, smallFutureDataTag, nextWorkDay, targetDate)).withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag)).withSideInputs(nextWorkDay))
                .get(smallTodayDataTag)
                // 上述のパイプラインはテスト済みとして実行
                .apply(ParDo.of(function));

        //                1;2;1022;20190101;5;6;0\n
        SettlementCollationFile result = new SettlementCollationFile()
        result.zenginProcessCode = "1";
        result.managementNumber = "2";
        result.communicationTypeCode = "1022";
        result.transferScheduledDate = "20190101";
        result.amount = 5;
        result.coreMoreTimeType = "6";
        result.largeValueTransactionFlag = "0";

        List<String> keys = new ArrayList<>();
        keys.add(result.managementNumber);

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。

        PAssert.that(output)
                .containsInAnyOrder(KV.of(keys,result));

        expect:
        // Pipelineを実行する。
        p.run();
    }

    def "Transformが正常完了.allCommunicationType"() {
        given:

        PCollection<KV<List<String>, SettlementCollationBase>> inputs = p
                .apply(Create.of(SettlementCollationData.getAllCommunicationInput().getBytes()))
                .apply(ParDo.of(new SettlementCollationByteColumnSeparatorFn(smallTodayDataTag, smallFutureDataTag, nextWorkDay, targetDate)).withOutputTags(smallTodayDataTag, TupleTagList.of(smallFutureDataTag)).withSideInputs(nextWorkDay))
                .get(smallTodayDataTag)
        // 上述のパイプラインはテスト済みとして実行
        ;

        List<SettlementCollationBase> resultsToday = new ArrayList<>();
        List<SettlementCollationBase> resultsFuture = new ArrayList<>();

        int index = 0;
        for(List<String> line : Conversion.separateBytesBySemicolonAndBreakLine(SettlementCollationData.getAllCommunicationInput().getBytes(StandardCharsets.UTF_8))) {
            if(line.size() != 7) continue;

            def result = new SettlementCollationFile();
            result.zenginProcessCode = line.get(0);
            result.managementNumber = line.get(1);
            result.communicationTypeCode = line.get(2);
            result.transferScheduledDate = line.get(3);
            result.amount = Long.valueOf(line.get(4));
            result.coreMoreTimeType = line.get(5);
            result.largeValueTransactionFlag = line.get(6);

            def key = new ArrayList<>()
            key.add(result.managementNumber)
            def resultKv = KV.of(key, (SettlementCollationBase)result)
            if(!CommunicationTypeCode.isBeforeSettlementTarget(line.get(2))) resultsToday.add(resultKv)
            index++;
        }

        def output = inputs
                .apply(ParDo.of(function));

        // Outputが予想であるかチェックする。
        // 注意：PAssertの声明は、PipelineをRunする前に行う必要。
        PAssert.that(output)
                .containsInAnyOrder(resultsToday);

        expect:
        // Pipelineを実行する。
        p.run();
    }
}
