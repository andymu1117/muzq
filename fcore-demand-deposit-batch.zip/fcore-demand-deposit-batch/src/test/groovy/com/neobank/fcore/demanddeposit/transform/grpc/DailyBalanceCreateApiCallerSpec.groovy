package com.neobank.fcore.demanddeposit.transform.grpc

import com.google.protobuf.Any
import io.grpc.Metadata
import io.grpc.Status
import io.grpc.StatusRuntimeException
import io.grpc.protobuf.StatusProto
import io.grpc.stub.StreamObserver
import org.apache.beam.sdk.options.PipelineOptions
import org.apache.beam.sdk.options.PipelineOptionsFactory
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.PCollection
import org.apache.beam.sdk.values.PCollectionTuple
import org.apache.beam.sdk.values.TupleTag
import org.apache.beam.sdk.values.TupleTagList
import org.junit.Rule
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Title

import com.accenture.mainri.test.utils.grpc.GrpcTestRule

import com.neobank.fcore.demanddeposit.dto.DailyBalanceCreateResponseDto
import com.neobank.fcore.demanddeposit.dto.ErrorLogEntryDto
import com.neobank.fcore.demanddeposit.entity.AccountEntity
import com.neobank.fcore.demanddeposit.pb.command.DailyBalanceCommandGrpc.DailyBalanceCommandImplBase
import com.neobank.fcore.demanddeposit.pb.command.message.DailyBalanceCalculateRequest
import com.neobank.fcore.demanddeposit.pb.command.message.DailyBalanceCalculateResponse
import com.neobank.fcore.demanddeposit.pipeline.options.DailyBalanceCreateOption
@Title('Daily Balance Create API Caller Transform テストケース ')
class DailyBalanceCreateApiCallerSpec extends Specification implements Serializable {
    // Grpc関連テストルール
    @Rule
    def final transient GrpcTestRule grpcRule = new GrpcTestRule();
    // テスト用Pipeline options
    @Shared
    def PipelineOptions options = {
        def op = PipelineOptionsFactory.as(DailyBalanceCreateOption.class)
        op.setProcessDate(new StaticValueProvider<String>("2019-10-21"))
        return op
    }()
    // テスト用Pipeline
    @Rule
    def transient TestPipeline p = TestPipeline.fromOptions(options);
    def TupleTag<DailyBalanceCreateResponseDto> successTag = new TupleTag<DailyBalanceCreateResponseDto>() {};
    def TupleTag<ErrorLogEntryDto> errorTag = new TupleTag<ErrorLogEntryDto>() {};
    def TupleTag<ErrorLogEntryDto> warnTag = new TupleTag<ErrorLogEntryDto>() {};
    @Subject
    def DailyBalanceCreateApiCaller apiCaller = new DailyBalanceCreateApiCaller(grpcRule.newFakeGrpcConnector(), successTag, errorTag, warnTag);

    def "Transformが正常完了"() {
        given: "Grpc サービス準備"
        grpcRule.addService(new DailyBalanceCommandImplBase() {
                    @Override
                    public void calculate(DailyBalanceCalculateRequest request, StreamObserver<DailyBalanceCalculateResponse> responseObserver) {
                        responseObserver.onNext(DailyBalanceCalculateResponse.getDefaultInstance());
                        responseObserver.onCompleted();
                    }
                });
        expect: "Pipeline実行&Ouput確認"
        PCollection<DailyBalanceCalculateRequest> input = p.apply(Create.of(account));
        // Output PCollectionを取得する。
        PCollectionTuple output = input.apply(ParDo.of(apiCaller)
                .withOutputTags(successTag, TupleTagList.of(errorTag).and(warnTag)));
        // Outputが予想であるかチェックする。
        PAssert.that(output.get(successTag))
                .containsInAnyOrder(result);
        // Pipelineを実行する。
        p.run();
        where:  "テストデーター準備"
        account = newAccount();
        result = new DailyBalanceCreateResponseDto(DailyBalanceCalculateResponse.getDefaultInstance());
    }

    def "Transformが業務異常完了"() {
        given: "Grpc サービス準備"
        grpcRule.addService(new DailyBalanceCommandImplBase() {
                    @Override
                    public void calculate(DailyBalanceCalculateRequest request, StreamObserver<DailyBalanceCalculateResponse> responseObserver) {
                        responseObserver.onNext(DailyBalanceCalculateResponse.getDefaultInstance());
                        responseObserver.onError(mockValidationError());
                    }
                });
        expect: "Pipeline実行&Ouput確認"
        PCollection<AccountEntity> input = p.apply(Create.of(account));
        // Output PCollectionを取得する。
        PCollectionTuple output = input.apply(ParDo.of(apiCaller)
                .withOutputTags(successTag, TupleTagList.of(errorTag).and(warnTag)));
        // Outputが予想であるかチェックする。
        PAssert.that(output.get(warnTag))
                .containsInAnyOrder(errorLogEntry);
        // Pipelineを実行する。
        p.run();
        where:  "テストデーター準備"
        account = newAccount();
        errorLogEntry << newValidationErrorLogEntryDto()
    }

    def "Transformがシステム異常完了"() {
        given: "Grpc サービス準備"
        grpcRule.addService(new DailyBalanceCommandImplBase() {
                    @Override
                    public void calculate(DailyBalanceCalculateRequest request, StreamObserver<DailyBalanceCalculateResponse> responseObserver) {
                        responseObserver.onNext(DailyBalanceCalculateResponse.getDefaultInstance());
                        responseObserver.onError(mockSystemError());
                    }
                });
        expect: "Pipeline実行&Ouput確認"
        PCollection<DailyBalanceCalculateRequest> input = p.apply(Create.of(account));
        // Output PCollectionを取得する。
        PCollectionTuple output = input.apply(ParDo.of(apiCaller)
                .withOutputTags(successTag, TupleTagList.of(errorTag).and(warnTag)));
        // Outputが予想であるかチェックする。
        PAssert.that(output.get(errorTag))
                .containsInAnyOrder(errorLogEntry);
        // Pipelineを実行する。
        p.run();
        where:  "テストデーター準備"
        account << newAccount();
        errorLogEntry << newSystemErrorLogEntryDto();
    }

    def AccountEntity newAccount() {
        AccountEntity entity =  new AccountEntity();
        entity.setAccountId("00000000-0000-0000-0020-000000001000");
        entity.setAccountManageKey("020");
        entity.setAccountNo("0001000");
        entity.setCustomerId("00000000-0000-0000-0000-000000000000");
        entity.setCustomerNo("000000000");
        return entity;
    }

    def ErrorLogEntryDto newSystemErrorLogEntryDto() {
        return new ErrorLogEntryDto(newAccount(), mockSystemError());
    }

    def ErrorLogEntryDto newValidationErrorLogEntryDto() {
        return new ErrorLogEntryDto(newAccount(), mockValidationError());
    }

    def RuntimeException mockValidationError() {
        Metadata trailers = new Metadata();
        com.google.rpc.Status statusProto =  com.google.rpc.Status.DEFAULT_INSTANCE.toBuilder()
                .setCode(Status.INVALID_ARGUMENT.getCode().value())
                .addDetails(new Any().DEFAULT_INSTANCE.toBuilder().setTypeUrl("xxx.ErrorResponse").build())
                .setMessage("INVALID_ARGUMENT")
                .build();
        trailers.put(StatusProto.STATUS_DETAILS_KEY, statusProto);
        return new StatusRuntimeException(Status.INVALID_ARGUMENT, trailers)
    }

    def RuntimeException mockSystemError() {
        return new RuntimeException("error response from gRPC is empty.");
    }
}
