package com.neobank.fcore.demanddeposit.code

import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

@Title("CommunicationTypeCodeテスト")
class CommunicationTypeCodeSpec  extends Specification implements Serializable {
    @Unroll
    def "CommunicationTypeCode:マッピングチェック.#caseName"() {
        expect:
        CommunicationTypeCode.isBeforeSettlementTarget(code) == isBeforeSettlement
        CommunicationTypeCode.isBillingTarget(code) == isBillingTarget
        CommunicationTypeCode.isChangeTarget(code) == isChangeTarget
        CommunicationTypeCode.isTransferTarget(code) == isTransferTarget

        where:
        caseName | code | isBeforeSettlement | isBillingTarget | isChangeTarget | isTransferTarget
        "通信種目コード.1022(当日／振込／一般)"    |   "1022"  |   false   |   false   |   false   |   true
        "通信種目コード.1054(当日／振込／国庫金)"   |   "1054"  |   false   |   false   |   false   |   true
        "通信種目コード.1074(当日／振込／公金)"    |   "1074"  |   false   |   false   |   false   |   true
        "通信種目コード.1082(当日／振込／電子記録債権)"    |   "1082"  |   false   |   false   |   false   |   true
        "通信種目コード.1041(当日／振込／株式配当金（一般）)" |   "1041"  |   false   |   false   |   false   |   true
        "通信種目コード.1046(当日／振込／株式配当金（自行）)" |   "1046"  |   false   |   false   |   false   |   true
        "通信種目コード.1042(当日／振込／貸付信託収益配当金)" |   "1042"  |   false   |   false   |   false   |   true
        "通信種目コード.1043(当日／振込／年金給付金（年金信託）)"   |   "1043"  |   false   |   false   |   false   |   true
        "通信種目コード.1044(当日／振込／年金給付金（公的年金）)"   |   "1044"  |   false   |   false   |   false   |   true
        "通信種目コード.1045(当日／振込／年金給付金（医療保険）)"   |   "1045"  |   false   |   false   |   false   |   true
        "通信種目コード.4101(当日／付替／集手資金付替)"    |   "4101"  |   false   |   false   |   true    |   false
        "通信種目コード.4201(当日／付替／期近資金付替)"    |   "4201"  |   false   |   false   |   true    |   false
        "通信種目コード.4301(当日／付替／その他資金付替)"   |   "4301"  |   false   |   false   |   true    |   false
        "通信種目コード.4401(当日／付替／その他資金付替（電子記録債権）)"   |   "4401"  |   false   |   false   |   true    |   false
        "通信種目コード.4501(当日／請求／一般・メール振込資金請求)"  |   "4501"  |   false   |   true    |   false   |   false
        "通信種目コード.4671(当日／請求／公金・メール振込資金請求)"  |   "4671"  |   false   |   true    |   false   |   false
        "通信種目コード.4701(当日／請求／その他資金請求)"   |   "4701"  |   false   |   true    |   false   |   false
        "通信種目コード.4910(当日／請求／集手・期近の不渡通知)"    |   "4910"  |   false   |   true    |   false   |   false
        "通信種目コード.3101(個別取立／入金報告)"   |   "3101"  |   false   |   false   |   false   |   false
        "通信種目コード.2154(送金／国庫金)"  |   "2154"  |   false   |   false   |   false   |   false
        "通信種目コード.2174(送金／公金)"   |   "2174"  |   false   |   false   |   false   |   false
        "通信種目コード.1122(先日付／振込／一般)"   |   "1122"  |   false   |   false   |   false   |   true
        "通信種目コード.1154(先日付／振込／国庫金)"  |   "1154"  |   false   |   false   |   false   |   true
        "通信種目コード.1174(先日付／振込／公金)"   |   "1174"  |   false   |   false   |   false   |   true
        "通信種目コード.1182(先日付／振込／電子記録債権)"   |   "1182"  |   false   |   false   |   false   |   true
        "通信種目コード.1141(先日付／振込／株式配当金（一般）)"    |   "1141"  |   false   |   false   |   false   |   true
        "通信種目コード.1146(先日付／振込／株式配当金（自行）)"    |   "1146"  |   false   |   false   |   false   |   true
        "通信種目コード.1142(先日付／振込／貸付信託収益配当金)"    |   "1142"  |   false   |   false   |   false   |   true
        "通信種目コード.1143(先日付／振込／年金給付金（年金信託）)"  |   "1143"  |   false   |   false   |   false   |   true
        "通信種目コード.1144(先日付／振込／年金給付金（公的年金）)"  |   "1144"  |   false   |   false   |   false   |   true
        "通信種目コード.1145(先日付／振込／年金給付金（医療保険）)"  |   "1145"  |   false   |   false   |   false   |   true
        "通信種目コード.4102(先日付／付替／集手資金付替)"   |   "4102"  |   false   |   false   |   true    |   false
        "通信種目コード.4202(先日付／付替／期近資金付替)"   |   "4202"  |   false   |   false   |   true    |   false
        "通信種目コード.4302(先日付／付替／その他資金付替)"  |   "4302"  |   false   |   false   |   true    |   false
        "通信種目コード.4402(先日付／付替／その他資金付替（電子記録債権）)"  |   "4402"  |   false   |   false   |   true    |   false
        "通信種目コード.4702(先日付／請求／その他資金請求)"  |   "4702"  |   false   |   true    |   false   |   false
        "通信種目コード.1211(給与／一般)"   |   "1211"  |   false   |   false   |   false   |   true
        "通信種目コード.1271(給与／公金（指定日決済）)"    |   "1271"  |   false   |   false   |   false   |   true
        "通信種目コード.1251(給与／国庫金)"  |   "1251"  |   true   |   false   |   false   |   true
        "通信種目コード.1275(給与／公金（指定日前営業日決済）)"    |   "1275"  |   true   |   false   |   false   |   true
        "通信種目コード.1212(賞与／一般)"   |   "1212"  |   false   |   false   |   false   |   true
        "通信種目コード.1272(賞与／公金（指定日決済）)"    |   "1272"  |   false   |   false   |   false   |   true
        "通信種目コード.1252(賞与／国庫金)"  |   "1252"  |   true   |   false   |   false   |   true
        "通信種目コード.1276(賞与／公金（指定日前営業日決済）)"    |   "1276"  |   true   |   false   |   false   |   true
        "通信種目コード.1122(文書為替／一般)" |   "1122"  |   false   |   false   |   false   |   true
        "通信種目コード.1154(文書為替／国庫金)"    |   "1154"  |   false   |   false   |   false   |   true
        "通信種目コード.1174(文書為替／公金)" |   "1174"  |   false   |   false   |   false   |   true
        "通信種目コード.1122(先日付振込／一般)"    |   "1122"  |   false   |   false   |   false   |   true
        "通信種目コード.1154(先日付振込／国庫金)"   |   "1154"  |   false   |   false   |   false   |   true
        "通信種目コード.1174(先日付振込／公金)"    |   "1174"  |   false   |   false   |   false   |   true
        "通信種目コード.1211(給与振込／一般)" |   "1211"  |   false   |   false   |   false   |   true
        "通信種目コード.1271(給与振込／公金（指定日決済）)"  |   "1271"  |   false   |   false   |   false   |   true
        "通信種目コード.1251(給与振込／国庫金)"    |   "1251"  |   true   |   false   |   false   |   true
        "通信種目コード.1275(給与振込／公金（指定日前営業日決済）)"  |   "1275"  |   true   |   false   |   false   |   true
        "通信種目コード.1212(賞与振込／一般)" |   "1212"  |   false   |   false   |   false   |   true
        "通信種目コード.1272(賞与振込／公金（指定日決済）)"  |   "1272"  |   false   |   false   |   false   |   true
        "通信種目コード.1252(賞与振込／国庫金)"    |   "1252"  |   true   |   false   |   false   |   true
        "通信種目コード.1276(賞与振込／公金（指定日前営業日決済）)"  |   "1276"  |   true   |   false   |   false   |   true
        "通信種目コード.1142(貸付信託収益配当金振込)" |   "1142"  |   false   |   false   |   false   |   true
        "通信種目コード.1143(年金信託契約に係る年金・一時金給付金振込)"    |   "1143"  |   false   |   false   |   false   |   true
        "通信種目コード.1144(公的年金保険の年金・一時給付金振込)"   |   "1144"  |   false   |   false   |   false   |   true
        "通信種目コード.1145(医療保険の給付金振込)"  |   "1145"  |   false   |   false   |   false   |   true
        "通信種目コード.1141(株式配当金振込／一般)"  |   "1141"  |   false   |   false   |   false   |   true
        "通信種目コード.1146(株式配当金振込／自行)"  |   "1146"  |   false   |   false   |   false   |   true
    }
}


