package com.neobank.fcore.demanddeposit.transform.writer

import spock.lang.Specification
import spock.lang.Title

@Title("ZenginReconcileMoveCompletedFileテスト")
class SettlementCollationMoveCompletedFileSpec  extends Specification implements Serializable {
    // ファイル操作を伴う箇所は、パイプラインを実行させて確認する。
}
