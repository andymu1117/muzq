package com.neobank.fcore.demanddeposit.transform

import java.time.LocalDate;

import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.ParDo
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Title

import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterEntity
import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity

@Title('利息無しの預金口座をフィルターする用エンティティ（利息基準日（LocalDate）付け）転換Fnのテストケース ')
class InterestAccountFilterWithLocalDateOfInterestDateConvertFnSpec extends Specification implements Serializable {

    def inputEntity = new InterestAccountFilterEntity(
    accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
    offeringId:null,
    interestFlag:"1",
    salesStartDate:LocalDate.of(2019, 11, 11),
    salesEndDate:LocalDate.of(2019, 11, 11),
    itemReferenceFlag:"1",
    offeringsInterestFlag:"1",
    offeringsOfferingId:"d1a62527-9308-4a93-bee4-660faaf55d94",
    interestDate:"20191104",
    )

    def outputEntity = new InterestAccountFilterWithLocalDateOfInterestDateEntity(
    accountId:"e7cdec8b-0260-4dee-a75c-97d522aada39",
    offeringId:null,
    interestFlag:"1",
    salesStartDate:LocalDate.of(2019, 11, 11),
    salesEndDate:LocalDate.of(2019, 11, 11),
    itemReferenceFlag:"1",
    offeringsInterestFlag:"1",
    offeringsOfferingId:"d1a62527-9308-4a93-bee4-660faaf55d94",
    interestDate:"20191104",
    interestDateWithoutHyphenToLocalDate:LocalDate.of(2019, 11, 4)
    )

    @Rule transient TestPipeline p = TestPipeline.create()

    def "エンティティ転換処理が正常に完了する場合"() {

        expect: "Pipeline実行"
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> output = p.apply(Create.of(inputEntity)).setCoder(SerializableCoder.of(InterestAccountFilterEntity.class))
                .apply("Convert interestAccountFilterEntity to interestAccountFilterWithLocalDateOfInterestDateEntity",ParDo.of(new InterestAccountFilterWithLocalDateOfInterestDateConvertFn()))
        // Outputが予想であるかチェックする。
        PAssert.that(output).containsInAnyOrder(outputEntity);
        // Pipelineを実行する。
        p.run();
    }
}
