package com.neobank.fcore.demanddeposit.utils

import spock.lang.Specification
import spock.lang.Title

@Title("FileUtilsテスト")
class FileUtilsSpec extends Specification {
    // 以下のメソッドはファイル操作を行うため、パイプラインを実行させて確認する。
    // renameFile()
    // readFile()
    // matchFile()
    // readMatchedOnlyOneFile()
    // readMatchedOneOrNoFile()
    // writeFile()
}
