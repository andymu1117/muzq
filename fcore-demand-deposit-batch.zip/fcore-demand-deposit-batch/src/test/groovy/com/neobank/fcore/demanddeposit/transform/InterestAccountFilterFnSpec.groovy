package com.neobank.fcore.demanddeposit.transform

import org.apache.beam.sdk.coders.SerializableCoder
import org.apache.beam.sdk.testing.PAssert
import org.apache.beam.sdk.testing.TestPipeline
import org.apache.beam.sdk.transforms.Create
import org.apache.beam.sdk.transforms.Filter;
import org.apache.beam.sdk.values.PCollection
import org.junit.Rule
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Title
import spock.lang.Unroll

import com.neobank.fcore.demanddeposit.entity.InterestAccountFilterWithLocalDateOfInterestDateEntity
@Title('利息無しの預金口座をフィルターするFilter テストケース ')
class InterestAccountFilterFnSpec extends Specification implements Serializable {

    @Shared
    def data = new InterestAccountFilterFnData()

    @Rule transient TestPipeline p = TestPipeline.create()

    @Unroll
    def "フィルター処理が正常に完了(#caseName)"() {
        expect: "Pipeline実行&Ouput確認"
        PCollection<InterestAccountFilterWithLocalDateOfInterestDateEntity> output = p.apply(Create.of(inputEntity)).setCoder(SerializableCoder.of(InterestAccountFilterWithLocalDateOfInterestDateEntity.class))
                .apply("Filter interestAccountFilterWithLocalDateOfInterestDateEntity", Filter.by(new InterestAccountFilterFn()));
        // Outputが予想であるかチェックする。
        PAssert.that(output).containsInAnyOrder(outputEntity);
        // Pipelineを実行する。
        p.run();

        where:"テストデータ準備"

        caseName                                                                                                                                                                                          | inputEntity                                                                 | outputEntity
        "0.処理対象である「口座.オファリングIDなし、基本商品BS情報.利息有無フラグは有」"                                                                                                                  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[0]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[0]
        "1.処理対象である「口座.オファリングIDなし、基本商品BS情報.利息有無フラグは無」"                                                                                                                  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[1]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[1]
        "2.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDなし」"                                                                                                                    | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[2]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[2]
        "3.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、利息基準日 < 販売開始日」"                                                                                           | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[3]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[3]
        "4.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、利息基準日 > 販売終了日」"                                                                                           | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[4]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[4]
        "5.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは有」"  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[5]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[5]
        "6.処理対象でない「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは無」"  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[6]  | []
        "7.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照する、基本商品BS情報.利息有無フラグは有」"  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[7]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[7]
        "8.処理対象でない「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 < 利息基準日 = 販売終了日、オファリング.基本商品参照フラグ参照する、基本商品BS情報.利息有無フラグは無」"  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[8]  | []
        "9.処理対象である「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 = 利息基準日 < 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは有」"  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[9]  | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[9]
        "10.処理対象でない「口座.オファリングIDあり、オファリング.オファリングIDあり、販売開始日 = 利息基準日 = 販売終了日、オファリング.基本商品参照フラグ参照しない、オファリング.利息有無フラグは無」" | data.inputInterestAccountFilterWithLocalDateOfInterestDateEntity[10] | []
    }
}
