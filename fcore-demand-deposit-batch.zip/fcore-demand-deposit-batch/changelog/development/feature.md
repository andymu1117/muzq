# 開発中

**更新日:2020/05/30 04:31:49**



## MVP1:作業

* [17645] [BT-ID-TBD_日次残高確定_BT_設計作業](https://ndp091d.acnshared.com/redmine/issues/17645)

* [17666] [BT-ID-TBD_利息決算元加_BT_開発作業](https://ndp091d.acnshared.com/redmine/issues/17666)

* [19102] [預金チーム_最新のアーキリリース(11/6)を取り込む](https://ndp091d.acnshared.com/redmine/issues/19102)

* [31442] [[ITb1][性能]Dataflowジョブのサービスアカウント名の修正](https://ndp091d.acnshared.com/redmine/issues/31442)

* [32008] [[預金]アーキ更新取り込み](https://ndp091d.acnshared.com/redmine/issues/32008)


## MVP1:障害

* [31915] [[ITb1][性能]利息決算元加バッチ処理にて、口座利息テーブルにあるデータが一部更新されない](https://ndp091d.acnshared.com/redmine/issues/31915)


## MVP2:作業

* [35968] [CBT007F_顧客優遇条件更新_UT作業](https://ndp091d.acnshared.com/redmine/issues/35968)

* [39046] [SAST対応 - Scalable Batch](https://ndp091d.acnshared.com/redmine/issues/39046)



## yaml data

```yaml
---
changelog:
  lastupdate: 2020/05/30 04:31:49
  release:
    v1.1.3:
      date: 2020/05/30
      ticket:
      - id: '17645'
        url: https://ndp091d.acnshared.com/redmine/issues/17645
        title: BT-ID-TBD_日次残高確定_BT_設計作業
        tracker: 作業
        status: 完了
        fixed_version: MVP1
      - id: '17666'
        url: https://ndp091d.acnshared.com/redmine/issues/17666
        title: BT-ID-TBD_利息決算元加_BT_開発作業
        tracker: 作業
        status: 完了
        fixed_version: MVP1
      - id: '19102'
        url: https://ndp091d.acnshared.com/redmine/issues/19102
        title: 預金チーム_最新のアーキリリース(11/6)を取り込む
        tracker: 作業
        status: 完了
        fixed_version: MVP1
      - id: '31442'
        url: https://ndp091d.acnshared.com/redmine/issues/31442
        title: "[ITb1][性能]Dataflowジョブのサービスアカウント名の修正"
        tracker: 作業
        status: 完了
        fixed_version: MVP1
      - id: '31915'
        url: https://ndp091d.acnshared.com/redmine/issues/31915
        title: "[ITb1][性能]利息決算元加バッチ処理にて、口座利息テーブルにあるデータが一部更新されない"
        tracker: 障害
        status: 完了
        fixed_version: MVP1
      - id: '32008'
        url: https://ndp091d.acnshared.com/redmine/issues/32008
        title: "[預金]アーキ更新取り込み"
        tracker: 作業
        status: 完了
        fixed_version: MVP1
      - id: '35968'
        url: https://ndp091d.acnshared.com/redmine/issues/35968
        title: CBT007F_顧客優遇条件更新_UT作業
        tracker: 作業
        status: 対応中
        fixed_version: MVP2
      - id: '39046'
        url: https://ndp091d.acnshared.com/redmine/issues/39046
        title: SAST対応 - Scalable Batch
        tracker: 作業
        status: 対応中
        fixed_version: MVP2

```
