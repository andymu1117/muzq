# MAINRI Dataflow Skeleton Project

## 環境セットアップ
* Java 8系のインストール
* Eclipseセットアップ
* プロジェクトルートにて`gradlew`コマンド実行

## ローカル実行
* `EntryPoint`クラスにある`Main`を実行することで動作確認が行える。
* 実行時の引数の`--pipelineName=${pipelineName}`（必須項目）に動作させたいPipelineの名称を指定する。
* Eclipseから実行する場合は AspectJを利用している機能が動作しなくなる(※1)。AspectJの利用が必要な場合は後述するgradleから実行する方法を使用すること。
* windows上のgradleから実行する場合は、`gradlew localRun　-Pargs="--pipelineName=${pipelineName}"` などと実行すること。
    * 上記コマンドを利用する理由は、Windowsコマンドラインの最大長を超過しないようにするため。問題の詳細は以下のURLを参照すること。
        * https://devblogs.microsoft.com/oldnewthing/?p=41553
    * 実行時引数は`-Pargs`内に空白区切りで記載する。

※1 AspectJ Pluginを使用すれば対応は可能だが、PluginをインストールするとGroovyEditorのSyntaxCheckでバグが発生するため使用しない。もしPluginをインストール済みの場合は[この手順](https://ndp091d.acnshared.com/redmine/projects/accenture/wiki/Eclipse%E3%81%A7Groovy%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB%E3%82%92%E9%96%8B%E3%81%84%E3%81%9F%E9%9A%9B%E3%81%AB%E7%99%BA%E7%94%9F%E3%81%99%E3%82%8BSyntaxError%E3%81%AE%E8%A7%A3%E6%B1%BA%E6%96%B9%E6%B3%95)を参考にアンインストールする。


## Dataflowでの実行
* 事前にgcloudツールにて認証を行っていることが前提。
* propertiesにて管理している`dataflow.runner`プロパティに`Dataflow`を指定することによって実行が可能。
    * propertiesはプロファイル別に管理しているため、直接書き換えるよりも別プロファイルで管理した方が良い。
    * `--profile=${profieName}` を実行時の引数に与えることによりプロファイルの切り替えが可能。
* 実行方法はローカル実行と同様。

## Templateの作成
* `dataflow.runner`に`Dataflow`を指定した状態で実行時引数に`--templateLocation=${templateLocation}`を与えると、実行は行わずに指定したロケーションにTemplateの作成のみを行う。
* Runtimeにて必要なパラメータは`ValueProvider`クラスを利用して定義する。
* Pipelineの名称や実行時に受け取れる引数を`metadata`として定義し、`templateLocation`に指定したディレクトリに配置する。
    * `metadata`は`src/main/resources/template-metadata`に格納して管理する。
* Templateの作成及び実行方法の詳細については以下を参照。
    * https://cloud.google.com/dataflow/docs/guides/templates/creating-templates
    * https://cloud.google.com/dataflow/docs/guides/templates/executing-templates


## インハウスリポジトリへのアクセス設定

共通ライブラリをインハウスリポジトリ(Nexus)から取得する必要があります。

インハウスリポジトリにはID/Passwordの認証が必要になります。

ユーザホームの `.gralde` フォルダに `gradle.properties` を作成して以下の内容を設定します。

```text
nexusUsername=[自分のID]
nexusPassword=[パスワード]
```

認証情報が不正な場合以下のようなエラーが発生します。

```bash
Could not resolve all files for configuration ':compileClasspath'.
> Could not resolve com.accenture.acts:acts-core-server-lib:1.0.4.  Required by:
      project :
   > Could not resolve com.accenture.acts:acts-core-server-lib:1.0.4.
      > Could not get resource 'https://adp001012.acnshared.com/nexus/content/repositories/releases/com/accenture/acts/acts-core-server-lib/1.0.4/acts-core-server-lib-1.0.4.pom'.
         > Could not GET 'https://adp001012.acnshared.com/nexus/content/repositories/releases/com/accenture/acts/acts-core-server-lib/1.0.4/acts-core-server-lib-1.0.4.pom'. Received status code 403 from server: Forbidden
```

* `401` エラーの場合はID/パスワードが間違っています。
* `403` エラーの場合は認証はOKなのですがインハウスリポジトリへのアクセス権限が無いのでプロジェクト管理者に問い合わせて下さい。

## GRPC用コードの自動生成

protoファイルを書き換えた際は次のコマンドを実行してGRPC用のコードを更新してください。

```bash
./gradlew generateProto
```
